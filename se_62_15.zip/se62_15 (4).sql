-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2020 at 06:31 PM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.2.28-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_15`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingId` int(11) NOT NULL,
  `borrowerId` int(11) NOT NULL,
  `lenderId` int(11) DEFAULT NULL,
  `status` enum('PENDING','APPROVE','RECEIVE','CANCEL') CHARACTER SET utf8 NOT NULL,
  `dateStart` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateEnd` timestamp NULL DEFAULT NULL,
  `disapprovalReason` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingId`, `borrowerId`, `lenderId`, `status`, `dateStart`, `dateEnd`, `disapprovalReason`) VALUES
(21, 2, NULL, 'PENDING', '2020-03-26 04:34:38', NULL, NULL),
(26, 2, NULL, 'PENDING', '2020-03-25 19:10:24', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryId` int(11) NOT NULL,
  `Name` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryId`, `Name`) VALUES
(1, '111'),
(2, 'com');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `commentId` int(11) NOT NULL,
  `comment` text NOT NULL,
  `datetime` datetime NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `detailBooking`
--

CREATE TABLE `detailBooking` (
  `detailBookingId` int(11) NOT NULL,
  `bookingID` int(11) NOT NULL,
  `deviceId` int(11) NOT NULL,
  `amount` int(5) NOT NULL,
  `receptionDate` datetime DEFAULT NULL,
  `revertingDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detailBooking`
--

INSERT INTO `detailBooking` (`detailBookingId`, `bookingID`, `deviceId`, `amount`, `receptionDate`, `revertingDate`) VALUES
(9, 21, 1, 1, '2020-03-26 11:34:38', NULL),
(14, 26, 2, 3, '2020-03-26 02:10:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `detaildevice`
--

CREATE TABLE `detaildevice` (
  `detailDeviceId` int(11) NOT NULL,
  `nameDevice` varchar(50) CHARACTER SET utf8 NOT NULL,
  `detail` varchar(255) CHARACTER SET utf8 NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detaildevice`
--

INSERT INTO `detaildevice` (`detailDeviceId`, `nameDevice`, `detail`, `amount`) VALUES
(1, 'device1', 'detail1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `deviceId` int(11) NOT NULL,
  `number` varchar(50) CHARACTER SET utf8 NOT NULL,
  `status` enum('READY','NOTREADY') CHARACTER SET utf8 NOT NULL DEFAULT 'READY',
  `picDevice` text CHARACTER SET utf8,
  `category` varchar(50) CHARACTER SET utf8 NOT NULL,
  `detail` varchar(255) CHARACTER SET utf8 NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device`
--

INSERT INTO `device` (`deviceId`, `number`, `status`, `picDevice`, `category`, `detail`, `name`) VALUES
(1, '10', 'READY', '23156fcasdfsafd5464', '', '', 'test'),
(2, '12', 'READY', NULL, 'หน้าจอ', 'ใช้แสดงผล', 'หน้าจอ'),
(3, '14', 'READY', NULL, 'เม้าส์', 'ใช้ควบคุม', 'เม้าส์'),
(4, '2', 'READY', NULL, 'เคสคอม', 'ใช้เก็บcpeคอม', 'เคสคอม'),
(5, '2', 'READY', NULL, 'ลำโพง', 'ใช้กระจายเสียง', 'ลำโพง'),
(6, '1', 'READY', NULL, 'ไอซี', 'ใช้ทดลองในห้องปฎิบัติการ', 'ไอซี'),
(7, '2', 'READY', NULL, 'มัลติมิเตอร์', 'ใช้วัดทางด้านไฟฟ้า', 'มัลติมิเตอร์'),
(8, '1', 'READY', NULL, 'ตัวเก็บประจุ', 'ใช้เก็บกระแสไฟฟฟ้า', 'ตัวเก็บประจุ'),
(9, '2', 'READY', NULL, 'บอร์ด', 'ใช่ต่อเพื่อทำวงจร', 'บอร์ด'),
(10, '1', 'READY', NULL, 'หัวแร้ง', 'ใช้บัดกรีแผงวงจร', 'หัวแร้ง'),
(11, '1', 'READY', NULL, 'ตัวต้านทาน', 'ใช้เป็นฉนวนไฟฟ้า', 'ตัวต้านทาน');

-- --------------------------------------------------------

--
-- Table structure for table `reception`
--

CREATE TABLE `reception` (
  `receptionId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET utf8 NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `surname` varchar(50) CHARACTER SET utf8 NOT NULL,
  `type` enum('STUDENT','PROFESSOR','OFFICER','ADMIN') CHARACTER SET utf8 NOT NULL,
  `numberStudent` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `numberMajor` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `telnumber` varchar(10) CHARACTER SET utf8 NOT NULL,
  `address` varchar(100) CHARACTER SET utf8 NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `username`, `name`, `surname`, `type`, `numberStudent`, `numberMajor`, `email`, `telnumber`, `address`, `pass`) VALUES
(2, 'User', 'User', 'User', 'STUDENT', 'User', 'Use', 'User@gmail.com', 'User', 'User', '123'),
(3, 'A1234', 'ADMIN', 'haha', 'ADMIN', 'a111', 'e25', 'a111@gmail.com', '0213222222', '', 'A1234'),
(11, 'a663', 'maka', 'bala', 'STUDENT', 'a663', 'e25', 'a663@gmail.com', '3332214445', '', ''),
(14, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(15, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(16, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(17, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(18, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(19, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(20, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(21, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(22, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(23, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(24, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(25, 'b6020500373', 'Baicha JENJOBVITTAYA', '', 'STUDENT', '', '', '', '', '', 'Abc%2542'),
(26, 'b6020500373', 'Baicha JENJOBVITTAYA', '', 'STUDENT', '', '', '', '', '', 'Abc%2542'),
(27, 'b5920502142', 'Sukrit TABSON', '', 'STUDENT', '', '', '', '', '', 'P@0888357506'),
(28, 'admin', 'admin', 'admin', 'ADMIN', NULL, NULL, 'admin@admin.com', 'admin', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingId`),
  ADD KEY `userId` (`borrowerId`),
  ADD KEY `userId_2` (`borrowerId`),
  ADD KEY `lenderId` (`lenderId`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryId`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`commentId`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `detailBooking`
--
ALTER TABLE `detailBooking`
  ADD PRIMARY KEY (`detailBookingId`),
  ADD KEY `bookingID` (`bookingID`),
  ADD KEY `deviceId` (`deviceId`);

--
-- Indexes for table `detaildevice`
--
ALTER TABLE `detaildevice`
  ADD PRIMARY KEY (`detailDeviceId`);

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`deviceId`);

--
-- Indexes for table `reception`
--
ALTER TABLE `reception`
  ADD PRIMARY KEY (`receptionId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `categoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `commentId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `detailBooking`
--
ALTER TABLE `detailBooking`
  MODIFY `detailBookingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `detaildevice`
--
ALTER TABLE `detaildevice`
  MODIFY `detailDeviceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `device`
--
ALTER TABLE `device`
  MODIFY `deviceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `reception`
--
ALTER TABLE `reception`
  MODIFY `receptionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`borrowerId`) REFERENCES `user` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`lenderId`) REFERENCES `user` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `detailBooking`
--
ALTER TABLE `detailBooking`
  ADD CONSTRAINT `detailBooking_ibfk_1` FOREIGN KEY (`deviceId`) REFERENCES `device` (`deviceId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detailBooking_ibfk_2` FOREIGN KEY (`bookingID`) REFERENCES `booking` (`bookingId`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
