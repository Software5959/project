<<!DOCTYPE html>
<?php
session_start();

if(isset($_GET['controller'])&&isset($_GET['action'])){
    $controller = $_GET['controller'];
    $action = $_GET['action'];
}
else{
    $controller = 'pages';
    $action = 'home';
}

if (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 1) {
    $ldap_uid = $_SESSION["ldap_uid"];
    $ldap_engname = $_SESSION["ldap_engname"];
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_email = $_SESSION["ldap_email"];
    $ldap_gender = $_SESSION["ldap_gender"];
    $ldap_Job = $_SESSION["ldap_Job"];
    $ldap_position = $_SESSION["ldap_position"];
    $ldap_department = $_SESSION["ldap_department"];
    $ldap_faculty = $_SESSION["ldap_faculty"];
    $ldap_campus = $_SESSION["ldap_campus"];
    $ldap_Status = $_SESSION["ldap_Status"];
    $ldap_idcode = $_SESSION["ldap_idcode"];
    echo "<script>console.log('id $ldap_uid')</script>";
    echo "<script>console.log('thainame $ldap_thainame')</script>";
    echo "<script>console.log('engname $ldap_engname')</script>";
    echo "<script>console.log('status $ldap_Status')</script>";
} elseif (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 2) {
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_Status = $_SESSION["ldap_Status"];
}else{
    header('http://158.108.207.4/se62_15/StarAdmin/index.php');
}
?>
<html lang="en">

<head>
    <title>ระบบยืม-คืนอุปกรณ์ มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน</title>
    <?php include "header.php"?>
</head>
<body>
<div class="container-scroller">
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-menu-wrapper d-flex align-items-center">
            <?php include "ออกจากระบบ.php" ?>
        </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <ul class="nav">
                <li class="nav-item nav-profile">
                    <div class="nav-link">
                        <div class="user-wrapper">
                            <div class="profile-image">
                                <img src="images/faces/face1.jpg" alt="profile image">
                            </div>
                            <div class="text-wrapper">
                                <p class="profile-name"><?php print ($ldap_thainame);?><br></p>
                                <div>
                                    <small class="designation text-muted">Manager</small>
                                    <span class="status-indicator online"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index1.php">
                        <i class="menu-icon mdi mdi-television"></i>
                        <span class="menu-title">หน้าหลัก</span>
                    </a>
                </li>
                
                <li class="nav-item" style="background-color:#a3edc8">
                    <a   class="nav-link">

                        <i class="menu-icon mdi mdi-television" ></i>
                        <span class="menu-title" >อุปกรณ์</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="รายการอุปกรณ์ทั้งหมด.php">
                        <i class="menu-icon mdi mdi-television"></i>
                        <span class="menu-title">รายการอุปกรณ์ทั้งหมด</span>
                        <!--              <i class="menu-arrow"></i>-->
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="รายงานยืมคืน.php">
                        <i class="menu-icon mdi mdi-television"></i>
                        <span class="menu-title">รายงานยืม-คืน</span>
                        <!--              <i class="menu-arrow"></i>-->
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="รายงานยืมคืนของตนเอง.php">
                        <i class="menu-icon mdi mdi-television"></i>
                        <span class="menu-title">รายงานยืมคืนของตนเอง</span>
                        <!--              <i class="menu-arrow"></i>-->
                    </a>
                </li>
            </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel" >
            <div class="content-wrapper">
                <div class="row purchace-popup">
                    <div class="col-12">
                        <!--              <span class="d-block d-md-flex align-items-center">-->
                        <!--                <p>Like what you see? Check out our premium version for more.</p>-->
                        <!--                <a class="btn ml-auto download-button d-none d-md-block" href="https://github.com/BootstrapDash/StarAdmin-Free-Bootstrap-Admin-Template" target="_blank">Download Free Version</a>-->
                        <!--                <a class="btn purchase-button mt-4 mt-md-0" href="https://www.bootstrapdash.com/product/star-admin-pro/" target="_blank">Upgrade To Pro</a>-->
                        <!--                <i class="mdi mdi-close popup-dismiss d-none d-md-block"></i>-->
                        <!--              </span>-->
                    </div>
                </div>


                <div class="row" align="center" >

                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
                        <div class="card card-statistics"style="background-color: #1da1f2">
                            <div class="card-body">
                                <div class="clearfix">
                                    <div >
                                        <a class="nav-link" >
                                            <font color="#f0f8ff" size="4"> <span class="menu-title">รายละเอียดอุปกรณ์</span></font>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--            -->
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
                        <div class="card card-statistics"style="background-color:#a3edc8">
                            <div class="card-body">
                                <div class="clearfix">
                                    <div >
                                        <a class="nav-link" href="เพิ่มอุปกรณ์.php">
                                            <font color="#f0f8ff" size="4"> <span class="menu-title">เพิ่มอุปกรณ์</span></font>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--            -->
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
                        <div class="card card-statistics"style="background-color:#a3edc8">
                            <div class="card-body">
                                <div class="clearfix">
                                    <div >
                                        <a class="nav-link" href="แก้ไขอุปกรณ์.php">
                                            <font color="#f0f8ff" size="4"><span class="menu-title">แก้ไขอุปกรณ์</span></font>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
                        <div class="card card-statistics"style="background-color:#a3edc8">
                            <div class="card-body">
                                <div class="clearfix">
                                    <div >
                                        <a class="nav-link" href="php">
                                            <font color="#f0f8ff" size="4"><span class="menu-title" size="">ลบอุปกรณ์</span></font>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--            -->
                    <!--          -->
                    <div class="row">
                        <div class="col-lg-7 grid-margin stretch-card">


                            <!--weather card-->
                            <!--              <div class="card card-weather">-->
                            <!--                <div class="card-body">-->
                            <!--                  <div class="weather-date-location">-->
                            <!--                    <h3>Monday</h3>-->
                            <!--                    <p class="text-gray">-->
                            <!--                      <span class="weather-date">25 October, 2016</span>-->
                            <!--                      <span class="weather-location">London, UK</span>-->
                            <!--                    </p>-->
                            <!--                  </div>-->
                            <!--                  <div class="weather-data d-flex">-->
                            <!--                    <div class="mr-auto">-->
                            <!--                      <h4 class="display-3">21-->
                            <!--                        <span class="symbol">&deg;</span>C</h4>-->
                            <!--                      <p>-->
                            <!--                        Mostly Cloudy-->
                            <!--                      </p>-->
                            <!--                    </div>-->
                            <!--                  </div>-->
                            <!--                </div>-->
                            <!--                <div class="card-body p-0">-->
                            <!--                  <div class="d-flex weakly-weather">-->
                            <!--                    <div class="weakly-weather-item">-->
                            <!--                      <p class="mb-0">-->
                            <!--                        Sun-->
                            <!--                      </p>-->
                            <!--                      <i class="mdi mdi-weather-cloudy"></i>-->
                            <!--                      <p class="mb-0">-->
                            <!--                        30°-->
                            <!--                      </p>-->
                            <!--                    </div>-->
                            <!--                    <div class="weakly-weather-item">-->
                            <!--                      <p class="mb-1">-->
                            <!--                        Mon-->
                            <!--                      </p>-->
                            <!--                      <i class="mdi mdi-weather-hail"></i>-->
                            <!--                      <p class="mb-0">-->
                            <!--                        31°-->
                            <!--                      </p>-->
                            <!--                    </div>-->
                            <!--                    <div class="weakly-weather-item">-->
                            <!--                      <p class="mb-1">-->
                            <!--                        Tue-->
                            <!--                      </p>-->
                            <!--                      <i class="mdi mdi-weather-partlycloudy"></i>-->
                            <!--                      <p class="mb-0">-->
                            <!--                        28°-->
                            <!--                      </p>-->
                            <!--                    </div>-->
                            <!--                    <div class="weakly-weather-item">-->
                            <!--                      <p class="mb-1">-->
                            <!--                        Wed-->
                            <!--                      </p>-->
                            <!--                      <i class="mdi mdi-weather-pouring"></i>-->
                            <!--                      <p class="mb-0">-->
                            <!--                        30°-->
                            <!--                      </p>-->
                            <!--                    </div>-->
                            <!--                    <div class="weakly-weather-item">-->
                            <!--                      <p class="mb-1">-->
                            <!--                        Thu-->
                            <!--                      </p>-->
                            <!--                      <i class="mdi mdi-weather-pouring"></i>-->
                            <!--                      <p class="mb-0">-->
                            <!--                        29°-->
                            <!--                      </p>-->
                            <!--                    </div>-->
                            <!--                    <div class="weakly-weather-item">-->
                            <!--                      <p class="mb-1">-->
                            <!--                        Fri-->
                            <!--                      </p>-->
                            <!--                      <i class="mdi mdi-weather-snowy-rainy"></i>-->
                            <!--                      <p class="mb-0">-->
                            <!--                        31°-->
                            <!--                      </p>-->
                            <!--                    </div>-->
                            <!--                    <div class="weakly-weather-item">-->
                            <!--                      <p class="mb-1">-->
                            <!--                        Sat-->
                            <!--                      </p>-->
                            <!--                      <i class="mdi mdi-weather-snowy"></i>-->
                            <!--                      <p class="mb-0">-->
                            <!--                        32°-->
                            <!--                      </p>-->
                            <!--                    </div>-->
                            <!--                  </div>-->
                            <!--                </div>-->
                            <!--              </div>-->
                            <!--weather card ends-->
                        </div>
                        <!--            <div class="col-lg-5 grid-margin stretch-card">-->
                        <!--              <div class="card">-->
                        <!--                <div class="card-body">-->
                        <!--                  <h2 class="card-title text-primary mb-5">Performance History</h2>-->
                        <!--                  <div class="wrapper d-flex justify-content-between">-->
                        <!--                    <div class="side-left">-->
                        <!--                      <p class="mb-2">The best performance</p>-->
                        <!--                      <p class="display-3 mb-4 font-weight-light">+45.2%</p>-->
                        <!--                    </div>-->
                        <!--                    <div class="side-right">-->
                        <!--                      <small class="text-muted">2017</small>-->
                        <!--                    </div>-->
                        <!--                  </div>-->
                        <!--                  <div class="wrapper d-flex justify-content-between">-->
                        <!--                    <div class="side-left">-->
                        <!--                      <p class="mb-2">Worst performance</p>-->
                        <!--                      <p class="display-3 mb-5 font-weight-light">-35.3%</p>-->
                        <!--                    </div>-->
                        <!--                    <div class="side-right">-->
                        <!--                      <small class="text-muted">2015</small>-->
                        <!--                    </div>-->
                        <!--                  </div>-->
                        <!--                  <div class="wrapper">-->
                        <!--                    <div class="d-flex justify-content-between">-->
                        <!--                      <p class="mb-2">Sales</p>-->
                        <!--                      <p class="mb-2 text-primary">88%</p>-->
                        <!--                    </div>-->
                        <!--                    <div class="progress">-->
                        <!--                      <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated" role="progressbar" style="width: 88%" aria-valuenow="88"-->
                        <!--                        aria-valuemin="0" aria-valuemax="100"></div>-->
                        <!--                    </div>-->
                        <!--                  </div>-->
                        <!--                  <div class="wrapper mt-4">-->
                        <!--                    <div class="d-flex justify-content-between">-->
                        <!--                      <p class="mb-2">Visits</p>-->
                        <!--                      <p class="mb-2 text-success">56%</p>-->
                        <!--                    </div>-->
                        <!--                    <div class="progress">-->
                        <!--                      <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" role="progressbar" style="width: 56%" aria-valuenow="56"-->
                        <!--                        aria-valuemin="0" aria-valuemax="100"></div>-->
                        <!--                    </div>-->
                        <!--                  </div>-->
                        <!--                </div>-->
                        <!--              </div>-->
                        <!--            </div>-->
                    </div>
                    <!--          <div class="row">-->
                    <!--            <div class="col-md-12 grid-margin">-->
                    <!--              <div class="card">-->
                    <!--                <div class="card-body">-->
                    <!--                  <div class="row d-none d-sm-flex mb-4">-->
                    <!--                    <div class="col-4">-->
                    <!--                      <h5 class="text-primary">Unique Visitors</h5>-->
                    <!--                      <p>34657</p>-->
                    <!--                    </div>-->
                    <!--                    <div class="col-4">-->
                    <!--                      <h5 class="text-primary">Bounce Rate</h5>-->
                    <!--                      <p>45673</p>-->
                    <!--                    </div>-->
                    <!--                    <div class="col-4">-->
                    <!--                      <h5 class="text-primary">Active session</h5>-->
                    <!--                      <p>45673</p>-->
                    <!--                    </div>-->
                    <!--                  </div>-->
                    <!--                  <div class="chart-container">-->
                    <!--                    <canvas id="dashboard-area-chart" height="80"></canvas>-->
                    <!--                  </div>-->
                    <!--                </div>-->
                    <!--              </div>-->
                    <!--            </div>-->
                </div>
                <div class="row">
                    <div class="col-lg-12 grid-margin">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <div class="card shadow mb-4">
                                            <div class="card-header py-3">
                                                <center><h6 class="h5 m-0 font-weight-bold text-primary">รายการอุปกรณ์ทที่สามมารถยืมได้</h6></center>
                                            </div>
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                                        <colgroup>
                                                            <col  width="20">
                                                            <col  width="20">
                                                            <col  width="20">
                                                            <col  width="20">
                                                            <col  width="20">
                                                        </colgroup>

                                                        <thead>
                                                        <tr>
                                                            <th>รหัสรายการ</th>
                                                            <th>วันที่ยืม</th>
                                                            <th>จำนวนอุปกรณ์</th>
                                                            <th>อาจารย์ที่อนุมัติ</th>
                                                            <th>สถานะ</th>
                                                        </tr>
                                                        </thead>
                                                        <tfoot>
                                                        <tr>
                                                            <th>รหัสรายการ</th>
                                                            <th>วันที่ยืม</th>
                                                            <th>จำนวนอุปกรณ์</th>
                                                            <th>อาจารย์ที่อนุมัติ</th>
                                                            <th>สถานะ</th>
                                                        </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->

<!-- plugins:js -->
<script src="vendors/js/vendor.bundle.base.js"></script>
<script src="vendors/js/vendor.bundle.addons.js"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="js/off-canvas.js"></script>
<script src="js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="js/dashboard.js"></script>
<!-- End custom js for this page-->
</body>

</html>