<?php
class WorkController {

    public function handleRequest(string $action="index", array $params=null) {
        switch ($action) {
            case "index":
                $this->index();
                break;
            case "showMyWork":
                $this->showMyWork();
                break;
            case  "AddWork":
                $team_id = $params["POST"]["team_id"]??"";
                $date = $params["POST"]["date"]??"";
                $topic = $params["POST"]["topic"]??"";
                $status = $params["POST"]["status"]??"";
                $chooseMember = $params["POST"]["chooseMember"]??null;
                $detail = $params["POST"]["detail"]??"";
                if ($team_id !== "" && $date !== "" && $topic !== ""&& $status !== "") {
                    $this->AddWork($team_id,$date,$topic,$status,$detail,$chooseMember);
                }
                break;
            case "receiveWork":
                $work_id = $params["GET"]["work_id"]??"";
                if($work_id !== ""){
                    $this->receiveWork($work_id);
                }
                break;
            case "sendFile":
                $work_id = $params["POST"]["work_id"]??"";
                $fileName = $params["FILES"]["inputFile"]["name"]??"";
                $pathUpload = $params["FILES"]["inputFile"]["tmp_name"]??"";
                if($work_id !== "" && $fileName !== "" && $pathUpload !==""){
                    $this->sendFile($work_id,$fileName,$pathUpload);
                }
                break;
            case "accept":
                $work_id = $params["GET"]["work_id"]??"";
                if($work_id !== "")
                {
                    $this->accept($work_id);
                }
                break;
            case  "modify":
                $work_id = $params["GET"]["work_id"]??"";
                if($work_id !== "")
                {
                    $this->modify($work_id);
                }
                break;
            case  "cancel":
                $work_id = $params["GET"]["work_id"]??"";
                if($work_id !== "")
                {
                    $this->cancel($work_id);
                }
                break;
            case "offNotify":
                $notify_id = $params["POST"]["id"]??"";
                if($notify_id != "") {
                    $this->offNotify($notify_id);
                }
                break;
            default:
                break;
        }
    }
    private function index() {

    }
    //Ajax
    private function offNotify(int $notify_id){
        $notify = NotifyHistory::findById($notify_id);
        $notify->setNotify("TRUE");
        $notify->update();
        echo "{\"team_id\":{$notify->getTeamId()},\"work_id\":{$notify->getWorkId()}}";
    }
    private function cancel(int $work_id){
        session_start();
        $member = $_SESSION['member'];
        $teamList = Team::getTeamByMember($member->getMemId());
        $work = Work::findById($work_id);
        foreach ($teamList as $team_id => $team) {
            if($work->getTeamId()==$team->getTeamId()){
                $work->delete();
                break;
            }
        }
        header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showTeamManager");
    }
    private function modify(int $work_id){
        session_start();
        $member = $_SESSION['member'];
        $teamList = Team::getTeamByMember($member->getMemId());
        $work = Work::findById($work_id);
        foreach ($teamList as $team_id => $team) {
            if($work->getTeamId()==$team->getTeamId()){
                $work->setStatusWork("modify");
                $work->update();
                break;
            }
        }
        header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showTeamManager");
    }
    private function accept(int $work_id){
        session_start();
        $member = $_SESSION['member'];
        $teamList = Team::getTeamByMember($member->getMemId());
        $work = Work::findById($work_id);
        if(date("A")=="PM"){
            $date = (date("h")+12).date(":i:s");
            if(date("h")==12){
                $date = (date("h")-12).date(":i:s");
            }
        }else {
            $date = date("h:i:s");
            if(date("h")==12){
                $date = (date("h")-12).date(":i:s");
            }
        }
        foreach ($teamList as $team_id => $team) {
            if($work->getTeamId()==$team->getTeamId()){
                $work->setCompleteDate(date("Y-m-d"));
                $work->setCompleteTime($date);
                $work->setStatusWork("finish");
                $work->update();
                break;
            }
        }
        header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showTeamManager");
    }
    private function sendFile(int $work_id,string $fileName,string $pathUpload)
    {
        session_start();
        $member = $_SESSION['member'];
        $work = Work::findById($work_id);
        if(isset($work)) {
            $path = Router::getSourcePath() . "fileUpload/".$work->getWorkerId().$fileName;
            move_uploaded_file($pathUpload, $path);
            if(date("A")=="PM"){
                $date = (date("h")+12).date(":i:s");
                if(date("h")==12){
                    $date = (date("h")-12).date(":i:s");
                }
            }else {
                $date = date("h:i:s");
                if(date("h")==12){
                    $date = (date("h")-12).date(":i:s");
                }
            }
            $work->setStatusWork("delivered");
            $work->setFile($path);
            $work->setSendDate(date("Y-m-d"));
            $work->setSendTime($date);
            $work->update();
            require_once Router::getSourcePath().'inc/helper_func.inc.php';
            $team = Team::findById($work->getTeamId());
            $teamMember = TeamMember::findById($work->getManagerId());
            $mem = Member::findById($teamMember->getMemId());
            emailToManager($mem->getEmail(),$team->getName(),$member->getUsername(),$work->getTopic(),$work->getDetail());

        }
        header("Location: ".Router::getSourcePath()."index.php?controller=Work&action=showMyWork");
    }
    private function receiveWork(int $work_id)
    {
        session_start();
        $member = $_SESSION['member'];
        $work = Work::findById($work_id);

        $teamMember = TeamMember::getTeamMemberByTeam($work->getTeamId());
        foreach ($teamMember as $teamWork_id => $obj)
        {
            if($member->getMemId()==$obj->getMemId()) {
                $work->setWorkerId($obj->getTeamworkId());
                $work->setStatusWork("process");
                $work->update();

                $notify = NotifyHistory::getNotifyHistoryByTeamOrWork($work->getTeamId(),$work_id);
                foreach ($notify as $id => $obj){
                    $obj->delete();
                }
                break;
            }
        }
       header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showTeamWorker");
    }
    private function AddWork(int $team_id,string $dateEnd,string $topic,string $status,string $detail,string $chooseMember=null)
    {
        session_start();
        $member = $_SESSION['member'];
        $work = new Work();
        $work->setTeamId($team_id);
        $work->setTopic($topic);
        $work->setDetail($detail);
        if(date("A")=="PM"){
            $date = (date("h")+12).date(":i:s");
        }else {
            $date = date("h:i:s");
        }
        $work->setStartDate(date("Y-m-d"));
        $work->setStartTime($date);
        $work->setEndDate($dateEnd);
        $work->setEndTime("00:00:00");
        $teamMember = TeamMember::getTeamMemberByTeam($team_id);
        $teamMember_id = NULL;
        foreach ($teamMember as $id => $obj){
            if($obj->getMemId()==$member->getMemId()){
                $teamMember_id = $obj->getTeamworkId();
            }
        }
        $work->setManagerId($teamMember_id);

        if($status=="public"){
            $work->setStatusPublic($status);
            $work->setStatusWork('waiting');
            $work->setNotifyWork("FALSE");
            $work->insert();
            $teamMember = TeamMember::getTeamMemberByTeam($team_id);
            $notify = new NotifyHistory();
            foreach ($teamMember as $teamMember_id => $obj)
            {
                $notify->setNotifyDate(date("Y-m-d"));
                $notify->setNotifyTime($date);
                $notify->setTeamId($team_id);
                $notify->setWorkId($work->getWorkId());
                $notify->setTeamworkId($teamMember_id);
                $notify->setNotify("FALSE");
                $notify->insert();
                $notify->setNotifyHistoryId(NULL);
            }
        }else if($status=="private"&&!empty($chooseMember)){
            $work->setStatusPublic($status);
            $work->setStatusWork('process');
            $teamMember = TeamMember::getTeamMemberByTeam($team_id);
            foreach ($teamMember as $teamMember_id => $obj ) {
                if ($obj->getMemId() == $chooseMember) {
                    $work->setWorkerId($obj->getTeamworkId());
                    $work->setNotifyWork("FALSE");
                    $work->insert();
                    require_once './inc/helper_func.inc.php';
                    $team = Team::findById($team_id);
                    $mem = Member::findById($obj->getMemId());
                    emailToWorker($mem->getEmail(),$team->getName(),$member->getUsername(),$work->getTopic(),$work->getDetail());
                    break;
                }
            }
        }
        header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showTeamManager");
    }
    private function showMyWork()
    {
        session_start();
        $member = $_SESSION['member'];
        if ($member->getPermission()=="user") {
            $allWorkList = Work::getWorkByMember($member->getMemId(), 'worker');
            $member_AllWorkList = array();
            foreach ($allWorkList as $work) {
                $member_AllWorkList[$work->getManagerId()] = Member::getMemberByTeamMember($work->getManagerId());
            }
            $teamList = Team::getTeamByMember($member->getMemId(),'worker');
            $memberListByTeamList = array();
            foreach ($teamList as $team_id => $value)
            {
                $memberListByTeamList[$team_id] = Member::getMemberByTeam($team_id,'manager');
                $teamMemberByTeamList[$team_id] = TeamMember::getTeamMemberByTeam($team_id);
            }
            $numListByTeamNotifyList = NotifyHistory::getNotifyNumberByMember($member->getMemId());
            foreach ($numListByTeamNotifyList as $team_id => $num) {
                $notifyHistoryListByTeamList[$team_id] = NotifyHistory::getNotifyHistoryByMemberOrTeam($member->getMemId(), $team_id);
            }
            $notifyHistoryListByMember = NotifyHistory::getNotifyHistoryByMemberOrTeam($member->getMemId());


            include Router::getSourcePath() . "views/member/myWork.inc.php";
        }
    }
}