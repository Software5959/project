<?php
class TeamController {

    public function handleRequest(string $action="index", array $params=null) {
        switch ($action) {
            case "index":
                $this->index();
                break;
            case "showTeamWorker":
                $this->showTeamWorker();
                break;
            case "showTeamManager":
                $this->showTeamManager();
                break;
            case "showCreateTeam":
                $this->showCreateTeam();
                break;
            case "selectPer":
                $memID = $params['POST']['multimem'];
                $teamname = $params['POST']['teamname'];
                $this->selectPer($memID, $teamname);
                break;
            case "create":
                for($i=1;$i<=count($params['POST']);$i++){
                    $status[$i] =  $params['POST']['radio'.$i];
                }
                $this->create($status);
                break;
            case "add":
                $memID = $params['POST']['multiadd'];
                $this->add($memID);
                break;
            case "add2":
                $memID = $params['POST']['multiadd2'];
                $this->add2($memID);
                break;
            case "showDetailAllTeam":
                $status = $params["GET"]["status"]??"";
                if($status != ""){
                    $this->showDetailAllTeam($status);
                }
                break;
            case "showDetailTeam":
                $team_id =$params["GET"]["team_id"]??"";
                if($team_id !=""){
                    $this->showDetailTeam($team_id);
                }
                break;
            case "changeStatus":
                $teamMember_id = $params["POST"]["id"]??"";
                if($teamMember_id != "") {
                    $this->changeStatus($teamMember_id);
                }
                break;
            case "outTeam":
                $teamMember_id = $params["POST"]["teamMember_id"];
                if($teamMember_id != ""){
                    $this->outTeam($teamMember_id);
                }
                break;
            case "outTeamMe":
                $teamMember_id = $params["POST"]["teamMember_id"]??"";
                if($teamMember_id != ""){
                    $this->outTeamMe($teamMember_id);
                }
                break;
            case "deleteTeam":
                $teamMember_id = $params["POST"]["teamMember_id"]??"";
                if($teamMember_id != ""){
                    $this->deleteTeam($teamMember_id);
                }
                break;
            case "statistic":
                session_start();
                $dateStart = $params["POST"]["dateStart"]??"";
                $dateEnd = $params["POST"]["dateEnd"]??"";
                $this->statistic($dateStart,$dateEnd,$_SESSION['thisTeam'],($_SESSION['member'])->getMemId());//$managerID
                break;
            case "offNotifyStatusHistory":
                $this->offNotifyStatusHistory();
                break;
            case "getStatusHistory":
                $this->getStatusHistory();
                break;
            case "getNumStatusHistory":
                $this->getNumStatusHistory();
                break;
            case "getNotifyWorker":
                $this->getNotifyWorker();
                break;
            default:
                break;
        }
    }
    private function index() {

    }
    private function getNotifyWorker(){

        session_start();
        $member = $_SESSION['member'];
        $count = 0;
        $notifyHistoryListByMember = NotifyHistory::getNotifyHistoryByMemberOrTeam($member->getMemId());
        foreach ($notifyHistoryListByMember as $notify_id => $notify) {
            if ("FALSE" == $notify->getNotify()) {
                $count++;
            }
        }
        echo $count;
    }
    private function getNumStatusHistory(){
        session_start();
        $member = $_SESSION['member'];
        if (!empty($member)) {
            $statusHistoryList = StatusHistory::getStatusHistoryByMember($member->getMemId());
            $teamOfStatusHistoryList = array();
            $memberOfStatusHistoryList = array();
            foreach ($statusHistoryList as $id => $obj) {
                $teamOfStatusHistoryList[$id] = Team::findById($obj->getTeamId());
                $memberOfStatusHistoryList[$id] = Member::findById($obj->getMemId());
            }
            if (isset($statusHistoryList) && !empty($statusHistoryList)) {
                $count = 0;
                require_once Router::getSourcePath() . 'inc/helper_func.inc.php';
                foreach ($statusHistoryList as $id => $obj) {
                    if (!empty($teamOfStatusHistoryList[$id]) && !empty($memberOfStatusHistoryList[$id])) {
                        if ($obj->getNotify() == "FALSE") {
                            $count++;
                        }
                    }
                }
            }
            echo $count;
        }
    }
    private function getStatusHistory()
    {
        session_start();
        $member = $_SESSION['member'];
        if (!empty($member)) {
            $statusHistoryList = StatusHistory::getStatusHistoryByMember($member->getMemId());
            $teamOfStatusHistoryList = array();
            $memberOfStatusHistoryList = array();
            foreach ($statusHistoryList as $id => $obj) {
                $teamOfStatusHistoryList[$id] = Team::findById($obj->getTeamId());
                $memberOfStatusHistoryList[$id] = Member::findById($obj->getMemId());
            }
            echo "<div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
                        <center><h3>แจ้งเตือน</h3></center>
                        <div class=\"dropdown-divider\"></div>
                        <div class=\"scrollBar\" style=\"max-height: 680px; overflow: hidden; overflow-y: auto;\">";
            if (isset($statusHistoryList) && !empty($statusHistoryList)) {
                $count = 0;
                require_once Router::getSourcePath() . 'inc/helper_func.inc.php';
                foreach ($statusHistoryList as $id => $obj) {
                    if (!empty($teamOfStatusHistoryList[$id]) && !empty($memberOfStatusHistoryList[$id])) {
                        if ($obj->getNotify() == "FALSE") {
                            $count++;
                        }
                        $endDateTime = new DateTime($obj->getBeginDate() . " " . $obj->getBeginTime());
                        $interval = calculatePeriodOfTime($endDateTime);
                        if($obj->getStatusId()==2){
                            if($obj->getNotify()=="FALSE"){
                                echo "<a class=\"dropdown-item\" style='background-color: aliceblue; border-color: red;'>";
                            }else {
                                echo "<a class=\"dropdown-item\" style='background-color: white; border-color: red;'>";
                            }
                            $str = "กลุ่ม {$teamOfStatusHistoryList[$id]->getName()} คุณถูกเปลี่ยนสถานะเป็นผู้รับงาน";
                            //$str = substr($str,0,120)."...";
                            echo "<h6>$str</h6>
                                      โดย {$memberOfStatusHistoryList[$id]->getUsername()}<br/>
                                     <i class=\"far fa-clock fa-xs\"> {$interval}</i>
                                     <hr style='width: 100%'>                                               
                                     </a> ";
                        }else if($obj->getStatusId()==3){
                            if($obj->getNotify()=="FALSE"){
                                echo "<a class=\"dropdown-item\" style='background-color: aliceblue; border-color: red;'>";
                            }else {
                                echo "<a class=\"dropdown-item\" style='background-color: white; border-color: red;'>";
                            }
                            $str = "กลุ่ม {$teamOfStatusHistoryList[$id]->getName()} คุณถูกเปลี่ยนสถานะเป็นผู้สั่งงาน";
                            //$str = substr($str,0,120)."...";
                            echo "<h6>$str</h6>
                                      โดย {$memberOfStatusHistoryList[$id]->getUsername()}<br/>
                                     <i class=\"far fa-clock fa-xs\"> {$interval}</i>
                                     <hr style='width: 100%'>                                              
                                                 </a>  ";
                        }else if($obj->getStatusId()==1){
                            if($obj->getNotify()=="FALSE"){
                                echo "<a class=\"dropdown-item\" style='background-color: aliceblue; border-color: red;'>";
                            }else {
                                echo "<a class=\"dropdown-item\" style='background-color: white; border-color: red;'>";
                            }
                            $str = "คุณถูกดึงเข้าร่วมกลุ่ม {$teamOfStatusHistoryList[$id]->getName()}";
                            //$str = substr($str,0,120)."...";
                            echo "<h6>$str</h6>
                                      โดย {$memberOfStatusHistoryList[$id]->getUsername()}<br/>
                                     <i class=\"far fa-clock fa-xs\"> {$interval}</i>
                                     <hr style='width: 100%'>                                                
                                     </a>";
                        }
                    }
                }
            } else {
                echo "<div class=\"dropdown-item\" >
                                                <h6>ไม่มีประวัติการแจ้งเตือน</h6>
                                                 </div>";
            }
            echo "</div>
                        <a class=\"dropdown-item\" href=\"#\">
                            แสดงการแจ้งเตือนทั้งหมด
                        </a>
                    </div>";
            $count = $count??null;
            echo "<input id=\"numNotifyStatusHistoryCount\" type=\"hidden\" value=\"$count\" >";
        }
    }
    private function offNotifyStatusHistory(){
        session_start();
        $member = $_SESSION["member"]??null;
        if(!empty($member)){
            $statusHistoryList = StatusHistory::getStatusHistoryByMember($member->getMemId());
            foreach ($statusHistoryList as $id => $obj){
                $obj->setNotify("TRUE");
                $obj->update();
            }
            echo 1;
        }
    }
    private function deleteTeam(int $teamMember_id){
        session_start();
        $member = $_SESSION['member'];
        if(isset($member)) {
            $teamMember = TeamMember::findById($teamMember_id);
            $team = Team::findById($teamMember->getTeamId());
            if($member->getMemId()==$team->getHead()){
                $teamMemberList = TeamMember::getTeamMemberByTeam($team->getTeamId());
                foreach ($teamMemberList as $id => $teamMember) {
                    if ($teamMember->getMemId() != $member->getMemId()) {
                        $target = Member::findById($teamMember->getMemId());
                        require_once Router::getSourcePath() . 'inc/helper_func.inc.php';
                        EmailDeleteTeam($target->getEmail(), $team->getName(), $member->getUsername());
                    }
                    $teamMember->setStatusTeamWork("CLOSE");
                    $teamMember->update();
                }
                $team->setStatusTeam("CLOSE");
                $team->update();
            }
            header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showTeamManager");
        }
    }
    private function outTeamMe(int $teamMember_id){
        session_start();
        $member = $_SESSION['member'];
        if(isset($member)) {
            $teamMember = TeamMember::findById($teamMember_id);
            $team = Team::findById($teamMember->getTeamId());
            $workList = Work::getWorkByMember($teamMember->getMemId());
            if(!isset($workList)){
                $teamMember->setStatusTeamWork('CLOSE');
                $teamMember->update();
            }
            foreach ($workList as $work_id => $work) {
                if ($work->getTeamId() == $teamMember->getTeamId() && $work->getStatusWork() != "finish") {
                    if ($work->getManagerId() == $teamMember->getTeamworkId()) {
                        $emailTo = Member::getMemberByTeamMember($work->getWorkerId());
                    } else if ($work->getWorkerId() == $teamMember->getTeamworkId()) {
                        $emailTo = Member::getMemberByTeamMember($work->getManagerId());
                    } else {
                        $emailTo = NULL;
                    }
                    $team = Team::findById($work->getTeamId());
                    require_once Router::getSourcePath() . 'inc/helper_func.inc.php';
                    EmailOutTeam($emailTo->getEmail(), $team->getName(), $teamMember->getUsername(), $work->getTopic(), $work->getDetail());
                    $work->delete();

                    $teamMember->setStatusTeamWork('CLOSE');
                    $teamMember->update();
                }
            }
            header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showTeamWorker");
        }
    }
    private function outTeam($teamMember_id){
        session_start();
        $member = $_SESSION['member'];
        $teamMember = TeamMember::findById($teamMember_id);
        $team = Team::findById($teamMember->getTeamId());
        if($team->getHead()==$member->getMemId()) {
            $workList = Work::getWorkByMember($teamMember->getMemId());
            if (isset($workList)) {
                foreach ($workList as $work_id => $work) {
                    if ($work->getTeamId() == $teamMember->getTeamId() && $work->getStatusWork() != "finish") {
                        if ($work->getManagerId() == $teamMember->getTeamworkId()) {
                            $emailTo = Member::getMemberByTeamMember($work->getWorkerId());
                        } else if ($work->getWorkerId() == $teamMember->getTeamworkId()) {
                            $emailTo = Member::getMemberByTeamMember($work->getManagerId());
                        } else {
                            $emailTo = NULL;
                        }
                        $team = Team::findById($work->getTeamId());
                        require_once Router::getSourcePath() . 'inc/helper_func.inc.php';
                        EmailOutTeam($emailTo->getEmail(), $team->getName(), $teamMember->getUsername(), $work->getTopic(), $work->getDetail(), $member->getUsername());
                        $work->delete();
                    }
                }
            }
            $teamMember->setStatusTeamWork('CLOSE');
            $teamMember->update();
        }
        header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showDetailTeam&team_id=".$teamMember->getTeamId());
    }
    //Ajax
    private function changeStatus(int $teamMember_id){
        session_start();
        $member = $_SESSION['member'];
        $teamMember = TeamMember::findById($teamMember_id);
        $statusHistoryList = StatusHistory::getStatusHistoryByTeamMember($teamMember->getTeamworkId());
        $status = new StatusHistory();
        $status->setTeamworkId($teamMember_id);
        if(date("A")=="PM"){
            $date = (date("h")+12).date(":i:s");
            if(date("h")==12){
                $date = (date("h")-12).date(":i:s");
            }
        }else {
            $date = date("h:i:s");
            if(date("h")==12){
                $date = (date("h")-12).date(":i:s");
            }
        }
        $status->setBeginDate(date("Y-m-d"));
        $status->setBeginTime($date);
        $teamMemberListMe = TeamMember::getTeamMemberByMember($member->getMemId());
        $team_id = NULL;
        foreach ($teamMemberListMe as $id => $obj){
            if($obj->getMemId()==$member->getMemId()){
                $team_id = $obj->getTeamId();
            }
        }
        $status->setTeamId($team_id);
        $status->setMemId($member->getMemId());

        foreach ($statusHistoryList as $statusHis_id => $statusHis){
            if($statusHis->getStatusId()=='2'){
                $status->setStatusId('3');
                $status->setNotify("FALSE");
                $status->insert();

                $workList = Work::getWorkByMember($teamMember->getMemId(),'worker');
                foreach ($workList as $work_id =>$work){
                    if($work->getTeamId()==$teamMember->getTeamId() && $work->getStatusWork()!="finish"&&$work->getStatusWork()!="waiting"){
                        $emailTo = Member::getMemberByTeamMember($work->getManagerId());
                        $team = Team::findById($work->getTeamId());
                        $memChange = Member::findById($teamMember->getMemId());
                        require_once Router::getSourcePath().'inc/helper_func.inc.php';
                        EmailChangeStatus($emailTo->getEmail(),$team->getName(),$member->getUsername(),$memChange->getUsername(),$work->getTopic(),$work->getDetail(),'manager');
                        $work->delete();
                    }
                }

                $teamMember->setStatus('manager');
                $teamMember->update();
            }else if($statusHis->getStatusId()=='3'){
                $status->setStatusId('2');
                $status->setNotify("FALSE");
                $status->insert();

                $workList = Work::getWorkByMember($teamMember->getMemId(),'manager');
                foreach ($workList as $work_id =>$work){
                    if($work->getTeamId()==$teamMember->getTeamId() && $work->getStatusWork()!="finish"){
                        if($work->getStatusWork()!="waiting"){
                            $emailTo = Member::getMemberByTeamMember($work->getWorkerId());
                            $team = Team::findById($work->getTeamId());
                            $memChange = Member::findById($teamMember->getMemId());
                            require_once Router::getSourcePath().'inc/helper_func.inc.php';
                            EmailChangeStatus($emailTo->getEmail(),$team->getName(),$member->getUsername(),$memChange->getUsername(),$work->getTopic(),$work->getDetail(),'worker');
                            $work->delete();
                        }else {
                            $work->delete();
                        }
                    }
                }
                $teamMember->setStatus('worker');
                $teamMember->update();
            }
            break;
        }
        echo $teamMember->getStatus();
    }
    private function showDetailTeam(int $team_id){
        session_start();
        $member = $_SESSION['member'];
        $team = Team::findById($team_id);
        $teamMemberList = TeamMember::getTeamMemberByTeam($team_id);
        foreach ($teamMemberList as $teamMember_id => $teamMember){
            $memberOfTeam[$teamMember->getMemId()] = Member::findById($teamMember->getMemId());
        }
        $head = Member::findById($team->getHead());
        $_SESSION['thisTeam']=$team_id;
        $_SESSION['addmem']= Member::findAdd($team_id);
        include Router::getSourcePath()."views/member/detailTeam.inc.php";
    }
    private function showDetailAllTeam(string $status){
        session_start();
        $member = $_SESSION['member'];
        if($status =="worker"){
            $teamL = Team::getTeamByMember($member->getMemId(),"worker");
            foreach ($teamL as $team_id => $team){
                $headL[$team_id] = Member::findById($team->getHead());
                $memberOfTeam[$team_id] = Member::getMemberByTeam($team->getTeamId(),"worker");
            }
            include Router::getSourcePath()."views/member/detailAllTeam.inc.php";
        }else if($status == "manager"){
            $teamL = Team::getTeamByMember($member->getMemId(),"manager");
            foreach ($teamL as $team_id => $team){
                $headL[$team_id] = Member::findById($team->getHead());
                $memberOfTeam[$team_id] = Member::getMemberByTeam($team->getTeamId(),"manager");
            }
            include Router::getSourcePath()."views/member/detailAllTeam.inc.php";
        }
    }
    private function showTeamWorker()
    {
        session_start();
        $member = $_SESSION['member'];
        if ($member->getPermission()=="user")
        {
            $allWorkList = Work::getWorkByMember($member->getMemId(),'worker','waiting');
            $member_AllWorkList = array();
            foreach ($allWorkList as $work)
            {
                $member_AllWorkList[$work->getManagerId()] = Member::getMemberByTeamMember($work->getManagerId());
            }
            $teamList = Team::getTeamByMember($member->getMemId(),'worker');

            $notifyHistoryListByMember = NotifyHistory::getNotifyHistoryByMemberOrTeam($member->getMemId());

            include Router::getSourcePath()."views/member/teamWorker.inc.php";
        }else {
            header("Location: ".Router::getSourcePath()."index.php?msg=invalid user");
        }
    }
    private function showTeamManager()
    {
        session_start();
        $member = $_SESSION['member'];
        if ($member->getPermission()=="user")
        {
            $allWorkList = Work::getWorkByMember($member->getMemId(),'manager');
            $allWorkListMe = array();
            $TeamMemberListMe = TeamMember::getTeamMemberByMember($member->getMemId());
            foreach ($allWorkList as $id =>$obj){
                foreach ($TeamMemberListMe as $teamMember_id => $teamMember){
                    if($teamMember->getTeamworkId()==$obj->getManagerId()){
                        $allWorkListMe[$id] = $obj;
                    }
                }
            }
            if(!empty($allWorkListMe)){
                $allWorkList = $allWorkListMe;
            }
            $member_AllWorkList = array();
            foreach ($allWorkList as $work)
            {
                $member_AllWorkList[$work->getManagerId()] = Member::getMemberByTeamMember($work->getManagerId());
            }
            $teamList = Team::getTeamByMember($member->getMemId(),'manager');
            $memberListByTeamList = array();
            foreach ($teamList as $team_id => $value)
            {
                $memberListByTeamList[$team_id] = Member::getMemberByTeam($team_id,'worker');
                $teamMemberByTeamList[$team_id] = TeamMember::getTeamMemberByTeam($team_id);
            }


            $numListByTeamNotifyList = NotifyHistory::getNotifyNumberByMember($member->getMemId());
            foreach($numListByTeamNotifyList as $team_id => $num)
            {
                $notifyHistoryListByTeamList[$team_id] = NotifyHistory::getNotifyHistoryByMemberOrTeam($member->getMemId(),$team_id);
            }
            $notifyHistoryListByMember = NotifyHistory::getNotifyHistoryByMemberOrTeam($member->getMemId());

            include Router::getSourcePath()."views/member/teamManager.inc.php";
        }else {
            header("Location: ".Router::getSourcePath()."index.php?msg=invalid user");
        }
    }
    private function showCreateTeam()
    {
        session_start();
        $member = $_SESSION['member'];
        $_SESSION['mem'] = Member::findCreate($member->getMemId());
        include Router::getSourcePath()."views/member/createTeam.inc.php";
    }
    private function selectPer(array $memID,string $teamname) {
        session_start();
        $memberselect[] =[];
        $i=0;
        foreach ($memID as $value){
            $memberselect[$i] = Member::findById($value)  ;
            $i++;
        }
        $_SESSION['memberselect'] = $memberselect;
        $_SESSION['teamname'] = $teamname;
        include Router::getSourcePath()."views/member/selectPermission.inc.php";
    }
    private function add($memID) {
        session_start();
        $member = $_SESSION['member'];
        foreach ($memID as $m) {
            $teammem = new TeamMember();
            $teammem->setTeamId($_SESSION['thisTeam']);
            $teammem->setMemId($m);
            $teammem->setStatus("worker");
            $teammem->setStatusDisplay("AUTO");
            $teammem->setStatusTeamWork("OPEN");
              $teammem->insert();

            $statusHistory = new StatusHistory();
            if(date("A")=="PM"){
                $date = (date("h")+12).date(":i:s");
                if(date("h")==12){
                    $date = (date("h")-12).date(":i:s");
                }
            }else {
                $date = date("h:i:s");
                if(date("h")==12){
                    $date = (date("h")-12).date(":i:s");
                }
            }
            $statusHistory->setBeginDate(date("Y-m-d"));
            $statusHistory->setBeginTime($date);
            $statusHistory->setTeamworkId($teammem->getTeamworkId());
            $statusHistory->setTeamId($teammem->getTeamId());
            $statusHistory->setMemId($member->getMemId());
            $statusHistory->setNotify("FALSE");
            $statusHistory->setStatusId(2);
            $statusHistory->insert();
        }
        $this->showDetailTeam($_SESSION['thisTeam']);
    }
    private function add2($memID) {
        session_start();
        $member = $_SESSION['member'];
        foreach ($memID as $m) {
            $teammem = new TeamMember();
            $teammem->setTeamId($_SESSION['thisTeam']);
            $teammem->setMemId($m);
            $teammem->setStatus("manager");
            $teammem->setStatusDisplay("AUTO");
            $teammem->setStatusTeamWork("OPEN");
            $teammem->insert();

            $statusHistory = new StatusHistory();
            if(date("A")=="PM"){
                $date = (date("h")+12).date(":i:s");
                if(date("h")==12){
                    $date = (date("h")-12).date(":i:s");
                }
            }else {
                $date = date("h:i:s");
                if(date("h")==12){
                    $date = (date("h")-12).date(":i:s");
                }
            }
            $statusHistory->setBeginDate(date("Y-m-d"));
            $statusHistory->setBeginTime($date);
            $statusHistory->setTeamworkId($teammem->getTeamworkId());
            $statusHistory->setTeamId($teammem->getTeamId());
            $statusHistory->setMemId($member->getMemId());
            $statusHistory->setNotify("FALSE");
            $statusHistory->setStatusId(3);
            $statusHistory->insert();
        }
        $this->showDetailTeam($_SESSION['thisTeam']);
    }
    private function create(array $status) {
        session_start();
        $member = $_SESSION['member'];
        $team = new Team();
        $team->setName($_SESSION['teamname']);
        if(date("A")=="PM"){
            $date = (date("h")+12).date(":i:s");
            if(date("h")==12){
                $date = (date("h")-12).date(":i:s");
            }
        }else {
            $date = date("h:i:s");
            if(date("h")==12){
                $date = (date("h")-12).date(":i:s");
            }
        }
        $team->setCreateDate(date("Y-m-d"));
        $team->setCreateTime($date);
        $team->setHead($member->getMemId());
        $team->setStatusTeam("OPEN");
        $team->insert();

        $memberselect = $_SESSION['memberselect'];
        //
        $teammem = new TeamMember();
        $teammem->setTeamId($team->getTeamId());
        $teammem->setMemId($member->getMemId());
        $teammem->setStatus("manager");
        $teammem->setStatusDisplay("AUTO");
        $teammem->setStatusTeamWork("OPEN");
        $teammem->insert();
        $i=1;
        foreach ($memberselect as $m){
            // $teammem = new Teammember($team->getTeamId(),$m->getMemId(),$status[$i++]);
            $teammem = new TeamMember();
            $teammem->setTeamId($team->getTeamId());
            $teammem->setMemId($m->getMemId());
            $teammem->setStatus($status[$i++]);
            $teammem->setStatusDisplay("AUTO");
            $teammem->setStatusTeamWork("OPEN");
            $teammem->insert();
            $statusHistory = new StatusHistory();
            if(date("A")=="PM"){
                $date = (date("h")+12).date(":i:s");
                if(date("h")==12){
                    $date = (date("h")-12).date(":i:s");
                }
            }else {
                $date = date("h:i:s");
                if(date("h")==12){
                    $date = (date("h")-12).date(":i:s");
                }
            }
            $statusHistory->setBeginDate(date("Y-m-d"));
            $statusHistory->setBeginTime($date);
            $statusHistory->setTeamworkId($teammem->getTeamworkId());
            $statusHistory->setTeamId($team->getTeamId());
            $statusHistory->setMemId($member->getMemId());
            $statusHistory->setNotify("FALSE");
            $statusType = Status::findAll();
            foreach ($statusType as $id => $obj){
                if($obj->getStatusType()==$teammem->getStatus()){
                    $statusHistory->setStatusId($obj->getStatusId());
                    break;
                }
            }
            $statusHistory->insert();
            $statusHistory->setStatusHistoryId(NULL);
            $statusHistory->setStatusId(1);
            $statusHistory->insert();
        }
        header("Location: ".Router::getSourcePath()."index.php?controller=Team&action=showTeamManager");
    }
    private function statistic($dateStart,$dateEnd,$teamID,$managerID) {
        session_start();
        $manager=TeamMember::getTeamMemberByMember($managerID);
        foreach ($manager as $m){
          if($m->getTeamId()==$teamID)
              $managerTeam = $m->getTeamworkId();
        }
        $_SESSION['countAll'] = Work::countAll($teamID,$managerTeam);
        $_SESSION['statistic'] = Work::statistic($teamID,$managerTeam);

        $_SESSION['countByDate'] = Work::countByDate($dateStart,$dateEnd,$teamID,$managerTeam);
        $_SESSION['statisticByDate'] = Work::statisticByDate($dateStart,$dateEnd,$teamID,$managerTeam);

        $_SESSION['statisticTable']=Work::statisticTable($teamID,$managerTeam);
        $_SESSION['statisticTableByDate']=Work::statisticTableByDate($dateStart,$dateEnd,$teamID,$managerTeam);

        include Router::getSourcePath()."views/member/statistic.inc.php";
    }
}