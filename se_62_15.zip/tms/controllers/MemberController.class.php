<?php
class MemberController {

    /**
     * handleRequest จะทำการตรวจสอบ action และพารามิเตอร์ที่ส่งเข้ามาจาก Router
     * แล้วทำการเรียกใช้เมธอดที่เหมาะสมเพื่อประมวลผลแล้วส่งผลลัพธ์กลับ
     *
     * @param string $action ชื่อ action ที่ผู้ใช้ต้องการทำ
     * @param array $params พารามิเตอร์ที่ใช้เพื่อในการทำ action หนึ่งๆ
     */
    public function handleRequest(string $action="index", array $params) {
        switch ($action) {
            case "index":
                $this->index();
                break;
            case "login":
                $username = $params["POST"]["username1"]??null;
                $pass = $params["POST"]["password1"]??null;
                if ($username != null && $pass != null) {
                    $this->login($username, $pass,$params);
                }
                break;
            case "showDetail":
                $this->showDetail();
                break;
            case "booking":
                $DeviceId = $params["POST"]["DeviceId"]??null;
                $numDevice = $params["POST"]["numDevice"]??null;
                $techer = $params["POST"]["techer"]??null;
                $this->booking($DeviceId,$numDevice,$techer);
                break;
            case "regis":

                $firstname = $params["POST"]["firstname"]??"";
                $lastname = $params["POST"]["lastname"]??"";
                $username = $params["POST"]["username"]??"";
                $password = $params["POST"]["password"]??"";
                $email = $params["POST"]["email"]??"";
                $permission = $params["POST"]["permission"]??"user";//
                $confirmpassword = $params["POST"]["confirmpassword"]??"";
                $this->regis($username,$password,$confirmpassword,$firstname,$lastname,$email,$permission);//
                break;
            case "delete":
                $memID=$params["POST"]["memID"]??"";
                $this->delete($memID);
                break;
            case "update":
                $memID=$params["POST"]["updateID"]??"";
                $firstname = $params["POST"]["name2"]??"";
                $lastname = $params["POST"]["surname2"]??"";
                $username = $params["POST"]["username2"]??"";
                $email = $params["POST"]["email2"]??"";
                $check = $params["POST"]["check"]??"";
                $permission = $params["POST"]["permission"]??"user";//
                $password = $params["POST"]["pass2"]??"";
                $this->update($memID ,$username ,$firstname ,$lastname , $email ,$permission,$password,$check);
                break;
            case "updateprofile":
                $memID=$params["POST"]["updateprofileID"]??"";
                $firstname = $params["POST"]["name3"]??"";
                $lastname = $params["POST"]["surname3"]??"";
                $password = $params["POST"]["password3"]??"";
                $username = $params["POST"]["user3"]??"";
                $email = $params["POST"]["email3"]??"";
                $permission = $params["POST"]["permission3"]??"";//
                $check = $params["POST"]["check3"]??"";
                $this->update($memID ,$username,$firstname ,$lastname , $email ,$permission,$password,$check);
                break;
            case "logout":
                $this->logout();
                break;
            case "forget":
                $email = $params["POST"]["email"]??"";
                $this->forget($email);
                break;
            default:
                break;
        }
    }
    // ควรมีสำหรับ controller ทุกตัว
    private function index() {
       

    }
    private function forget(string $email) {
        $ob = new Member();
        $checkemail = $ob->findByEmail($email);
        if ($checkemail == true )
        {
            require_once Router::getSourcePath() . 'inc/helper_func.inc.php';
            EmailForget($checkemail->getEmail(),$checkemail->getNumberStudent(),$checkemail->getPass(),$checkemail->getName(),$checkemail->getType());


        }
        else
        {
            echo  "no" ;
        }

    }
    private function showDetail(){
        session_start();
        $member = $_SESSION['member'];
        $Listbooking = booking::getBookingByMember($member->getUid());
        $ListDetailBooingByBooking = array();
        foreach ($Listbooking as $key => $value){
            if($value->getStatus()=="PENDING"){
                $ListDetailBooing = detailBooking::getDetailBookingByBooking($key);
                foreach ($ListDetailBooing as $key2 => $value2){
                    $ListDetailBooingByBooking[$key2] = $value2;
                }
            }
        }
        $ListDeviceByUser = array();
        foreach ($ListDetailBooingByBooking as $key => $value){
            $ListDeviceByUser[$key] = device::findById($value->getDeviceId());
        }
        include Router::getSourcePath()."รายงานยืมคืน.php";
    }
    private function booking($DeviceId,$numDevice,$techer){
        session_start();
        $member = $_SESSION['member'];
        $ob = new booking();
        $ob->setBorrowerId($member->getUid());
        $ob->setLenderId($techer);
        $ob->setStatus('PENDING');
        $ob->setDateStart(date("Y-m-d h:i:s"));
        //$ob->setDateEnd();
        //$ob->setDisapprovalReason();
        $ob->Insert();
        $bookingId = $ob->getBookingId();
        $dbooking = new detailBooking();
        $dbooking->setBookingID($bookingId);
        $dbooking->setDeviceId($DeviceId);
        $dbooking->setAmount($numDevice);
        $dbooking->setReceptionDate(date("Y-m-d h:i:s"));
        $dbooking->insert();


        $_SESSION['member'] = $member;
        $devices = device::findAll();
        $detailBookings = detailBooking::findAll();
        $numDevice = array();
        foreach ($devices as $key => $value){
            $numDevice[$key] = (int)($value->getNumber());
        }
        foreach ($detailBookings as $key => $value){
            if($value->getRevertingDate() == NULL){
                $numDevice[$value->getDeviceId()] -= $value->getAmount();
            }
        }
        foreach ($numDevice as $key => $value){
            if($value==0){
                unset($numDevice[$key]);
                unset($devices[$key]);
            }
        }
        $ListMember = Member::findAll();
        $ListAdmin = array();
        foreach ($ListMember as $key => $value){
            if($value->getType() == 'TEACHER'){
                $ListAdmin[$key] = $value;
            }
        }
        include Router::getSourcePath()."booking.inc.php";


    }
    private function login(string $username, string $password,array $params) {
        include 'inc/ldap.php';

        //login by user
        $ldap_authen_result = user_authen($username, $password);
        if($ldap_authen_result==0){
            session_start();
            $mem= Member::findByAccount($username,$password);
            if ($mem == null) {
                $mem = New Member();
                $mem->setUsername($username);
                $mem->setPass($password);
                $mem->setEmail($GLOBALS["ldap_email"]);
                $mem->setName($GLOBALS["ldap_engname"]);
                $mem->setType('STUDENT');
                $mem->insert();
            }
            $_SESSION['member'] = $mem;
            $devices = device::findAll();
            $detailBookings = detailBooking::findAll();
            $numDevice = array();
            foreach ($devices as $key => $value){
                $numDevice[$key] = (int)($value->getNumber());
            }
            foreach ($detailBookings as $key => $value){
                if($value->getRevertingDate() == NULL){
                    $numDevice[$value->getDeviceId()] -= 1;
                }
            }
            foreach ($numDevice as $key => $value){
                if($value==0){
                    unset($numDevice[$key]);
                    unset($devices[$key]);
                }
            }
            $ListMember = Member::findAll();
            $ListAdmin = array();
            foreach ($ListMember as $key => $value){
                if($value->getType() == 'PROFESSOR'){
                    $ListAdmin[$key] = $value;
                }
            }
            #include Router::getSourcePath()."booking.inc.php";
        }else{
            //login by admin
            $member = Member::findByAccount($username,$password);
            if ($member !== null){
                session_start();
                $_SESSION['member'] = $member;
                $devices = device::findAll();
                $detailBookings = detailBooking::findAll();
                $numDevice = array();
                foreach ($devices as $key => $value){
                    $numDevice[$key] = (int)($value->getNumber());
                }
                foreach ($detailBookings as $key => $value){
                    if($value->getRevertingDate() == NULL){
                        $numDevice[$value->getDeviceId()] -= 1;
                    }
                }
                foreach ($numDevice as $key => $value){
                    if($value==0){
                        unset($numDevice[$key]);
                        unset($devices[$key]);
                    }
                }
                $ListMember = Member::findAll();
                $ListAdmin = array();
                foreach ($ListMember as $key => $value){
                    if($value->getType() == 'PROFESSOR'){
                        $ListAdmin[$key] = $value;
                    }
                }
                include Router::getSourcePath()."booking.inc.php";
            }
            else {
                header("Location: ".Router::getSourcePath()."index.php?msg=invalid");
            }
        }
    }
    private function logout()
    {
        session_start();
        session_unset();
        session_destroy();
        header("Location: ".Router::getSourcePath()."index.php?");
    }
    private function regis(string $username, string $password,string $confirmpassword,string $firstname ,string $lastname ,string $email, string $permission) {
     
        $ob = new Member();
        $ob->setNumberStudent("$username");
        $ob->setPass("$password");
        $ob->setName("$firstname");
        $ob->setType("$lastname");
        $ob->setEmail("$email");
        $ob->setPermission("$permission");

//         $ob->setPermission("user");
//         $ob->setPermission("$permission"); (string $permission = "user")
        $checkusername = $ob->findByUsername($username);
        $checkemail = $ob->findByEmail($email);

        if($checkusername == false ) {
            if ($confirmpassword == $password)
            {
                if ($checkemail == false)
                {

                   var_dump($ob->Insert()) ;
                    echo "SUCCESS";
                }
                else
                {
                    echo  "donntuseemail" ;
                }
            }
            else{
                echo "checkpassword";
            }
        }
        else{
            echo "dontuseusername";
        }

    }
    private function delete(string $memID){
        $ob = new Member();
        $ob->setUid($memID);
        if($ob->delete()){
            echo "1";
        }
        else echo "0";
       

    }

    private function update(string $memID ,string $username,string $firstname ,string $lastname ,string $email, string $permission,string $password,string $check){

        session_start();
        $ob = new Member();
        $ob->setUid($memID);
        $ob->setNumberStudent("$username");
        $ob->setName("$firstname");
        $ob->setType("$lastname");
        $ob->setEmail("$email");
        $ob->setPermission("$permission");
        $ob->setPass("$password");

        $checkemail = $ob->findByEmail($email);

        if ($checkemail == false || $checkemail->getEmail()==$check)
        {

            $ob->update();
            $member = Member::findById($memID);

            $_SESSION['member'] = $member;

        }
        else
        {
            echo  "donntuseemail" ;
        }



    }
}