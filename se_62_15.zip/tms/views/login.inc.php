<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <title>Document</title>
    <style>
        body{
            background-image: url("./img/background.jpg");
            background-size: 100%;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
    </style>
</head>
<body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<!--check login-->
<input type="hidden" name="check" id="check" value="<?= $_GET['msg']??"3" ?>">


<!--Login-->
<nav class="navbar sticky-top navbar-light bg-dark">
    <span class="navbar-brand mb-0 h1"><img src="./img2/logo.png" alt="" width="150" height="60"></span>
    <form class="form-inline" id="login" method="post"
          action=<?= Router::getSourcePath() . "index.php?controller=Member&action=login" ?>>
        <div class="input-group mb-0 mr-sm-2">
            <div class="input-group-prepend">
                <div class="input-group-text">ชื่อผู้ใช้</div>
            </div>
            <input type="text" name="username1" class="form-control" id="username1" placeholder="ชื่อผู้ใช้" required>
        </div>

        <div class="input-group mb-0 mr-sm-2">
            <div class="input-group-prepend">
                <div class="input-group-text">รหัสผ่าน</div>
            </div>
            <input type="password" name="password1" class="form-control" id="password1" placeholder="รหัสผ่าน" required>
        </div>


        <button type="submit" class="btn btn-primary mb-0">เข้าสู่ระบบ</button>
        <!--<a class="text-white ml-2" href="views/member/resetPass.inc.php" >ลืมรหัสผ่าน</a> -->
    </form>
</nav>

<!--register-->
<div class="container-fluid mt-3 mb-3">

        <div class="col" style="margin-top:5%;">
            <center>
            <h1 class="text-center text-success" style="font-family:Arial Black; font-size: 300%;">ระบบยืม-คืน อุปกรณ์ ภาควิชาวิศวกรรมคอมพิวเตอร์ มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน</h1>
            <div class="form-group mt-5 ml-5"><img src="img2/background.jpg" alt="" style="width: 60%"></div>
            </center>
        </div>


    </div>
</div>

<script>
    var check = document.getElementById("check");

    if(check.value != "3"){
        Swal.fire({
            type: 'error',
            title: 'ชื่อผู้ใช้หรือรหัสผ่าน ผิด',
            confirmButtonText: 'ตกลง'
        })}
</script>
</body>
</html>