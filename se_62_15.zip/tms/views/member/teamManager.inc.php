<!DOCTYPE html>
<html lang="en">
<?php
if (!isset($_SESSION['member']) || !is_a($_SESSION['member'],"Member"))
{
    header("Location: " . Router::getSourcePath() . "index.php");
}
$allWorkList = $allWorkList??null;
$member_AllWorkList = $member_AllWorkList??null;
$teamL = $teamList??null;
$memberListByTeamList = $memberListByTeamList??null;
$teamMemberByTeamList = $teamMemberByTeamList??null;

$title = "TMS";
require_once './inc/helper_func.inc.php';
ob_start();
?>
<body>

<div class="row">
    <div class="col-3 mt-3 ">
        <span style="display: inline-flex ">
        <div style="width: 300px" class="nav flex-column nav-pills ml-3 bg-light" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <a class="nav-link active"  data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="" aria-selected="true"><i class="fas fa-users fa-lg"></i> กลุ่มทั้งหมด</a>
            <?php
            foreach ($teamL as $index => $obj) {
                echo "<a class=\"nav-link\" id=\"v-pills-{$obj->getTeamId()}-tab\" data-toggle=\"pill\" href=\"#v-pills-{$obj->getTeamId()}\" role=\"tab\" aria-controls=\"v-pills-{$obj->getTeamId()}\" aria-selected=\"true\">{$obj->getName()}</a>";
            }
            ?>
        </div>
        <div  class="nav flex-column navbar-link ">
            <a id="pillAllSetting" style="background: #f1f0fc;border-radius: 0px 20px 20px 0px" class="nav-link" href="<?= Router::getSourcePath()."index.php?controller=Team&action=showDetailAllTeam&status=manager" ?>"><i style="color: #007bff" class="fa fa-cog"></i></a>
            <?php
            foreach ($teamL as $index => $obj) {
                echo "<a id=\"pillSetting{$obj->getTeamId()}\" style=\"background: #f1f0fc;border-radius: 0px 20px 20px 0px\" class=\"nav-link\" href=\"".Router::getSourcePath()."index.php?controller=Team&action=showDetailTeam&team_id=".$obj->getTeamId()."\"><i style=\"color: #007bff\" class=\"fa fa-cog\"></i></a>";
            }
            ?>
        </div>
        </span>
    </div>



    <div class="col-8 ml-5 mt-3 " >
        <div class="tab-content mt-2" id="v-pills-tabContent">
            <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                <div align="left">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" style="margin: 0px 5px">
                            <button type="button" class="nav-link btn btn-dark" id="v-pills-all-tab" data-toggle="pill" href="#v-pills-all" role="tab" aria-controls="pills--all" aria-selected="false">ทั้งหมด</button>
                        </li>
                        <li class="nav-item" style="margin: 0px 5px">
                            <button type="button" class="nav-link btn btn-secondary" id="pills-waiting-tab" data-toggle="pill" href="#pills-waiting" role="tab" aria-controls="pills-waiting" aria-selected="false">รอผู้รับงาน</button>
                        </li>
                        <li class="nav-item" style="margin: 0px 5px">
                            <button type="button" class="nav-link btn btn-info" id="pills-process-tab" data-toggle="pill" href="#pills-process" role="tab" aria-controls="pills-process" aria-selected="false">ดำเนินการ</button>
                        </li>
                        <li class="nav-item" style="margin: 0px 5px">
                            <button type="button" class="nav-link btn btn-warning text-white" id="pills-delivered-tab" data-toggle="pill" href="#pills-delivered" role="tab" aria-controls="pills-delivered" aria-selected="false">รอตรวจ</button>
                        </li>
                        <li class="nav-item" style="margin: 0px 5px">
                            <button type="button" class="nav-link btn btn-danger" id="pills-modify-tab" data-toggle="pill" href="#pills-modify" role="tab" aria-controls="pills-modify" aria-selected="false">แก้ไข</button>
                        </li>
                        <li class="nav-item" style="margin: 0px 5px">
                            <button type="button" class="nav-link btn btn-success" id="pills-finish-tab" data-toggle="pill" href="#pills-finish" role="tab" aria-controls="pills-finish" aria-selected="false">เสร็จสิ้น</button>
                        </li>
                    </ul>

                    <div class="tab-content " id="pills-tabContent">
                        <div class="tab-pane fade show active" id="v-pills-all" role="tabpanel" aria-labelledby="v-pills-all-tab">
                            <?php
                            if(isset($allWorkList)&&!empty($allWorkList)) {
                                ?>
                                <table id="customTableAll" class="table table-striped table-bordered dataTable" style="width: 100%;" role="grid"
                                       aria-describedby="example_info">
                                    <thead>
                                    <tr class="table-active">
                                        <th scope="col">ลำดับ</th>
                                        <th scope="col">หัวข้อ</th>
                                        <th scope="col">วันที่สั่ง</th>
                                        <th scope="col">วันที่กำหนดส่ง</th>
                                        <th scope="col">รายละเอียด</th>
                                        <th scope="col">สถานะ</th>
                                    </tr>
                                    </thead>
                                    <?php
                                    $i = 1;
                                    foreach ($allWorkList as $obj) {
                                        if($obj->getStatusWork()=="process"||$obj->getStatusWork()=="delivered"||$obj->getStatusWork()=="modify"||$obj->getStatusWork()=="finish"){
                                            $targetTeamMember = null;
                                            $targetMember = null;
                                            foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember){
                                                if($obj->getWorkerId()==$teamMember_id){
                                                    $targetTeamMember = $teamMember;
                                                    break;
                                                }
                                            }
                                            foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem){
                                                if($targetTeamMember->getMemId()==$mem_id){
                                                    $targetMember = $mem;
                                                    break;
                                                }
                                            }
                                            $targetMember = $targetMember->getUsername()??null;
                                        }
                                        $startDate = formatDate($obj->getStartDate());
                                        $endDate = formatDate($obj->getEndDate());
                                        echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalAllId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                        if($obj->getStatusWork()=="waiting") {
                                            echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                        } else if ($obj->getStatusWork() == "process") {
                                            echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                        } else if ($obj->getStatusWork() == "delivered") {
                                            echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                        } else if ($obj->getStatusWork() == "modify") {
                                            echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                        } else if ($obj->getStatusWork() == "finish") {
                                            echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                        }
                                        echo "</td></tr>";
                                        ?>

                                        <div id="ModalAllId<?= $obj->getWorkId() ?>"
                                             class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                             aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content" align='left'>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                        <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                        <?php
                                                        if($obj->getStatusWork()=="delivered")
                                                        {
                                                            echo "<p><b>วันที่ส่ง</b> {$obj->getSendDate()}</p>";
                                                            echo "<p><b>ผู้รับงาน</b> $targetMember</p>";
                                                        }else if($obj->getStatusWork()=="modify"||$obj->getStatusWork()=="process"||$obj->getStatusWork()=="finish"){
                                                            echo "<p><b>ผู้รับงาน</b> $targetMember</p>";
                                                        }
                                                        ?>
                                                        <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>
                                                        <div style="float: left">
                                                            <?php
                                                            if ($obj->getStatusWork() == "delivered"){
                                                                ?>
                                                                <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                                <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                    <button type="submit" class="btn btn-success">
                                                                        ยอมรับงาน
                                                                    </button>
                                                                </a>
                                                                <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                    <button type="submit" class="btn btn-danger">
                                                                        ส่งแก้ไขงาน
                                                                    </button>
                                                                </a>
                                                                <?php
                                                            }else if($obj->getStatusWork()=="finish"){?>
                                                                <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                                <?php
                                                            }
                                                            ?>
                                                        </div>
                                                        <div style="float: right">
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                                <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                                </table>
                                <?php
                            }else {
                                echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                            }
                            ?>
                        </div>
                        <div class="tab-pane fade" id="pills-waiting" role="tabpanel" aria-labelledby="pills-waiting-tab">
                            <?php
                            $i = 1;
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "waiting") {
                                    echo "<table id=\"customTableWaiting\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">ระยะเวลาที่เหลือ</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout  = calculateBetweenPeriodOfTime($date);
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalWaitingId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>

                                    <div id="ModalWaitingId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if($obj->getStatusWork() == "waiting"){
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout  = calculateBetweenPeriodOfTime($date);
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalWaitingId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>

                                    <div id="ModalWaitingId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                            if($i==1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                            ?>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="pills-process" role="tabpanel" aria-labelledby="pills-process-tab">
                            <?php
                            $i = 1;
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "process") {
                                    echo "<table id=\"customTableProcess\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">ระยะเวลาที่เหลือ</th>
                                                     <th scope=\"col\">ผู้รับงาน</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout  = calculateBetweenPeriodOfTime($date);
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $targetTeamMember = null;
                                    $targetMember = null;
                                    foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember){
                                        if($obj->getWorkerId()==$teamMember_id){
                                            $targetTeamMember = $teamMember;
                                            break;
                                        }
                                    }
                                    foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem){
                                        if($targetTeamMember->getMemId()==$mem_id){
                                            $targetMember = $mem;
                                            break;
                                        }
                                    }
                                    $targetMember = $targetMember->getUsername()??null;
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td>{$targetMember}</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalProcessId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalProcessId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if($obj->getStatusWork() == "process"){
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout  = calculateBetweenPeriodOfTime($date);
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $targetMember = $targetMember??null;
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalProcessId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>

                                    <div id="ModalProcessId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                            if($i==1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                            ?>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="pills-delivered" role="tabpanel" aria-labelledby="pills-delivered-tab">
                            <?php
                            $i = 1;
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "delivered") {
                                    echo "<table id=\"customTableDelivered\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">วันที่ส่ง</th>
                                                     <th scope=\"col\">ผู้รับงาน</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $targetTeamMember = null;
                                    $targetMember = null;
                                    foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember){
                                        if($obj->getWorkerId()==$teamMember_id){
                                            $targetTeamMember = $teamMember;
                                            break;
                                        }
                                    }
                                    foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem){
                                        if($targetTeamMember->getMemId()==$mem_id){
                                            $targetMember = $mem;
                                            break;
                                        }
                                    }
                                    $targetMember = $targetMember->getUsername()??null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>{$obj->getSendDate()}</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalDeliveredId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalDeliveredId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>
                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if($obj->getStatusWork() == "delivered"){
                                    $targetMember = $targetMember??null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $sendDate = formatDate($obj->getSendDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$sendDate</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalDeliveredId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalDeliveredId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>
                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                            if($i==1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                            ?>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="pills-modify" role="tabpanel" aria-labelledby="pills-modify-tab">
                            <?php
                            $i = 1;
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "modify") {
                                    echo "<table id=\"customTableModify\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">ระยะเวลาที่เหลือ</th>
                                                     <th scope=\"col\">ผู้รับงาน</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout  = calculateBetweenPeriodOfTime($date);
                                    $targetTeamMember = null;
                                    $targetMember = null;
                                    foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember){
                                        if($obj->getWorkerId()==$teamMember_id){
                                            $targetTeamMember = $teamMember;
                                            break;
                                        }
                                    }
                                    foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem){
                                        if($targetTeamMember->getMemId()==$mem_id){
                                            $targetMember = $mem;
                                            break;
                                        }
                                    }
                                    $targetMember = $targetMember->getUsername()??null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalModifyId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalModifyId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if($obj->getStatusWork() == "modify"){
                                    $targetMember = $targetMember??null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalModifyId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalModifyId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=cancel&work_id=". $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                            if($i==1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                            ?>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="pills-finish" role="tabpanel" aria-labelledby="pills-finish-tab">
                            <?php
                            $i = 1;
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "finish") {
                                    echo "<table id=\"customTableFinish\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">วันที่ส่ง</th>
                                                     <th scope=\"col\">ผู้รับงาน</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $targetTeamMember = null;
                                    $targetMember = null;
                                    foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember){
                                        if($obj->getWorkerId()==$teamMember_id){
                                            $targetTeamMember = $teamMember;
                                            break;
                                        }
                                    }
                                    foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem){
                                        if($targetTeamMember->getMemId()==$mem_id){
                                            $targetMember = $mem;
                                            break;
                                        }
                                    }
                                    $targetMember = $targetMember->getUsername()??null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $sendDate = formatDate($obj->getSendDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$sendDate</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalFinishId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalFinishId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่งงาน</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>วันที่ตรวจเสร็จ</b> <?= formatDate($obj->getCompleteDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }else if($obj->getStatusWork()=="finish"){ ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if($obj->getStatusWork() == "finish"){
                                    $targetMember = $targetMember??null;
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>{$obj->getStartDate()}</td>
                                              <td>{$obj->getEndDate()}</td>
                                              <td>{$obj->getSendDate()}</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalFinishId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if($obj->getStatusWork()=="waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalFinishId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่งงาน</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>วันที่ตรวจเสร็จ</b> <?= formatDate($obj->getCompleteDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered" ){
                                                            ?>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=accept&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath()."index.php?controller=Work&action=modify&work_id=". $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }else if($obj->getStatusWork()=="finish"){ ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <?php
                                                        }

                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                            if($i==1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                            ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $NumCustomTable = 0;
            foreach ($teamL as $index => $objTeam) {
            $NumCustomTable++;
            echo "<div class=\"tab-pane fade\" id=\"v-pills-{$objTeam->getTeamId()}\" role=\"tabpanel\" aria-labelledby=\"v-pills-{$objTeam->getTeamId()}-tab\">";
            ?>
            <div align="left">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" style="margin: 0px 5px">
                        <button type="button" class="nav-link btn btn-dark" id="pills-all-tab-<?= $objTeam->getTeamId() ?>"
                                data-toggle="pill" href="#v-pills-all-<?= $objTeam->getTeamId() ?>" role="tab" aria-controls="pills-all-<?= $objTeam->getTeamId() ?>"
                                aria-selected="false">ทั้งหมด
                        </button>
                    </li>
                    <li class="nav-item" style="margin: 0px 5px">
                        <button type="button" class="nav-link btn btn-secondary" id="pills-waiting-tab-<?= $objTeam->getTeamId() ?>"
                                data-toggle="pill" href="#pills-waiting-<?= $objTeam->getTeamId() ?>" role="tab" aria-controls="pills-waiting-<?= $objTeam->getTeamId() ?>"
                                aria-selected="false">รอผู้รับงาน
                        </button>
                    </li>
                    <li class="nav-item" style="margin: 0px 5px">
                        <button type="button" class="nav-link btn btn-info" id="pills-process-tab-<?= $objTeam->getTeamId() ?>" data-toggle="pill"
                                href="#pills-process-<?= $objTeam->getTeamId() ?>" role="tab" aria-controls="pills-process-<?= $objTeam->getTeamId() ?>" aria-selected="false">
                            ดำเนินการ
                        </button>
                    </li>
                    <li class="nav-item" style="margin: 0px 5px">
                        <button type="button" class="nav-link btn btn-warning" id="pills-delivered-tab-<?= $objTeam->getTeamId() ?>"
                                data-toggle="pill" href="#pills-delivered-<?= $objTeam->getTeamId() ?>" role="tab" aria-controls="pills-delivered-<?= $objTeam->getTeamId() ?>"
                                aria-selected="false">รอตรวจ
                        </button>
                    </li>
                    <li class="nav-item" style="margin: 0px 5px">
                        <button type="button" class="nav-link btn btn-danger" id="pills-modify-tab-<?= $objTeam->getTeamId() ?>" data-toggle="pill"
                                href="#pills-modify-<?= $objTeam->getTeamId() ?>" role="tab" aria-controls="pills-modify-<?= $objTeam->getTeamId() ?>" aria-selected="false">แก้ไข
                        </button>
                    </li>
                    <li class="nav-item" style="margin: 0px 5px">
                        <button type="button" class="nav-link btn btn-success" id="pills-finish-tab-<?= $objTeam->getTeamId() ?>" data-toggle="pill"
                                href="#pills-finish-<?= $objTeam->getTeamId() ?>" role="tab" aria-controls="pills-finish-<?= $objTeam->getTeamId() ?>" aria-selected="false">
                            เสร็จสิ้น
                        </button>
                    </li>
                    <div  style="margin: 0px 5px; float: right">
                        <button type="button" class="nav-link btn btn-primary"
                                data-toggle="modal" data-target="#ModalTeamAddWorkId<?= $objTeam->getTeamId() ?>">
                            <i class="fa fa-plus-circle"></i> สั่งงาน
                        </button>
                    </div>
                    <div id="ModalTeamAddWorkId<?= $objTeam->getTeamId() ?>"
                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content" align='left'>
                                <div class="modal-header">
                                    <h2 class="modal-title">สั่งงาน </h2>
                                    <button type="button" class="close" data-dismiss="modal"
                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form method="post" action=<?= Router::getSourcePath()."index.php?controller=Work&action=AddWork"?>>
                                        <input type="hidden" name="team_id" value="<?= $objTeam->getTeamId() ?>">
                                        <div class="col-md-9 mb-0">
                                            <table border="0" width="90%">
                                                <tr>
                                                    <td style="width: 40%;" align="right"><h3 >หัวข้อ</h3></td>
                                                    <td ><input id="topic" name="topic" style="margin-left: 15px" type="text" class="form-control" placeholder="" value="" required=""></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 30%;" align="right"><h3 >กำหนดส่งงาน</h3></td>
                                                    <td ><input id="date<?= $NumCustomTable ?>" name="date" style="margin-left: 15px" type="date" class="form-control" placeholder="" value="" required=""></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 30%;" align="right"><h3>รูปแบบ</h3></td>
                                                    <td>
                                                        <div style="float: left;margin-left: 15px"  class="custom-control custom-radio">
                                                            <input id="statusPublic<?= $NumCustomTable ?>" name="status" type="radio" class="custom-control-input" required="" value="public" checked>
                                                            <label class="custom-control-label" for="statusPublic<?= $NumCustomTable ?>">Public</label>
                                                        </div>
                                                        <div style="float: left;margin-left: 10px"  class="custom-control custom-radio">
                                                            <input id="statusPrivate<?= $NumCustomTable ?>" name="status" type="radio" class="custom-control-input" required="" value="private">
                                                            <label class="custom-control-label" for="statusPrivate<?= $NumCustomTable ?>">Private</label>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr id="dropdownMember<?= $NumCustomTable ?>" >
                                                    <td  align="right" ><h3>เลือกสมาชิก</h3></td>
                                                    <td>
                                                        <?php
                                                        $countMember = 1;
                                                        foreach ($memberListByTeamList[$objTeam->getTeamId()] as $index=>$mem) {
                                                            if($countMember==1)
                                                            {
                                                                echo "<select style=\"margin-left: 15px\" id=\"chooseMember\" name=\"chooseMember\"  class=\"browser-default custom-select\">";
                                                                echo "<option value=\"{$mem->getMemId()}\" selected>{$mem->getUsername()}</option>";
                                                            }else {
                                                                echo "<option value=\"{$mem->getMemId()}\">{$mem->getUsername()}</option>";
                                                            }
                                                            $countMember++;
                                                        }
                                                        if($countMember!=1) echo "</select>";
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td  align="right"><h3>รายละเอียด</h3></td>
                                                    <td ><textarea name="detail" style="margin-left: 15px" class="form-control" rows="4" cols="50" required></textarea></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div style="float: right">
                                            <button type="submit" class="btn btn-success">ตกลง</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </ul>

                <div class="tab-content " id="pills-tabContent">
                    <div class="tab-pane fade show active" id="v-pills-all-<?= $objTeam->getTeamId() ?>" role="tabpanel"
                         aria-labelledby="v-pills-all-tab-<?= $objTeam->getTeamId() ?>">
                        <?php
                        $i = 1;
                        if(isset($allWorkList)&&!empty($allWorkList)) {
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    echo "<table id=\"customTableTeam-$NumCustomTable\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                                 aria-describedby=\"example_info\">
                                                 <thead>
                                                    <tr class=\"table-active\">
                                                       <th scope=\"col\">ลำดับ</th>
                                                       <th scope=\"col\">หัวข้อ</th>
                                                       <th scope=\"col\">วันที่สั่ง</th>
                                                       <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                       <th scope=\"col\">รายละเอียด</th>
                                                       <th scope=\"col\">สถานะ</th>
                                                     </tr>
                                                  </thead>";
                                    if($obj->getStatusWork()=="process"||$obj->getStatusWork()=="delivered"||$obj->getStatusWork()=="modify"||$obj->getStatusWork()=="finish"){
                                        $targetTeamMember = null;
                                        $targetMember = null;
                                        foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember){
                                            if($obj->getWorkerId()==$teamMember_id){
                                                $targetTeamMember = $teamMember;
                                                break;
                                            }
                                        }
                                        foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem){
                                            if($targetTeamMember->getMemId()==$mem_id){
                                                $targetMember = $mem;
                                                break;
                                            }
                                        }
                                        $targetMember = $targetMember->getUsername()??null;
                                        $startDate = formatDate($obj->getStartDate());
                                        $endDate = formatDate($obj->getEndDate());
                                    }
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <?php
                                                    if($obj->getStatusWork()=="delivered")
                                                    {
                                                        echo "<p><b>วันที่ส่ง</b> {$obj->getSendDate()}</p>";
                                                        echo "<p><b>ผู้รับงาน</b> $targetMember</p>";
                                                    }else if($obj->getStatusWork()=="modify"||$obj->getStatusWork()=="process"||$obj->getStatusWork()=="finish"){
                                                        echo "<p><b>ผู้รับงาน</b> $targetMember</p>";
                                                    }
                                                    ?>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }else if($obj->getStatusWork()=="finish"){?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <?php if($obj->getStatusWork()!="finish"){?>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                        <?php
                                                    }?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if ($objTeam->getTeamId() == $obj->getTeamId()) {
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <?php
                                                    if($obj->getStatusWork()=="delivered")
                                                    {
                                                        $sendDate = formatDate($obj->getSendDate());
                                                        echo "<p><b>วันที่ส่ง</b> $sendDate</p>";
                                                        echo "<p><b>ผู้รับงาน</b> $targetMember</p>";
                                                    }else if($obj->getStatusWork()=="modify"||$obj->getStatusWork()=="process"||$obj->getStatusWork()=="finish"){
                                                        echo "<p><b>ผู้รับงาน</b> $targetMember</p>";
                                                    }
                                                    ?>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }else if($obj->getStatusWork()=="finish"){?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                        }
                        if ($i == 1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                        ?>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="pills-waiting-<?= $objTeam->getTeamId() ?>" role="tabpanel" aria-labelledby="pills-waiting-tab-<?= $objTeam->getTeamId() ?>">
                        <?php
                        $i = 1;
                        if(isset($allWorkList)&&!empty($allWorkList)) {
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "waiting" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    echo "<table id=\"customTableTeam-$NumCustomTable-waiting\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">ระยะเวลาที่เหลือ</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout = calculateBetweenPeriodOfTime($date);
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamWaitingId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamWaitingId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if ($obj->getStatusWork() == "waiting" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout = calculateBetweenPeriodOfTime($date);
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamWaitingId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamWaitingId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">

                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                        }
                        if ($i == 1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                        ?>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="pills-process-<?= $objTeam->getTeamId() ?>" role="tabpanel" aria-labelledby="pills-process-tab-<?= $objTeam->getTeamId() ?>">
                        <?php
                        $i = 1;
                        if(isset($allWorkList)&&!empty($allWorkList)) {
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "process" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    echo "<table id=\"customTableTeam-$NumCustomTable-process\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">ระยะเวลาที่เหลือ</th>
                                                     <th scope=\"col\">ผู้รับงาน</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout = calculateBetweenPeriodOfTime($date);
                                    $targetTeamMember = null;
                                    $targetMember = null;
                                    foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember) {
                                        if ($obj->getWorkerId() == $teamMember_id) {
                                            $targetTeamMember = $teamMember;
                                            break;
                                        }
                                    }
                                    foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem) {
                                        if ($targetTeamMember->getMemId() == $mem_id) {
                                            $targetMember = $mem;
                                            break;
                                        }
                                    }
                                    $targetMember = $targetMember->getUsername() ?? null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamProcessId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamProcessId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if ($obj->getStatusWork() == "process" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout = calculateBetweenPeriodOfTime($date);
                                    $targetMember = $targetMember ?? null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$timeout</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamProcessId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamProcessId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                        }
                        if ($i == 1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                        ?>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="pills-delivered-<?= $objTeam->getTeamId() ?>" role="tabpanel"
                         aria-labelledby="pills-delivered-tab-<?= $objTeam->getTeamId() ?>">
                        <?php
                        $i = 1;
                        if(isset($allWorkList)&&!empty($allWorkList)) {
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "delivered" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    echo "<table id=\"customTableTeam-$NumCustomTable-delivered\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">วันที่ส่ง</th>
                                                     <th scope=\"col\">ผู้รับงาน</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $targetTeamMember = null;
                                    $targetMember = null;
                                    foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember) {
                                        if ($obj->getWorkerId() == $teamMember_id) {
                                            $targetTeamMember = $teamMember;
                                            break;
                                        }
                                    }
                                    foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem) {
                                        if ($targetTeamMember->getMemId() == $mem_id) {
                                            $targetMember = $mem;
                                            break;
                                        }
                                    }
                                    $targetMember = $targetMember->getUsername() ?? null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $sendDate = formatDate($obj->getSendDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$sendDate</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamDeliveredId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamDeliveredId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if ($obj->getStatusWork() == "delivered" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    $targetMember = $targetMember ?? null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $sendDate = formatDate($obj->getSendDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$sendDate</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamDeliveredId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamDeliveredId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                        }
                        if ($i == 1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                        ?>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="pills-modify-<?= $objTeam->getTeamId() ?>" role="tabpanel" aria-labelledby="pills-modify-tab-<?= $objTeam->getTeamId() ?>">
                        <?php
                        $i = 1;
                        if(isset($allWorkList)&&!empty($allWorkList)) {
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "modify" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    echo "<table id=\"customTableTeam-$NumCustomTable-modify\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">วันที่ส่งงาน</th>
                                                     <th scope=\"col\">ระยะเวลาที่เหลือ</th>
                                                     <th scope=\"col\">ผู้รับงาน</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout = calculateBetweenPeriodOfTime($date);
                                    $targetTeamMember = null;
                                    $targetMember = null;
                                    foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember) {
                                        if ($obj->getWorkerId() == $teamMember_id) {
                                            $targetTeamMember = $teamMember;
                                            break;
                                        }
                                    }
                                    foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem) {
                                        if ($targetTeamMember->getMemId() == $mem_id) {
                                            $targetMember = $mem;
                                            break;
                                        }
                                    }
                                    $targetMember = $targetMember->getUsername() ?? null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $sendDate = formatDate($obj->getSendDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$sendDate</td>
                                              <td>$timeout</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamModifyId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamModifyId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if ($obj->getStatusWork() == "modify" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    $date = new DateTime($obj->getEndDate());
                                    $timeout = calculateBetweenPeriodOfTime($date);
                                    $targetMember = $targetMember ?? null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $sendDate = formatDate($obj->getSendDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$sendDate</td>
                                              <td>$timeout</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamModifyId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamModifyId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <div style="float: right">
                                                        <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=cancel&work_id=" . $obj->getWorkId() ?>">
                                                            <button type="button" class="btn btn-dark">ยกเลิกงาน
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                        }
                        if ($i == 1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                        ?>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="pills-finish-<?= $objTeam->getTeamId() ?>" role="tabpanel" aria-labelledby="pills-finish-tab-<?= $objTeam->getTeamId() ?>">
                        <?php
                        $i = 1;
                        if(isset($allWorkList)&&!empty($allWorkList)) {
                            foreach ($allWorkList as $obj) {
                                if ($i == 1 && $obj->getStatusWork() == "finish" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    echo "<table id=\"customTableTeam-$NumCustomTable-finish\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">
                                                <thead>
                                                 <tr class=\"table-active\">
                                                    <th scope=\"col\">ลำดับ</th>
                                                     <th scope=\"col\">หัวข้อ</th>
                                                     <th scope=\"col\">วันที่สั่ง</th>
                                                     <th scope=\"col\">วันที่กำหนดส่ง</th>
                                                     <th scope=\"col\">วันที่ส่ง</th>
                                                     <th scope=\"col\">ผู้รับงาน</th>
                                                     <th scope=\"col\">รายละเอียด</th>
                                                 <th scope=\"col\">สถานะ</th>
                                               </tr>
                                               </thead>";
                                    $targetTeamMember = null;
                                    $targetMember = null;
                                    foreach ($teamMemberByTeamList[$obj->getTeamId()] as $teamMember_id => $teamMember) {
                                        if ($obj->getWorkerId() == $teamMember_id) {
                                            $targetTeamMember = $teamMember;
                                            break;
                                        }
                                    }
                                    foreach ($memberListByTeamList[$obj->getTeamId()] as $mem_id => $mem) {
                                        if ($targetTeamMember->getMemId() == $mem_id) {
                                            $targetMember = $mem;
                                            break;
                                        }
                                    }
                                    $targetMember = $targetMember->getUsername() ?? null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $sendDate = formatDate($obj->getSendDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$sendDate</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamFinishId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamFinishId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>วันที่ตรวจเสร็จ</b> <?= formatDate($obj->getCompleteDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }else if($obj->getStatusWork()=="finish"){
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                } else if ($obj->getStatusWork() == "finish" && $objTeam->getTeamId() == $obj->getTeamId()) {
                                    $targetMember = $targetMember ?? null;
                                    $startDate = formatDate($obj->getStartDate());
                                    $endDate = formatDate($obj->getEndDate());
                                    $sendDate = formatDate($obj->getSendDate());
                                    echo "<tr>
                                              <td>$i</td>
                                              <td>{$obj->getTopic()}</td>
                                              <td>$startDate</td>
                                              <td>$endDate</td>
                                              <td>$sendDate</td>
                                              <td>$targetMember</td>
                                              <td><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalTeamFinishId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></td>
                                              <td>";
                                    if ($obj->getStatusWork() == "waiting") {
                                        echo "<h3><span class=\"badge badge-secondary\">รอผู้รับงาน</span></h3>";
                                    } else if ($obj->getStatusWork() == "process") {
                                        echo "<h3><span class=\"badge badge-info\">ดำเนินการ</span></h3>";
                                    } else if ($obj->getStatusWork() == "delivered") {
                                        echo "<h3><span class=\"badge badge-warning text-white\">รอตรวจ</span></h3>";
                                    } else if ($obj->getStatusWork() == "modify") {
                                        echo "<h3><span class=\"badge badge-danger\">แก้ไข</span></h3>";
                                    } else if ($obj->getStatusWork() == "finish") {
                                        echo "<h3><span class=\"badge badge-success\">เสร็จสิ้น</span></h3>";
                                    }
                                    echo "</td></tr>";
                                    ?>
                                    <div id="ModalTeamFinishId<?= $obj->getWorkId() ?>"
                                         class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                                         aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content" align='left'>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">หัวข้อ: <?= $obj->getTopic() ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                                <span aria-hidden="true"
                                                                      style='font-size: 35px'>×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><b>วันที่สั่งงาน</b> <?= formatDate($obj->getStartDate()) ?></p>
                                                    <p><b>กำหนดส่งงาน</b> <?= formatDate($obj->getEndDate()) ?></p>
                                                    <p><b>วันที่ส่ง</b> <?= formatDate($obj->getSendDate()) ?></p>
                                                    <p><b>วันที่ตรวจเสร็จ</b> <?= formatDate($obj->getCompleteDate()) ?></p>
                                                    <p><b>ผู้รับงาน</b> <?= $targetMember ?></p>
                                                    <p><b>รายละเอียด</b> <?= $obj->getDetail() ?></p>

                                                    <div style="float: left">
                                                        <?php
                                                        if ($obj->getStatusWork() == "delivered") {
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=accept&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-success">
                                                                    ยอมรับงาน
                                                                </button>
                                                            </a>
                                                            <a href="<?= Router::getSourcePath() . "index.php?controller=Work&action=modify&work_id=" . $obj->getWorkId() ?>">
                                                                <button type="submit" class="btn btn-danger">
                                                                    ส่งแก้ไขงาน
                                                                </button>
                                                            </a>
                                                            <?php
                                                        }else if($obj->getStatusWork()=="finish"){
                                                            ?>
                                                            <a href="<?= $obj->getFile() ?>"><button type="button" class="btn btn-primary"><i class="fa fa-download"></i> ดาวน์โหลดไฟล์</button> </a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                }
                            }
                        }
                        if ($i == 1) echo "<br><br><h1 align='center'>ไม่มีรายการ</h1>";
                        ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php
        }
        ?>
    </div>
</div>
</div>


<script type="text/javascript" class="init">
    //setup date
    var num = <?= $NumCustomTable ?>;
    var today = new Date().toISOString().substr(0, 10);
    var date = new Date(today);
    date.setDate(date.getDate()+1);
    for(var i=1;i<=num;i++){
        document.querySelector('#date'+i).value = date.toISOString().substr(0, 10);
        $('#date'+i).attr('min',date.toISOString().substr(0, 10));
        // toggle public and private
        $('#dropdownMember'+i).hide();
        $( "#statusPrivate"+i ).change(function() {
            $('#dropdownMember'+$(this).attr('id')[$(this).attr('id').length-1]).show();
        });
        $( "#statusPublic"+i ).change(function() {
            $('#dropdownMember'+$(this).attr('id')[$(this).attr('id').length-1]).hide();
        });
    }

    //setup data Table
    $(document).ready(function () {
        var NumCustomTable = <?= $NumCustomTable ?>;
        if(NumCustomTable) {
            for (var i = 1; i <= NumCustomTable; i++) {
                $('#customTableTeam-'+i).DataTable( {
                    "order": [],
                    "columnDefs": [ {
                        "targets"  : 'no-sort',
                        "orderable": false
                    }],
                    "oLanguage": {
                        "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                        "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                        "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                        "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                        "sInfoPostFix":    "",
                        "sInfoThousands":  ",",
                        "sLengthMenu":     "แสดง _MENU_ แถว",
                        "sLoadingRecords": "กำลังโหลดข้อมูล...",
                        "sProcessing":     "กำลังดำเนินการ...",
                        "sSearch":         "ค้นหา: ",
                        "sZeroRecords":    "ไม่พบข้อมูล",
                        "oPaginate": {
                            "sFirst":    "หน้าแรก",
                            "sPrevious": "ก่อนหน้า",
                            "sNext":     "ถัดไป",
                            "sLast":     "หน้าสุดท้าย"
                        },
                        "oAria": {
                            "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                            "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                        }
                    }
                });
                $('#customTableTeam-'+i+'-waiting').DataTable( {
                    "order": [],
                    "columnDefs": [ {
                        "targets"  : 'no-sort',
                        "orderable": false
                    }],
                    "oLanguage": {
                        "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                        "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                        "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                        "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                        "sInfoPostFix":    "",
                        "sInfoThousands":  ",",
                        "sLengthMenu":     "แสดง _MENU_ แถว",
                        "sLoadingRecords": "กำลังโหลดข้อมูล...",
                        "sProcessing":     "กำลังดำเนินการ...",
                        "sSearch":         "ค้นหา: ",
                        "sZeroRecords":    "ไม่พบข้อมูล",
                        "oPaginate": {
                            "sFirst":    "หน้าแรก",
                            "sPrevious": "ก่อนหน้า",
                            "sNext":     "ถัดไป",
                            "sLast":     "หน้าสุดท้าย"
                        },
                        "oAria": {
                            "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                            "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                        }
                    }
                });
                $('#customTableTeam-'+i+'-process').DataTable( {
                    "order": [],
                    "columnDefs": [ {
                        "targets"  : 'no-sort',
                        "orderable": false
                    }],
                    "oLanguage": {
                        "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                        "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                        "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                        "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                        "sInfoPostFix":    "",
                        "sInfoThousands":  ",",
                        "sLengthMenu":     "แสดง _MENU_ แถว",
                        "sLoadingRecords": "กำลังโหลดข้อมูล...",
                        "sProcessing":     "กำลังดำเนินการ...",
                        "sSearch":         "ค้นหา: ",
                        "sZeroRecords":    "ไม่พบข้อมูล",
                        "oPaginate": {
                            "sFirst":    "หน้าแรก",
                            "sPrevious": "ก่อนหน้า",
                            "sNext":     "ถัดไป",
                            "sLast":     "หน้าสุดท้าย"
                        },
                        "oAria": {
                            "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                            "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                        }
                    }
                });
                $('#customTableTeam-'+i+'-delivered').DataTable( {
                    "order": [],
                    "columnDefs": [ {
                        "targets"  : 'no-sort',
                        "orderable": false
                    }],
                    "oLanguage": {
                        "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                        "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                        "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                        "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                        "sInfoPostFix":    "",
                        "sInfoThousands":  ",",
                        "sLengthMenu":     "แสดง _MENU_ แถว",
                        "sLoadingRecords": "กำลังโหลดข้อมูล...",
                        "sProcessing":     "กำลังดำเนินการ...",
                        "sSearch":         "ค้นหา: ",
                        "sZeroRecords":    "ไม่พบข้อมูล",
                        "oPaginate": {
                            "sFirst":    "หน้าแรก",
                            "sPrevious": "ก่อนหน้า",
                            "sNext":     "ถัดไป",
                            "sLast":     "หน้าสุดท้าย"
                        },
                        "oAria": {
                            "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                            "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                        }
                    }
                });
                $('#customTableTeam-'+i+'-modify').DataTable( {
                    "order": [],
                    "columnDefs": [ {
                        "targets"  : 'no-sort',
                        "orderable": false
                    }],
                    "oLanguage": {
                        "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                        "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                        "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                        "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                        "sInfoPostFix":    "",
                        "sInfoThousands":  ",",
                        "sLengthMenu":     "แสดง _MENU_ แถว",
                        "sLoadingRecords": "กำลังโหลดข้อมูล...",
                        "sProcessing":     "กำลังดำเนินการ...",
                        "sSearch":         "ค้นหา: ",
                        "sZeroRecords":    "ไม่พบข้อมูล",
                        "oPaginate": {
                            "sFirst":    "หน้าแรก",
                            "sPrevious": "ก่อนหน้า",
                            "sNext":     "ถัดไป",
                            "sLast":     "หน้าสุดท้าย"
                        },
                        "oAria": {
                            "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                            "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                        }
                    }
                });
                $('#customTableTeam-'+i+'-finish').DataTable( {
                    "order": [],
                    "columnDefs": [ {
                        "targets"  : 'no-sort',
                        "orderable": false
                    }],
                    "oLanguage": {
                        "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                        "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                        "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                        "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                        "sInfoPostFix":    "",
                        "sInfoThousands":  ",",
                        "sLengthMenu":     "แสดง _MENU_ แถว",
                        "sLoadingRecords": "กำลังโหลดข้อมูล...",
                        "sProcessing":     "กำลังดำเนินการ...",
                        "sSearch":         "ค้นหา: ",
                        "sZeroRecords":    "ไม่พบข้อมูล",
                        "oPaginate": {
                            "sFirst":    "หน้าแรก",
                            "sPrevious": "ก่อนหน้า",
                            "sNext":     "ถัดไป",
                            "sLast":     "หน้าสุดท้าย"
                        },
                        "oAria": {
                            "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                            "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                        }
                    }
                });
            }
        }
        $('#customTableAll').DataTable( {
            "order": [],
            "columnDefs": [ {
                "targets"  : 'no-sort',
                "orderable": false
            }],
            "oLanguage": {
                "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "แสดง _MENU_ แถว",
                "sLoadingRecords": "กำลังโหลดข้อมูล...",
                "sProcessing":     "กำลังดำเนินการ...",
                "sSearch":         "ค้นหา: ",
                "sZeroRecords":    "ไม่พบข้อมูล",
                "oPaginate": {
                    "sFirst":    "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext":     "ถัดไป",
                    "sLast":     "หน้าสุดท้าย"
                },
                "oAria": {
                    "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                    "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                }
            }
        });
        $('#customTableWaiting').DataTable( {
            "order": [],
            "columnDefs": [ {
                "targets"  : 'no-sort',
                "orderable": false
            }],
            "oLanguage": {
                "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "แสดง _MENU_ แถว",
                "sLoadingRecords": "กำลังโหลดข้อมูล...",
                "sProcessing":     "กำลังดำเนินการ...",
                "sSearch":         "ค้นหา: ",
                "sZeroRecords":    "ไม่พบข้อมูล",
                "oPaginate": {
                    "sFirst":    "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext":     "ถัดไป",
                    "sLast":     "หน้าสุดท้าย"
                },
                "oAria": {
                    "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                    "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                }
            }
        });
        $('#customTableProcess').DataTable( {
            "order": [],
            "columnDefs": [ {
                "targets"  : 'no-sort',
                "orderable": false
            }],
            "oLanguage": {
                "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "แสดง _MENU_ แถว",
                "sLoadingRecords": "กำลังโหลดข้อมูล...",
                "sProcessing":     "กำลังดำเนินการ...",
                "sSearch":         "ค้นหา: ",
                "sZeroRecords":    "ไม่พบข้อมูล",
                "oPaginate": {
                    "sFirst":    "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext":     "ถัดไป",
                    "sLast":     "หน้าสุดท้าย"
                },
                "oAria": {
                    "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                    "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                }
            }
        });
        $('#customTableDelivered').DataTable( {
            "order": [],
            "columnDefs": [ {
                "targets"  : 'no-sort',
                "orderable": false
            }],
            "oLanguage": {
                "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "แสดง _MENU_ แถว",
                "sLoadingRecords": "กำลังโหลดข้อมูล...",
                "sProcessing":     "กำลังดำเนินการ...",
                "sSearch":         "ค้นหา: ",
                "sZeroRecords":    "ไม่พบข้อมูล",
                "oPaginate": {
                    "sFirst":    "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext":     "ถัดไป",
                    "sLast":     "หน้าสุดท้าย"
                },
                "oAria": {
                    "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                    "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                }
            }
        });
        $('#customTableModify').DataTable( {
            "order": [],
            "columnDefs": [ {
                "targets"  : 'no-sort',
                "orderable": false
            }],
            "oLanguage": {
                "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
                "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "แสดง _MENU_ แถว",
                "sLoadingRecords": "กำลังโหลดข้อมูล...",
                "sProcessing":     "กำลังดำเนินการ...",
                "sSearch":         "ค้นหา: ",
                "sZeroRecords":    "ไม่พบข้อมูล",
                "oPaginate": {
                    "sFirst":    "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext":     "ถัดไป",
                    "sLast":     "หน้าสุดท้าย"
                },
                "oAria": {
                    "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                    "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                }
            }
        });
    });

</script>
</body>
<?php
$content = ob_get_clean();

include Router::getSourcePath()."templates/layout.php";

?>
</html>