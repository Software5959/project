<?php
if (!isset($_SESSION['member']) || !is_a($_SESSION['member'],"Member"))
{
    header("Location: " . Router::getSourcePath() . "index.php");
}
$title = "TMS";
$countAll = $_SESSION['countAll'];
//echo $countAll[0];

$statistic = $_SESSION['statistic'];
//print_r($statistic);
$countByDate = $_SESSION['countByDate'];
$statisticByDate = $_SESSION['statisticByDate'];
$dateStart = $_POST['dateStart'];
$dateEnd = $_POST['dateEnd'];
require_once './inc/helper_func.inc.php';
//ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>

    <style>
        body {
            background-image: url("img/background.jpg");
            background-size: 100%;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
    </style>
</head>

<body>
<!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <span class="navbar-brand mb-0 h1"><img src="./img/logo.png" alt="" width="150" height="60"></span>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="nav nav-pills mr-auto">
            <li class="nav-item">
                <!--<a class="nav-link active text-white" id="pills-home-tab" data-toggle="pill" href=<?=Router::getSourcePath()."index.php?controller=Team&action=showTeamWorker"?> role="tab" aria-controls="pills-home" aria-selected="true"><i class="fas fa-home"></i> หน้าหลัก</a>-->
            </li>
            <li class="nav-item">
                <!--<a class="nav-link text-white" id="pills-profile-tab" data-toggle="pill" href=<?=Router::getSourcePath()."index.php?controller=Team&action=showTeamManager"?> role="tab" aria-controls="pills-profile" aria-selected="false"><i class="far fa-bell"></i> งานของฉัน</a>-->
            </li>
            <li class="nav-item">
                <!--<a class="nav-link text-white" id="pills-profile-tab" data-toggle="pill" href=<?=Router::getSourcePath()."index.php?controller=Work&action=showMyWork"?> role="tab" aria-controls="pills-profile" aria-selected="false"><i class="far fa-envelope"></i> ส่งงาน</a>-->
            </li>
            <li class="nav-item">
                <!--<a class="nav-link text-white" id="pills-contact-tab" data-toggle="pill" href=<?=Router::getSourcePath()."index.php?controller=Team&action=showCreateTeam"?> role="tab" aria-controls="pills-contact" aria-selected="false"><i class="fas fa-users"></i> สร้างทีม</a>-->
            </li>
        </ul>
        <form class="form-inline">
            <div class="input-group mb-0 mr-sm-2">
            </div>
            <a class="btn btn-primary text-white mb-0" href=<?=Router::getSourcePath()."index.php?controller=Team&action=showDetailTeam&team_id=".$_SESSION['thisTeam']?>>ย้อนกลับ</a>
        </form>
    </div>
</nav>

<?php if(!isset($_POST['dateStart'])){if($countAll[0]==0){echo "<br/><h2 align='center'>ไม่มีงานที่คุณสั่ง</h2></br>";}else{?>
    <?php echo "<br/><h2 align='center'>งานที่คุณสั่งทั้งหมด $countAll[0] งาน</h2>"; ?>
    <!--content-->

    <div class="container-fluid" >
        <div class="row">
            <div class="col mt-4">
                <div id="container" style="min-width: 310px; height: 120%; max-width: 80%; margin: 0 auto;"></div>
            </div>
            <div class="col-4 mt-5 mr-4" >
                <div class="card">
                    <div class="card-header bg-success"><center><h4 class="text-white">กรุณากรอกวันที่เริ่มต้นและสิ้นสุด</h4></center></div>
                    <div class="card-body" style="background-color:#ccffcc">
                        <center>
                            <label class="form-group">
                                <form method="post" action=<?=Router::getSourcePath()."index.php?controller=Team&action=statistic" ?>>
                                    <div class="form-group row">
                                        <label for="">วันเริ่มต้น</label>
                                        <input class="form-control" type="date" name="dateStart" required/>
                                    </div>
                                    <div class="form-group row">
                                        <label for="">วันสิ้นสุด</label>
                                        <input class="form-control" type="date" name="dateEnd" required/>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-lg mb-0 ">ตกลง</button>
                                </form>
                            </label>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--endcontent-->
    <div class="container mt-3">
        <br/><h2 align="center">ตารางสถิติ</h2><br/>
        <?php
        $stable = $_SESSION['statisticTable'];
        $i=1;
        echo "<table class='table table-striped table-dark'>
        <thead>
            <tr>
                <td>ลำดับ</td>
                <td>วันที่สั่ง</td>
                <td>หัวข้อ</td>
                <td>สถานะ</td>
                <td>ผู้รับงาน</td>
            </tr>
        </thead>";
        foreach ($stable as $s){
            echo "<tr style='background-color: whitesmoke; color: black'>
                    <td>$i</td>
                    <td>$s[start_date]</td><td>$s[topic]</td>";
            if($s[status_work]=="waiting")echo "<td style='background-color: gray'>รอดำเนินการ</td>";
            elseif ($s[status_work]=="process")echo "<td style='background-color: #4a8cdb'>ดำเนินการ</td>";
            elseif ($s[status_work]=="delivered")echo "<td style='background-color: yellow'>รอตรวจ</td>";
            elseif ($s[status_work]=="modify")echo "<td style='background-color: red'>แก้ไข</td>";
            else echo "<td style='background-color: #1dc116'>เสร็จสิ้น</td>";
            echo " <td>$s[worker]</td>
                   </tr>";
            $i++;
        }
        echo "</table>";
        $sum=0;
        foreach ($statistic as $t)
            $sum+=$t[1];
        ?>
    </div>

    <!--Script-->
    <script>
        Highcharts.chart('container', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: '<b>สถิติผู้ที่รับงานของคุณ</b>'
            },
            tooltip: {
                pointFormat: '<b>{point.name} : {point.y} งาน</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name} : {point.y} งาน</b>',
                        style: {
                            color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                        }
                    }
                }
            },
            series: [{
                name: 'Brands',
                colorByPoint: true,
                data: [
                    <?php
                    foreach ($statistic as $s)
                    {
                        echo "{ name:'$s[0]' ,y:$s[1] },";
                    }
                    if($countAll[0]>$sum)
                        echo "{ name:'งานที่ไม่มีผู้รับ' ,y:$countAll[0]-$sum }";
                    ?>
                ]
            }]
        });
    </script>

<?php }}else{ if($countByDate[0]==0){echo "<br/><h2 align='center'>ไม่มีงานที่คุณสั่งระหว่าง วันที่ $dateStart ถึง $dateEnd</h2></br>";
    echo "  <center><form action=\"index.php?controller=Team&action=statistic\" method=\"post\"><button type=\"submit\" class=\"btn btn-success btn-lg mb-2 \">ดูสถิติทั้งหมด</button></form></center>
                <div class='container'>
                <div class=\"card \" style='margin-left: 20% ;margin-right: 20%'>
                    <div class=\"card-header bg-success\"><center><h4 class=\"text-white\">กรุณากรอกวันที่เริ่มต้นและสิ้นสุด</h4></center></div>
                    <div class=\"card-body\" style=\"background-color:#ccffcc\">
                        <center>
                            <label class=\"form-group\">                       
                                <form method=\"post\" action=<?=Router::getSourcePath().\"index.php?controller=Team&action=statistic\" ?>
                                    <div class=\"form-group row\">
                                        <label for=\"\">วันเริ่มต้น</label>
                                        <input class=\"form-control\" type=\"date\" name=\"dateStart\" required/>
                                    </div>
                                    <div class=\"form-group row\">
                                        <label for=\"\">วันสิ้นสุด</label>
                                        <input class=\"form-control\" type=\"date\" name=\"dateEnd\" required/>
                                    </div>
                                    <button type=\"submit\" class=\"btn btn-primary btn-lg mb-0 \">ตกลง</button>
                                </form>
                            </label>
                        </center> 
                </div>
               ";
}else{?>
<?php echo "<br/><h2 align='center'>งานที่คุณสั่งระหว่าง วันที่ $dateStart ถึง $dateEnd</h2><h2 align='center'>มีทั้งหมด $countByDate[0] งาน</h2>"; ?>

    <div class="container-fluid" >
        <div class="row">
            <div class="col mt-4">
                <div id="container" style="min-width: 310px; height: 120%; max-width: 80%; margin: 0 auto;"></div>
            </div>
            <div class="col-4 mt-5 mr-4" >
                <center><form action="index.php?controller=Team&action=statistic" method="post"><button type="submit" class="btn btn-success btn-lg mb-2 ">ดูสถิติทั้งหมด</button></form></center>
                <div class="card">
                    <div class="card-header bg-success"><center><h4 class="text-white">กรุณากรอกวันที่เริ่มต้นและสิ้นสุด</h4></center></div>
                    <div class="card-body" style="background-color:#ccffcc">
                        <center>
                            <label class="form-group">
                                <form method="post" action=<?=Router::getSourcePath()."index.php?controller=Team&action=statistic" ?>>
                                    <div class="form-group row">
                                        <label for="">วันเริ่มต้น</label>
                                        <input class="form-control" type="date" name="dateStart" required/>
                                    </div>
                                    <div class="form-group row">
                                        <label for="">วันสิ้นสุด</label>
                                        <input class="form-control" type="date" name="dateEnd" required/>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-lg mb-0 ">ตกลง</button>
                                </form>
                            </label>
                        </center>
                    </div>
                </div>
                <div></div>

            </div>
        </div>
    </div>
    <div class="container mt-3">
        <br/><h2 align="center">ตารางสถิติ</h2><br/>
        <?php
        $stable2 = $_SESSION['statisticTableByDate'];
        $i=1;
        echo "<table class='table table-striped table-dark'>
        <thead>
            <tr>
                <td>ลำดับ</td>
                <td>วันที่สั่ง</td>
                <td>หัวข้อ</td>
                <td>สถานะ</td>
                <td>ผู้รับงาน</td>
            </tr>
        </thead>";
        foreach ($stable2 as $s){
            echo "<tr style='background-color: whitesmoke; color: black'>
                    <td>$i</td>
                    <td>$s[start_date]</td><td>$s[topic]</td>";
            if($s[status_work]=="waiting")echo "<td style='background-color: gray'>รอดำเนินการ</td>";
            elseif ($s[status_work]=="process")echo "<td style='background-color: #4a8cdb'>ดำเนินการ</td>";
            elseif ($s[status_work]=="delivered")echo "<td style='background-color: yellow'>รอตรวจ</td>";
            elseif ($s[status_work]=="modify")echo "<td style='background-color: red'>แก้ไข</td>";
            else echo "<td style='background-color: #1dc116'>เสร็จสิ้น</td>";
            echo " <td>$s[worker]</td>
                   </tr>";
            $i++;
        }
        echo "</table>";
        $sum=0;
        foreach ($statisticByDate as $t)
            $sum+=$t[1];
        ?>
    </div>



    <script>
        Highcharts.chart('container', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: '<b>สถิติผู้ที่รับงานของคุณ</b>'
            },
            tooltip: {
                pointFormat: '<b>{point.name} : {point.y} งาน</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name} : {point.y} งาน</b>',
                        style: {
                            color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                        }
                    }
                }
            },
            series: [{
                name: 'Brands',
                colorByPoint: true,
                data: [
                    <?php
                    foreach ($statisticByDate as $s)
                    {
                        echo "{ name:'$s[0]' ,y:$s[1] },";
                    }
                    if($countByDate[0]>$sum)
                        echo "{ name:'งานที่ไม่มีผู้รับ' ,y:$countByDate[0]-$sum }";
                    ?>
                ]
            }]
        });
    </script>
<?php }}?>
<!--endScript-->

</body>
</html>