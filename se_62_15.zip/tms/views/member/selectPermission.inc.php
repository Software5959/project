<!DOCTYPE html>
<html lang="en">
<?php
if (!isset($_SESSION['member']) || !is_a($_SESSION['member'],"Member"))
{
    header("Location: " . Router::getSourcePath() . "index.php");
}
$title = "TMS";
$memberselect = $_SESSION['memberselect'];
$member = $_SESSION['member'];
$teamname=$_SESSION['teamname'];
require_once './inc/helper_func.inc.php';
ob_start();
?>
<body>

<div class="container  mt-5">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header bg-dark">
                    <h2 class="text-white">ชื่อทีม<?php
                        echo " ";
                        echo "$teamname";?>
                    </h2>
                </div>
                <div class="card-body">
                    <h4>ผู้สร้างทีม<span class="badge"><?php echo " ".$member->getName()." ".$member->getSurname();?></span></h4><br/>
                    <label class=form-group><h5>กำหนดสิทธิให้สมาชิก</h5></label>

                    <form method="post" action=<?= Router::getSourcePath()."index.php?controller=Team&action=create" ?>>
                        <?php  $i=1;
                        foreach($memberselect as $m){
                            echo "<div class=\"form-group\">";
                            echo "<label class=\"col-sm-2 col-form-label\">";
                            echo $m->getName()." ".$m->getSurname()."  ";
                            echo "</label>";
                            echo "&nbsp <input type=\"radio\" name=\"radio$i\" value='worker' checked> ผู้รับงาน &nbsp
                                        <input type=\"radio\" name=\"radio$i\" value='manager'> ผู้สั่งงาน ";
                            echo "</div>";
                            $i++;
                        }
                        ?>
                        <button type="submit" class="btn btn-primary btn-lg  ml-3">สร้างทีม</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


</body>
<?php
$content = ob_get_clean();

include Router::getSourcePath()."templates/layout.php";

?>
</html>
