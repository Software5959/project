<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <title>Document</title>
    <style>
        body{
            background-image: url("../../img/background.jpg");
            background-size: 100%;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
    </style>
</head>
<body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<nav class="navbar navbar-dark bg-dark">
    <span class="navbar-brand mb-0 h1"><img src="../../img/logo.png" alt="" width="150" height="60"></span>
    <form class="form-inline">

        <a class="btn btn-primary my-2 my-sm-0" href="http://158.108.207.4/WAD18_09/tms/">ย้อนกลับ</a>
    </form>
</nav>

<div class="container-fluid" style="margin-top: 8%">
    <div class="row">
        <div class="col" style="margin-left: 25%; margin-right: 25%">
            <h1 class="font-weight-bold">ลืมรหัสผ่าน</h1>
            <div class="regis-form" style="
                padding: 4% 4% ;
                box-sizing: border-box;
                background: rgba(0,0,0,0.1);">
                <form name="regisForm" id="regisForm" method="post"  >

                    <div class="form-group">
                        <label for="exampleInputPassword1"><h5 class="font-weight-light">กรุณาใส่อีเมลของคุณ</h5></label>
                        <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="someone@example.com" required>
                    </div>


                    <center><input type="submit" class="btn btn-primary add" value="ยืนยัน" ></center>

                </form>
            </div>
        </div>
    </div>

</div>

<script>

    $('#regisForm').on('submit',function (e) {
        e.preventDefault();

        var  email =  document.getElementById("email");





        $.ajax({
            url: "../../index.php?controller=Member&action=forget"  ,
            method : "POST",
            data:{
                email:email.value


            },

            success:function (data) {
                if(data=="no"){
                    $("#email").val("");
                    email.focus();
                    Swal.fire({
                        type: 'warning',
                        title: 'ไม่พบ e-mail นี้ในระบบ',
                        confirmButtonText: 'ตกลง'
                    });


                }
                else {
                    $("#email").val("");
                    email.focus();
                    Swal.fire({
                        type: 'success',
                        title: 'ส่งรหัสผ่านสำเร็จ'+data,
                        text: 'กรุณาเข้าเช็ค e-mail' ,
                        confirmButtonText: 'ตกลง'

                    });

                }

            }

        },);



    });


</script>

</body>
</html>