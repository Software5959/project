<!DOCTYPE html>
<html lang="en">
<?php
if (!isset($_SESSION['member']) || !is_a($_SESSION['member'],"Member"))
{
    header("Location: " . Router::getSourcePath() . "index.php");
}
$allWorkList = $allWorkList??"";
$member_AllWorkList = $member_AllWorkList??"";
$teamL = $teamList??"";
if(isset($notifyHistoryListByMember)){
    $notifyHistory = $notifyHistoryListByMember;
}

$title = "TMS";
require_once './inc/helper_func.inc.php';
ob_start();
?>
<body>

    <div class="row">
        <div class="col-3 mt-3 ">
            <span style="display: inline-flex ">
            <div style="width: 300px"  class="nav flex-column nav-pills ml-3 bg-light" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a id="pillAll" class="nav-link active"  data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="" aria-selected="true"><i class="fas fa-users fa-lg"></i> กลุ่มทั้งหมด</a>
                <?php
                $countCheckBar = 0;
                foreach ($teamL as $index => $obj) {
                    $count = 0;
                    if(isset($notifyHistory)){
                        foreach ($notifyHistory as $notify_id => $notify) {
                            if ("FALSE" == $notify->getNotify()&& $obj->getTeamId()==$notify->getTeamId()) {
                                $count++;
                            }
                        }
                    }

                    if ($count == 0) {
                        echo "<a class=\"nav-link\" id=\"pill{$obj->getTeamId()}\" data-toggle=\"pill\" href=\"#v-pills-{$obj->getTeamId()}\" role=\"tab\" aria-controls=\"v-pills-{$obj->getTeamId()}\" aria-selected=\"true\">{$obj->getName()} </a>";

                    } else {
                        $countCheckBar += $count;
                        echo "<a class=\"nav-link\" id=\"pill{$obj->getTeamId()}\" data-toggle=\"pill\" href=\"#v-pills-{$obj->getTeamId()}\" role=\"tab\" aria-controls=\"v-pills-{$obj->getTeamId()}\" aria-selected=\"true\">{$obj->getName()} <span id=\"notifyTeam{$obj->getTeamId()}\"  class=\"badge badge-pill badge-danger\">$count</span></a>";
                    }
                }
                    ?>
            </div>
                <div  class="nav flex-column navbar-link ">
                <a id="pillAllSetting" style="background: #f1f0fc;border-radius: 0px 20px 20px 0px" class="nav-link" href="<?= Router::getSourcePath()."index.php?controller=Team&action=showDetailAllTeam&status=worker" ?>"><i style="color: #007bff" class="fa fa-cog"></i></a>
                    <?php
                    foreach ($teamL as $index => $obj) {
                        echo "<a id=\"pillSetting{$obj->getTeamId()}\" style=\"background: #f1f0fc;border-radius: 0px 20px 20px 0px\" class=\"nav-link\" href=\"".Router::getSourcePath()."index.php?controller=Team&action=showDetailTeam&team_id=".$obj->getTeamId()."\"><i style=\"color: #007bff\" class=\"fa fa-cog\"></i></a>";
                    }
                    ?>
                </div>
            </span>
        </div>

        <div class="col-8 ml-5 mt-3 ">
            <div class="tab-content mt-2" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                    <div align="left">
                    <table id="customTableAll" class="table table-striped table-bordered dataTable" style="width: 100%;" role="grid"
                           aria-describedby="example_info">
                        <thead>
                        <tr class="table-active">
                            <th scope="col">ลำดับ</th>
                            <th scope="col">หัวข้อ</th>
                            <th scope="col">ผู้สั่ง</th>
                            <th scope="col">ระยะเวลาที่เหลือ</th>
                            <th scope="col">รายละเอียด</th>
                            <th scope="col">รับงาน</th>
                        </tr>
                        </thead>
                        <?php
                        $j=1;
                        foreach ($allWorkList as $work_id => $obj) {
                            $new = NULL;
                            $tagNew = NULL;
                            if(isset($notifyHistory)) {
                                $new = NULL;
                                foreach ($notifyHistory as $notify_id => $notify) {
                                    if ($notify->getWorkId() == $obj->getWorkId()&&$notify->getNotify()=="FALSE") {
                                        $new = $notify->getNotifyHistoryId();
                                        break;
                                    }
                                }
                                $tagNew = NULL;
                                if ($new) {
                                    $tagNew = "<h5 style=\"float: left;margin-left: 10px\"><span class=\"badge badge-danger\">New</span></h5>";
                                }
                            }

                            $endDateTime = new DateTime($obj->getEndDate()." ".$obj->getEndTime());
                            $interval = calculateBetweenPeriodOfTime($endDateTime);
                            $path = Router::getSourcePath()."index.php?controller=Work&action=receiveWork&work_id=".$obj->getWorkId();
                            echo "
                        <tr>
                            <td>$j</td>
                            <td><div style=\"float: left;\">{$obj->getTopic()}</div> <div class=\"notifyNew{$obj->getWorkId()}\">$tagNew</div></td>
                            <td>{$member_AllWorkList[$obj->getManagerId()]->getUsername()}</td>
                            <td>{$interval}</td>
                            <td><div class=\"notify{$obj->getWorkId()}\" value=\"{$new}\"><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalAllId{$obj->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></div></td>
                            <td><a href=\"$path\"><button type=\"button\" class=\"btn btn-success\">รับงาน</button></a></td>
                        </tr>";
                            $startDate = formatDate($obj->getStartDate());
                            $endDate = formatDate($obj->getEndDate());
                            echo "<div id=\"ModalAllId{$obj->getWorkId()}\" class=\"modal fade bd-example-modal-lg\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myLargeModalLabel\" aria-hidden=\"true\">
                                <div class=\"modal-dialog modal-lg\">
                                    <div class=\"modal-content\" align='left'>
                                        <div class=\"modal-header\">
                                            <h5 class=\"modal-title\">หัวข้อ: {$obj->getTopic()}</h5>
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                               <span aria-hidden=\"true\" style='font-size: 35px'>×</span>
                                            </button>
                                        </div>
                                        <div class=\"modal-body\">
                                           <p><b>ผู้สั่งงาน</b> {$member_AllWorkList[$obj->getManagerId()]->getUsername()}</p>
                                           <p><b>วันที่สั่งงาน</b> $startDate</p>
                                           <p><b>กำหนดส่งงาน</b> $endDate</p>
                                        <p><b>รายละเอียด</b> {$obj->getDetail()}</p>
                                        </div>
                                    </div>
                                </div>
                              </div>";
                            $j++;
                        }
                        ?>
                    </table>
                    </div>
                </div>
                <?php
                $i=1;
                foreach ($teamL as $team_id => $team)
                {
                    echo "<div class=\"tab-pane fade\" id=\"v-pills-$team_id\" role=\"tabpanel\" aria-labelledby=\"v-pills-$team_id-tab\">";
                    echo "<div align=\"left\">";
                    echo "<table id=\"customTable{$i}\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
                                   aria-describedby=\"example_info\">";
                    echo "<thead><tr class=\"table-active\">
                            <th scope=\"col\">ลำดับ</th>
                            <th scope=\"col\">หัวข้อ</th>
                            <th scope=\"col\">ผู้สั่ง</th>
                            <th scope=\"col\">ระยะเวลาที่เหลือ</th>
                            <th scope=\"col\">รายละเอียด</th>
                            <th scope=\"col\">รับงาน</th>
                        </tr></thead>";
                    $j = 1;
                    foreach ($allWorkList as $work_id => $work)
                    {
                        if($work->getTeamId()==$team->getTeamId()){
                            $new = NULL;
                            $tagNew = NULL;
                            if(isset($notifyHistory)) {
                                $new = NULL;
                                foreach ($notifyHistory as $notify_id => $notify) {
                                    if ($notify->getWorkId() == $work->getWorkId()&&$notify->getNotify()=="FALSE") {
                                        $new = $notify->getNotifyHistoryId();
                                        break;
                                    }
                                }
                                $tagNew = NULL;
                                if ($new) {
                                    $tagNew = "<h5 style=\"float: left;margin-left: 10px\"><span class=\"badge badge-danger\">New</span></h5>";
                                }
                            }

                            $endDateTime = new DateTime($work->getEndDate()." ".$work->getEndTime());
                            $interval = calculateBetweenPeriodOfTime($endDateTime);
                            $path = Router::getSourcePath()."index.php?controller=Work&action=receiveWork&work_id=".$work->getWorkId();
                            echo "
                        <tr>
                            <td>$j</td>
                            <td><div style=\"float: left;\">{$work->getTopic()}</div> <div class=\"notifyNew{$work->getWorkId()}\">$tagNew</div></td>
                            <td>{$member_AllWorkList[$work->getManagerId()]->getUsername()}</td>
                            <td>{$interval}</td>
                            <td><div class=\"notify{$obj->getWorkId()}\" value=\"{$new}\"><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#ModalId{$work->getWorkId()}\"><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></div></td>
                            <td><a href=\"$path\"><button type=\"submit\" class=\"btn btn-success\">รับงาน</button></a></td>
                        </tr>";
                            $startDate = formatDate($work->getStartDate());
                            $endDate = formatDate($work->getEndDate());
                            echo "<div id=\"ModalId{$work->getWorkId()}\" class=\"modal fade bd-example-modal-lg\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myLargeModalLabel\" aria-hidden=\"true\">
                                <div class=\"modal-dialog modal-lg\">
                                    <div class=\"modal-content\" align='left'>
                                        <div class=\"modal-header\">
                                            <h5 class=\"modal-title\">หัวข้อ: {$work->getTopic()}</h5>
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                                <span aria-hidden=\"true\" style='font-size: 35px'>×</span>
                                            </button>
                                        </div>
                                        <div class=\"modal-body\">
                                           <p><b>ผู้สั่งงาน</b> คงเดช</p>
                                           <p><b>วันที่สั่งงาน</b> $startDate</p>
                                           <p><b>กำหนดส่งงาน</b> $endDate</p>
                                        <p><b>รายละเอียด</b> {$work->getDetail()}</p>
                                        </div>
                                    </div>
                                </div>
                              </div>";
                            $j++;
                        }

                    }
                    echo "</table></div></div>";
                    $i++;
                }
                ?>
            </div>
            </div>
        </div>

    </div>
    <script>

        function setupNotify(){
            var WorkIdList = <?= json_encode($allWorkList) ?>;
            var count = <?= $countCheckBar??null ?>;
            if(count>0){
                $('#NotifyWorkerPoint').attr('hidden',null);
            }
            $(document).ajaxComplete(function(){
                count--;
                if(count==0){
                    $('#NotifyWorkerPoint').attr('hidden',true);
                }
            });
            if(WorkIdList) {
                for(let work_id in WorkIdList){
                    $('.notify'+work_id).click(function () {
                        if($(this).attr('value')!=null) {
                            var id = $(this).attr('value');
                            $.ajax({
                                url: "<?= Router::getSourcePath()?>" + "index.php?controller=Work&action=offNotify",
                                method: "post",
                                data: {id: id},
                                dataType: "json",
                                success: function (data) {
                                    var num = $('#notifyTeam' + data.team_id).html();
                                    num--;
                                    $('#notifyTeam' + data.team_id).html(num);
                                    if ($('#notifyTeam' + data.team_id).html() == 0) {
                                        $('#notifyTeam' + data.team_id).hide();
                                    }
                                    $('.notifyNew' + data.work_id).hide();
                                }
                            });
                            $(this).attr('value', null);
                        }
                    });
                }
            }
        }
        $(document).ready(function () {
            setupNotify();
            var NumCustomTable = <?= $i ?>;
            if (NumCustomTable) {
                for (var i = 1; i < NumCustomTable; i++) {
                    $('#customTable' + i).DataTable({
                        "order": [],
                        "columnDefs": [{
                            "targets": 'no-sort',
                            "orderable": false
                        }],
                        "oLanguage": {
                            "sEmptyTable": "ไม่มีข้อมูลในตาราง",
                            "sInfo": "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                            "sInfoEmpty": "แสดง 0 ถึง 0 จาก 0 แถว",
                            "sInfoFiltered": "(กรองข้อมูล _MAX_ ทุกแถว)",
                            "sInfoPostFix": "",
                            "sInfoThousands": ",",
                            "sLengthMenu": "แสดง _MENU_ แถว",
                            "sLoadingRecords": "กำลังโหลดข้อมูล...",
                            "sProcessing": "กำลังดำเนินการ...",
                            "sSearch": "ค้นหา: ",
                            "sZeroRecords": "ไม่พบข้อมูล",
                            "oPaginate": {
                                "sFirst": "หน้าแรก",
                                "sPrevious": "ก่อนหน้า",
                                "sNext": "ถัดไป",
                                "sLast": "หน้าสุดท้าย"
                            },
                            "oAria": {
                                "sSortAscending": ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                                "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                            }
                        }
                    });
                }
                $('#customTableAll').DataTable({
                    "order": [],
                    "columnDefs": [{
                        "targets": 'no-sort',
                        "orderable": false
                    }],
                    "oLanguage": {
                        "sEmptyTable": "ไม่มีข้อมูลในตาราง",
                        "sInfo": "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                        "sInfoEmpty": "แสดง 0 ถึง 0 จาก 0 แถว",
                        "sInfoFiltered": "(กรองข้อมูล _MAX_ ทุกแถว)",
                        "sInfoPostFix": "",
                        "sInfoThousands": ",",
                        "sLengthMenu": "แสดง _MENU_ แถว",
                        "sLoadingRecords": "กำลังโหลดข้อมูล...",
                        "sProcessing": "กำลังดำเนินการ...",
                        "sSearch": "ค้นหา: ",
                        "sZeroRecords": "ไม่พบข้อมูล",
                        "oPaginate": {
                            "sFirst": "หน้าแรก",
                            "sPrevious": "ก่อนหน้า",
                            "sNext": "ถัดไป",
                            "sLast": "หน้าสุดท้าย"
                        },
                        "oAria": {
                            "sSortAscending": ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                            "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                        }
                    }
                });
            }
        });
    </script>


</body>

<?php
$content = ob_get_clean();

include Router::getSourcePath()."templates/layout.php";

?>
</html>