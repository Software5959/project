<!DOCTYPE html>
<html lang="en">
<?php
if (!isset($_SESSION['member']) || !is_a($_SESSION['member'],"Member"))
{
    header("Location: " . Router::getSourcePath() . "index.php");
}

$teamL = $teamL;
$headL = $headL??null;
$memberOfTeam = $memberOfTeam??null;

$title = "TMS";
require_once './inc/helper_func.inc.php';
ob_start();
?>
<body>
<div class="container-fluid col-11 mt-4">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h1>รายละเอียดทีมทั้งหมด</h1>
                </div>
                <div class="card-body">
                    <div align="left">
                    <table id="customTable" class="table table-striped table-bordered dataTable" role="grid" aria-describedby="example_info">
                    <thead>
                        <tr class="table-active">
                            <th scope="col"><center>ลำดับ</center></th>
                            <th scope="col"><center>ชื่อทีม</center></th>
                            <th scope="col"><center>หัวหน้าทีม</center></th>
                            <th scope="col"><center>จำนวนสมาชิกทีม</center></th>
                            <th scope="col"><center>รายละเอียดสมากชิก</center></th>
                        </tr>
                    </thead>
                            <?php
                            $i = 1;
                            foreach ($teamL as $team_id => $team){
                                $numMem = 0;
                                foreach ($memberOfTeam[$team_id] as $mem_id => $mem){
                                    $numMem++;
                                }
                                echo "<tr><td><center>$i</center></td>
                            <td><center>{$team->getName()}</center></td>
                            <th ><center>{$headL[$team_id]->getUsername()}</center></th>
                            <td><center>$numMem</center></td>
                            <td><center><a href=\"". Router::getSourcePath()."index.php?controller=Team&action=showDetailTeam&team_id=".$team_id."\"><button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" ><i class=\"fas fa-search\"></i> ดูรายละเอียด</button></a></center></td></tr>";
                            $i++;
                            }
                            ?>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script>
    $('#customTable').DataTable( {
        "order": [],
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false
        }],
        "oLanguage": {
            "sEmptyTable":     "ไม่มีข้อมูลในตาราง",
            "sInfo":           "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
            "sInfoEmpty":      "แสดง 0 ถึง 0 จาก 0 แถว",
            "sInfoFiltered":   "(กรองข้อมูล _MAX_ ทุกแถว)",
            "sInfoPostFix":    "",
            "sInfoThousands":  ",",
            "sLengthMenu":     "แสดง _MENU_ แถว",
            "sLoadingRecords": "กำลังโหลดข้อมูล...",
            "sProcessing":     "กำลังดำเนินการ...",
            "sSearch":         "ค้นหา: ",
            "sZeroRecords":    "ไม่พบข้อมูล",
            "oPaginate": {
                "sFirst":    "หน้าแรก",
                "sPrevious": "ก่อนหน้า",
                "sNext":     "ถัดไป",
                "sLast":     "หน้าสุดท้าย"
            },
            "oAria": {
                "sSortAscending":  ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
            }
        }
    });
</script>
<?php
$content = ob_get_clean();

include Router::getSourcePath()."templates/layout.php";

?>
</html>