<!DOCTYPE html>
<html lang="en">
<head>
    <link href="inc/fSelect.css" rel="stylesheet">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script src="inc/fSelect.js"></script>
    <script>
        (function($) {
            $(function() {
                $('#multi-select-dd').fSelect();
            });
        })(jQuery);
    </script>
</head>
<?php
if (!isset($_SESSION['member']) || !is_a($_SESSION['member'],"Member"))
{
    header("Location: " . Router::getSourcePath() . "index.php");
}
$title = "TMS";
$mem = $_SESSION['mem'];
require_once './inc/helper_func.inc.php';
ob_start();
?>
<body>
<!--Content-->
<!--
<div class="container mt-5">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h2>สร้างทีม</h2>
                </div>
                <div class="card-body" style="background-color: #e6e6e6">
                    <form method="post" action=<?= Router::getSourcePath()."index.php?controller=Team&action=selectPer" ?>>
                        <div class="form-group">
                            <label for=""><b>ชื่อทีม</b></label><br/><input class="" type="text" name="teamname" placeholder=" กรุณาตั้งชื่อทีม" required>
                        </div>
                        <div class="form-group">
                            <label for=""><b>เลือกสมาชิกทีม</b></label><br/><select name="multimem[]" id="multi-select-dd" multiple="multiple" required>
                                <?php foreach($mem as $m){echo '<option value="'.$m->getMemId().'" >'.$m->getName()." ".$m->getSurname().'</option>'; }?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg mb-3 mt-2">ตกลง</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>-->

<div class="container-fluid">
    <div class="contact-form">
        <div class="create-form"
            style="position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            padding: 2% 15%;
            box-sizing: border-box;
            background: rgba(0,0,0,.4);">
            <h1 class="text-white font-weight-bold" style="align-items: center; margin-bottom: 10%">สร้างทีม</h1>
            <form method="post" action=<?= Router::getSourcePath()."index.php?controller=Team&action=selectPer" ?>>

                <div class="form-group">
                    <label for="inputEmail3" class="text-white"><b class="font-weight-light">ชื่อทีม</b></label><br/>
                    <input class="" type="text" name="teamname" placeholder=" กรุณาตั้งชื่อทีม" required>
                </div>
                <div class="form-group">
                    <label for="inputEmail3" class="text-white"><b class="font-weight-light">เลือกสมาชิกทีม</b></label><br/>
                    <select name="multimem[]" id="multi-select-dd" multiple="multiple" required>
                        <?php foreach($mem as $m){echo '<option value="'.$m->getMemId().'" >'.$m->getName()." ".$m->getSurname().'</option>'; }?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-lg mb-3 mt-2">ตกลง</button>
            </form>
        </div>
    </div>
</div>
</body>
<?php
$content = ob_get_clean();

include Router::getSourcePath()."templates/layout.php";

?>
</html>
