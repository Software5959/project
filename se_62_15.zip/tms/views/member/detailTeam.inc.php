<!DOCTYPE html>
<html lang="en">
<head>
    <link href="inc/fSelect.css" rel="stylesheet">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script src="inc/fSelect.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
    <script>
        (function($) {
            $(function() {
                $('#multi-select-dd').fSelect();
                $('#multi-select-ddd').fSelect();
            });
        })(jQuery);
    </script>
</head>
<?php
//if (!isset($_SESSION['member']) || !is_a($_SESSION['member'],"Member"))
//{
//    header("Location: " . Router::getSourcePath() . "index.php");
//}

$team = $team??null;
$teamMemberList = $teamMemberList??null;
$memberOfTeam = $memberOfTeam??null;
$head = $head??null;
$mem = $_SESSION['addmem'];

$title = "TMS";
require_once './inc/helper_func.inc.php';
ob_start();

?>

<body>
<div class="container-fluid col-11 mt-4">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h1 style="float: left">รายละเอียดสมากชิกทีม <?= $team->getName() ?></h1>
                    <?php
                    $teamMember = NULL;
                    foreach ($teamMemberList as $id => $obj) {
                        if($obj->getMemId()==$member->getMemId()){
                            $teamMember = $obj;
                            break;
                        }
                    }
                        if($head->getMemId()!=$member->getMemId()){
                            echo "<button style=\"float: right;\" type=\"button\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#ModalConfirmOutTeamMe\"><i class=\"fas fa-times-circle\"></i> ออกจากทีม</button>";
                        }else{
                            echo "<button style=\"float: right;\" type=\"button\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#ModalConfirmDeleteTeam\"><i class=\"fas fa-times-circle\"></i> ลบทีม</button>";
                            echo "<button style=\"float: right;\" type=\"button\" class=\"btn btn-success mr-2\" data-toggle=\"modal\" data-target=\"#ModalAdd\"><i class=\"fas fa-plus-circle\"></i> เพิ่มผู้รับงาน</button>";
                            echo "<button style=\"float: right;\" type=\"button\" class=\"btn btn-warning text-white mr-2\" data-toggle=\"modal\" data-target=\"#ModalAdd2\"><i class=\"fas fa-plus-circle\"></i> เพิ่มผู้สั่งงาน</button>";
                        }

                    foreach ($teamMemberList as $id => $obj){
                        if($obj->getMemId()==$member->getMemId()&&$obj->getStatus()=='manager'){
                            echo "<a href=./index.php?controller=Team&action=statistic class=\"btn btn-primary mr-2 text-white\" style=\"float: right;\" ><i class=\"fas fa-signal\"></i> สถิติ</a>";
                            break;
                        }
                    }

                    ?>
                    <!--modaladd-->
                    <div class="modal fade" id="ModalAdd" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title" id="exampleModalLabel">เพิ่มผู้รับงาน</h2>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form method="post" action=<?= Router::getSourcePath()."index.php?controller=Team&action=add" ?>>
                                <div class="modal-body edit-content" id="edit-content">
                                    <div align="left">
                                    <b>เลือกสมาชิก</b><br/>
                                    <select name="multiadd[]" id="multi-select-dd" multiple="multiple" required>
                                        <?php foreach($mem as $m){echo '<option value="'.$m->getMemId().'" >'.$m->getName()." ".$m->getSurname().'</option>'; }?>
                                    </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>

                                    <button type="submit"  class="btn btn-primary">เพิ่ม</button>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--modaladd-->
                    <div class="modal fade" id="ModalAdd2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title" id="exampleModalLabel">เพิ่มผู้สั่งงาน</h2>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form method="post" action=<?= Router::getSourcePath()."index.php?controller=Team&action=add2" ?>>
                                    <div class="modal-body edit-content" id="edit-content">
                                        <div align="left">
                                            <b>เลือกสมาชิก</b><br/>
                                            <select name="multiadd2[]" id="multi-select-ddd" multiple="multiple" required>
                                                <?php foreach($mem as $m){echo '<option value="'.$m->getMemId().'" >'.$m->getName()." ".$m->getSurname().'</option>'; }?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>

                                        <button type="submit"  class="btn btn-primary" >เพิ่ม</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="ModalConfirmOutTeamMe" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title" id="exampleModalLabel"></h2>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body edit-content" id="edit-content">
                                    <span style="display: inline-flex"><h4>คุณยืนยันที่จะออกจากทีม</h4><h4></h4></span>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">ยกเลิก</button>
                                    <?php
                                    echo "<form  method=\"post\" action=".Router::getSourcePath()."index.php?controller=Team&action=outTeamMe".">
                    <input type=\"hidden\" value=\"{$teamMember->getTeamworkId()}\" name=\"teamMember_id\" id='teamMember_id' ><button type=\"submit\"  class=\"btn btn-primary\" >ยืนยัน</button>
                   </form>";
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="ModalConfirmDeleteTeam" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2 class="modal-title" id="exampleModalLabel"></h2>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body edit-content" id="edit-content">
                                <span style="display: inline-flex"><h4>คุณยืนยันที่จะลบทีม</h4><h4></h4></span>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">ยกเลิก</button>
                                <?php
                                echo "<form  method=\"post\" action=".Router::getSourcePath()."index.php?controller=Team&action=deleteTeam".">
                                <input type=\"hidden\" value=\"{$teamMember->getTeamworkId()}\"  name=\"teamMember_id\" id='teamMember_id' ><button type=\"submit\"  class=\"btn btn-primary\" >ยืนยัน</button>
                                    </form>";
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                <?php
                        if($head->getMemId()==$member->getMemId())
                        {
                            ?>
                            <div class="card-body">
                                <div align="left">
                                    <table id="customTable1" class="table table-striped table-bordered dataTable" role="grid" aria-describedby="example_info">
                                        <thead>
                                        <tr class="table-active">
                                            <th scope="col"><center>ลำดับ</center></th>
                                            <th scope="col"><center>ชื่อผู้ใช้</center></th>
                                            <th scope="col"><center>ชื่อ</center></th>
                                            <th scope="col"><center>นามสกุล</center></th>
                                            <th scope="col"><center>อีเมล</center></th>
                                            <th scope="col"><center>สถานะ</center></th>
                                            <th scope="col"><center>จัดการผู้ใช้</center></th>
                                        </tr>
                                        </thead>
                                        <?php
                                        $i = 1;
                                        foreach ($memberOfTeam as $mem_id => $mem){
                                            $status = NULL;
                                            $teamMem = NULL;
                                            if($head->getMemId()==$mem->getMemId()) continue;
                                            foreach ($teamMemberList as $teamMember_id => $teamMember){
                                                if($teamMember->getMemId()==$mem_id){
                                                    $teamMem =$teamMember ;
                                                    if($teamMember->getStatus()=="worker"){
                                                        $status = "ผู้รับงาน";
                                                    }else if($teamMember->getStatus()=="manager"){
                                                        $status = "ผู้สั่งงาน";
                                                    }
                                                }
                                            }
                                            echo "<tr><td><center>$i</center></td>
                            <th><center>{$mem->getUsername()}</center></th>
                            <th ><center>{$mem->getName()}</center></th>
                            <th><center>{$mem->getSurname()}</center></th>
                            <th><center>{$mem->getEmail()}</center></th>
                            <th><center id=\"status{$teamMem->getTeamworkId()}\">$status</center></th>
                            <th><center>
                                        <div class=\"dropdown\">
                                            <button class=\"btn btn-primary\"><i class=\"fas fa-cog\"></i> จัดกาาร</button>
                                            <div class=\"dropdown-content\" style=\"left:0;\">
                                                <a id=\"changeStatus{$teamMem->getTeamworkId()}\"  class=\"ChangeStatus\" name=\"{$mem->getUsername()}\" value=\"{$teamMem->getTeamworkId()}\" data-toggle=\"modal\" data-target=\"#ModalConfirmChangeStatus\"><i class=\"far fa-edit\"></i> เปลี่ยนสถานะ</a>
                                                <a id=\"outTeam{$teamMem->getTeamworkId()}\" class=\"OutTeam\" name=\"{$mem->getUsername()}\"  value=\"{$teamMem->getTeamworkId()}\" data-toggle=\"modal\" data-target=\"#ModalConfirmOutTeam\"><i class=\"fas fa-sign-out-alt\"></i> ออกจากทีม</a>
                                            </div>
                                        </div>
                            </center></th></tr>";
                                            $i++;
                                        }
                                        ?>
                                    </table>
                                </div>
                            </div>
                            <?php
                        }else {
                            ?>
                            <div class="card-body">
                                <div align="left">
                                    <table id="customTable2" class="table table-striped table-bordered dataTable"
                                           role="grid" aria-describedby="example_info">
                                        <thead>
                                        <tr class="table-active">
                                            <th scope="col">
                                                <center>ลำดับ</center>
                                            </th>
                                            <th scope="col">
                                                <center>ชื่อผู้ใช้</center>
                                            </th>
                                            <th scope="col">
                                                <center>ชื่อ</center>
                                            </th>
                                            <th scope="col">
                                                <center>นามสกุล</center>
                                            </th>
                                            <th scope="col">
                                                <center>อีเมล</center>
                                            </th>
                                            <th scope="col">
                                                <center>สถานะ</center>
                                            </th>
                                        </tr>
                                        </thead>
                                        <tr>
                                            <th>
                                                <center>1</center>
                                            </th>
                                            <th>
                                                <center><?= $head->getUsername() ?></center>
                                            </th>
                                            <th>
                                                <center><?= $head->getName() ?></center>
                                            </th>
                                            <th>
                                                <center><?= $head->getSurname() ?></center>
                                            </th>
                                            <th>
                                                <center><?= $head->getEmail() ?></center>
                                            </th>
                                            <th>
                                                <center>หัวทีม</center>
                                            </th>
                                        </tr>
                                        </tr>
                                        <?php
                                        $i = 2;
                                        foreach ($memberOfTeam as $mem_id => $mem) {
                                            $status = NULL;
                                            if($head->getMemId()==$mem->getMemId()) continue;
                                            foreach ($teamMemberList as $teamMember_id => $teamMember) {
                                                if ($teamMember->getMemId() == $mem_id) {
                                                    if ($teamMember->getStatus() == "worker") {
                                                        $status = "ผู้รับงาน";
                                                    } else if ($teamMember->getStatus() == "manager") {
                                                        $status = "ผู้สั่งงาน";
                                                    }
                                                }
                                            }
                                            echo "<tr><td><center>$i</center></td>
                            <th><center>{$mem->getUsername()}</center></th>
                            <th ><center>{$mem->getName()}</center></th>
                            <th><center>{$mem->getSurname()}</center></th>
                            <th><center>{$mem->getEmail()}</center></th>
                            <th><center>$status</center></th>";
                                            $i++;
                                        }
                                        ?>
                                    </table>
                                </div>
                            </div>
                            <?php
                        }
                ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal ChangeStatus -->
<div class="modal fade" id="ModalConfirmChangeStatus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLabel"></h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body edit-content" id="edit-content">
                <span style="display: inline-flex"><h4>คุณยืนยันเปลี่ยนสถานะ</h4><h4 id=\"nameChangeStatus\"></h4></span>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">ยกเลิก</button>
                <?php
                echo "<input type=\"hidden\" name=\"teamMember_id\" id='idChangeStatus' ><button type=\"button\" id=\"btnChangeStatus\"  class=\"btn btn-primary\" data-dismiss=\"modal\">ยืนยัน</button>";
                ?>
            </div>
        </div>
    </div>
</div>
<!-- Modal OutTeam -->
<div class="modal fade" id="ModalConfirmOutTeam" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLabel"></h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body edit-content" id="edit-content">
                <span style="display: inline-flex"><h4>คุณยืนยันที่จะไล่ออกจากทีม</h4><h4 id=\"targetChangeStatus\"></h4></span>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">ยกเลิก</button>
                <?php
                echo "<form  method=\"post\" action=".Router::getSourcePath()."index.php?controller=Team&action=outTeam".">
                    <input type=\"hidden\" name=\"teamMember_id\" id='idOutTeam' ><button type=\"submit\"  class=\"btn btn-primary\" >ยืนยัน</button>
                   </form>";
                ?>
            </div>
        </div>
    </div>
</div>

</body>
<script>
    $('.OutTeam').click(function () {
        var teamMember_id = $(this).attr('value');
        $('#idOutTeam').attr('value',teamMember_id);
    });
    $('.ChangeStatus').click(function () {
        var teamMember_id = $(this).attr('value');
        $('#idChangeStatus').attr('value',teamMember_id);
    });
    function changeStatus() {
        $('#btnChangeStatus').click(function () {
            var id = $('#idChangeStatus').attr('value');
            $.ajax({
                url: "<?= Router::getSourcePath()?>" + "index.php?controller=Team&action=changeStatus",
                method: "post",
                data: {id: id},
                success: function (data) {
                    if (data == 'worker') {
                        $('#status' + id).html('ผู้รับงาน');
                        Swal.fire({
                            type: 'success',
                            title: 'เปลี่ยนสถานะสำเร็จ',

                            confirmButtonText: 'ตกลง'

                        });
                    } else if (data == 'manager') {
                        $('#status' + id).html('ผู้สั่งงาน');
                        Swal.fire({
                            type: 'success',
                            title: 'เปลี่ยนสถานะสำเร็จ',

                            confirmButtonText: 'ตกลง'
                        });
                    }
                }
            });
        });
    }
    $(document).ready(function() {
        changeStatus();
        $('#customTable1').DataTable({
            "order": [],
            "columnDefs": [{
                "targets": 'no-sort',
                "orderable": false
            }],
            "oLanguage": {
                "sEmptyTable": "ไม่มีข้อมูลในตาราง",
                "sInfo": "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty": "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered": "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix": "",
                "sInfoThousands": ",",
                "sLengthMenu": "แสดง _MENU_ แถว",
                "sLoadingRecords": "กำลังโหลดข้อมูล...",
                "sProcessing": "กำลังดำเนินการ...",
                "sSearch": "ค้นหา: ",
                "sZeroRecords": "ไม่พบข้อมูล",
                "oPaginate": {
                    "sFirst": "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext": "ถัดไป",
                    "sLast": "หน้าสุดท้าย"
                },
                "oAria": {
                    "sSortAscending": ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                    "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                }
            }
        });
        $('#customTable2').DataTable({
            "order": [],
            "columnDefs": [{
                "targets": 'no-sort',
                "orderable": false
            }],
            "oLanguage": {
                "sEmptyTable": "ไม่มีข้อมูลในตาราง",
                "sInfo": "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
                "sInfoEmpty": "แสดง 0 ถึง 0 จาก 0 แถว",
                "sInfoFiltered": "(กรองข้อมูล _MAX_ ทุกแถว)",
                "sInfoPostFix": "",
                "sInfoThousands": ",",
                "sLengthMenu": "แสดง _MENU_ แถว",
                "sLoadingRecords": "กำลังโหลดข้อมูล...",
                "sProcessing": "กำลังดำเนินการ...",
                "sSearch": "ค้นหา: ",
                "sZeroRecords": "ไม่พบข้อมูล",
                "oPaginate": {
                    "sFirst": "หน้าแรก",
                    "sPrevious": "ก่อนหน้า",
                    "sNext": "ถัดไป",
                    "sLast": "หน้าสุดท้าย"
                },
                "oAria": {
                    "sSortAscending": ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                    "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
                }
            }
        });
    });
</script>
<?php
$content = ob_get_clean();

include Router::getSourcePath()."templates/layout.php";

?>
</html>