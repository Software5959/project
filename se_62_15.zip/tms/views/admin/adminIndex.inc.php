<!DOCTYPE html>
<html lang="en">
<?php
if (!isset($_SESSION['admin']) || !is_a($_SESSION['admin'],"Member"))
{
header("Location: ".Router::getSourcePath()."index.php");
}?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <title>Document</title>
    <style>
        body{
            background-image: url("./img/background.jpg");
            background-size: 100%;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
    </style>

    <!-- DataTables-->
    <link rel="stylesheet" type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">

    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"
            async=""></script>
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" language="javascript"
            src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


</head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<?php
$admin=$_SESSION["admin"];
$memList=$_SESSION["memList"];
$id=$admin->getMemId();
$user=$admin->getUsername();
$pass = $admin->getPassword();
$permis = $admin->getPermission();
require_once Router::getSourcePath()."inc/helper_func.inc.php";
?>
<!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <span class="navbar-brand mb-0 h1"><img src="./img/logo.png" alt="" width="150" height="60"></span>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="nav nav-pills mr-auto">
            <li class="nav-item">
                <!--<a class="nav-link active text-white" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true"><i class="fas fa-home"></i> หน้าหลัก</a>-->
            </li>
        </ul>
        <form class="form-inline">
            <div class="input-group mb-0 mr-sm-2">
                <div class="input-group-prepend ">
                </div>
                <div class="text-white mt-3">
                    <a class = "nav-link text-white" href="#myProfile" data-toggle="modal">
                        <i class="far fa-user fa-lg mr-2" style="color:#ffffff;"></i><?php echo"<h8>".$admin->getName()." ".$admin->getSurname()."</h8>";?>
                    </a>
                </div>
            </div>
            <a class="btn btn-primary text-white mb-0 mt-3" <a href=<?= Router::getSourcePath()."index.php?controller=Member&action=logout"?>><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>

        </form>
    </div>
</nav>






<!--Content-->
<div class="container mt-3">
    <h1 align="center">จัดการผู้ใช้</h1>
    <button class ="btn btn-primary mb-2" type="submit" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo"><i class="fas fa-user-plus fa-lg"></i> เพิ่มผู้ใช้งาน</button>
    <?php
    $header = array("ลำดับ","ชื่อผู้ใช้","ชื่อ","นามสกุล","อีเมล","สถานะ","แก้ไขผู้ใช้","ลบผู้ใช้");
    $data = array();
    $i = 0;
    //var_dump($memList);
    foreach ($memList as $mem) {
        //var_dump($mem);
        if ($mem->getMemId()!=$admin->getMemId()) {
            $data[$i] = array($i + 1, $mem->getUsername(), $mem->getName(), $mem->getSurname(), $mem->getEmail(), $mem->getPermission(),

                "<button class=\"btn btn-primary edit_spec2\" type=\"submit\" data-toggle=\"modal\" data-target=\"#exampleModal2\" data-userName=" . $mem->getUsername() . " data-name=" . $mem->getName() . " data-surname=" . $mem->getSurname() . " data-email=" . $mem->getEmail() . " data-per=" . $mem->getPermission() . " data-userID=" . $mem->getMemId() . " data-pass=" . $mem->getPassword() . ">แก้ไขผู้ใช้</button>",

                "<form  method=\"post\" ><input hidden name=\"memID\" id=\"ID\" value=" . $mem->getMemId() . "> <button type=\"button\" name='delete' id=".$mem->getMemId()." data-name2=" . $mem->getName() . " data-surname2=" . $mem->getSurname() . " data-id=" . $mem->getMemId() . " class=\"btn btn-danger delete1\" data-toggle=\"modal\" data-target=\"#exampleModal3\">ลบผู้ใช้</button></form>");

            $i++;
        }
    }

    ?>
    <table id="memberTable" class="table table-striped table-bordered dataTable" style="width: 100%;" role="grid"
           aria-describedby="example_info">
        <thead>
        <tr class="table-active">
            <th scope="col">ลำดับ</th>
            <th scope="col">ชื่อผู้ใช้</th>
            <th scope="col">ชื่อ</th>
            <th scope="col">นามสกุล</th>
            <th scope="col">อีเมลล์</th>
            <th scope="col">สถานะ</th>
            <th scope="col">แก้ไขผู้ใช้</th>
            <th scope="col">ลบผู้ใช้</th>
        </tr>
        </thead>
       <?php echo "</tr>";
        foreach ($data as $row) {
        echo "<tr>";
            foreach ($row as $col){
            echo "<td>$col</td>";
            }
            echo "</tr>";
        }?>
    </table>

</div>


<!--ModalCreateUser-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <form id="regis" action=<?= Router::getSourcePath()."index.php?controller=Member&action=regis" ?> method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">เพิ่มสมาชิก</h5>

                </div>
                <div class="modal-body">
                    <div class="form-group">

                        <div class="form-group">
                            <label for="" class="">ชื่อผู้ใช้</label>
                            <input class="form-control" type="text" name="username" id="username" placeholder="ชื่อผู้ใช้" required>
                        </div>
                        <div class="form-group">
                            <label for="" class="">รหัสผ่าน</label>
                            <input class="form-control" type="password" name="password" id="password" placeholder="รหัสผ่าน" required>
                        </div>
                        <div class="form-group">
                            <label for="" class="">ยืนยันรหัสผ่าน</label>
                            <input class="form-control" type="password" name="confirmpassword" id="confirmpassword" placeholder="ยืนยันรหัสผ่าน">
                        </div>
                        <div class="form-group">
                            <label for="" class="">ชื่อ</label>
                            <input class="form-control" type="text" name="firstname" id="firstname" placeholder="ชื่อ" required>
                        </div>
                        <div class="form-group">
                            <label for="" class="">นามสกุล</label>
                            <input class="form-control" type="text" name="lastname" id="lastname" placeholder="นามสกุล" required>
                        </div>
                        <div class="form-group">
                            <label for="" class="">อีเมล</label>
                            <input class="form-control" type="email" name="email" id="email" placeholder="someone@example.com" required>
                        </div>
                        <div class="form-group">
                            <label for="" class="">สถานะ</label><br/>
                                    <input type="radio" name="permission" id="permission" value="user" checked> ผู้ใช้
                                    <input type="radio" name="permission" id="permission" value="admin"> ผู้ดูแลระบบ
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
                    <button type="submit" class="btn btn-primary">เพิ่มสมาชิก</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- ModalUpdateUser-->
<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel2">แก้ไขข้อมูลสมาชิก</h5>

            </div>
            <form action=<?= Router::getSourcePath()."index.php?controller=Member&action=update" ?> method="post">
                <div class="modal-body">
                    <div class="form-group">


                            <div class="form-group">
                                <label for="" class="">ชื่อผู้ใช้</label>
                                <input class="form-control" type="text" name="username2" id="username2" readonly >
                            </div>
                            <div class="form-group">
                                <label for="" class="">ชื่อ</label>
                                <input class="form-control" type="text" name="name2" id="name2">
                            </div>
                            <div class="form-group">
                                <label for="" class="">นามสกุล</label>
                                <input class="form-control" type="text" name="surname2" id="surname2">
                            </div>
                            <div class="form-group">
                                <label for="" class="">อีเมล</label>
                                <input class="form-control" type="email" name="email2" id="email2">
                            </div>
                            <div class="form-group">
                                <label for="" class="">สถานะ</label><br/>
                                <input type="radio" name="permission" id="permission1" value="user"> ผู้ใช้
                                <input type="radio" name="permission" id="permission2" value="admin"> ผู้ดูแลระบบ
                            </div>

                        <input class="form-control" type="hidden" name="pass2" id="pass2">
                        <input class="form-control" type="hidden" name="check" id="check">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
                    <input hidden name="updateID" id='updateID' ><button type="submit" class="btn btn-primary">แก้ไข</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ModalConfirmDelete-->
<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body edit-content" id="edit-content">
                ....
            </div>
            <div class="modal-footer">
                <?php
                echo "<form  method=\"post\" >
                    <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
                    <input hidden name=\"memID\" id='memID' > <button type=\"submit\"  class=\"btn btn-primary ConfirmDelete\" >Delete</button> 
                   </form>";
                ?>
            </div>
        </div>
    </div>
</div>

<!-- ModalProfile -->
<div class="modal fade" id="myProfile" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fas fa-user-circle fa-lg"></i> โปรไฟล์</h4>
            </div>
            <div class="modal-body">
                <form id="profile" action=<?= Router::getSourcePath()."index.php?controller=Member&action=updateprofile"?> method="post">
                    <div class="form-group">
                        <label for="name">ชื่อ</label> <input class="form-control" id="name3" name="name3" type="text" value="<?=$admin->getName() ?>">
                    </div>
                    <div class="form-group">
                        <label for="name">นามสกุล</label> <input class="form-control" id="surname3" name="surname3" type="text" value="<?=$admin->getSurname() ?>">
                    </div>
                    <div class="form-group">
                        <label for="name">email</label> <input class="form-control" id="email3" name="email3" type="text" value="<?=$admin->getEmail() ?>">
                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
                        <button type="submit"  class="btn btn-primary" >แก้ไข</button>
                        <input hidden type="text" name="updateprofileID" id="updateprofileID" value="<?=$id?>" >
                        <input hidden type="text" name="user3" id="user3" value="<?=$user?>" >
                        <input hidden type="text" name="password3" id="password3" value="<?=$pass?>" >
                        <input hidden  type="text" name="permission3" id="permission3" value="<?=$admin->getPermission() ?>" >
                        <input class="form-control" type="hidden" name="check3" id="check3" value="<?=$admin->getEmail() ?>">

                    </div>
                </form>
            </div>

        </div>

    </div>
</div>

<script>
    $('#regis').on('submit',function (e) {
        e.preventDefault();
        var username = document.getElementById("username");
        var password = document.getElementById("password");
        var  firstname = document.getElementById("firstname");
        var  lastname =document.getElementById("lastname");
        var  email =  document.getElementById("email");
        var permission = document.getElementById("permission");
        $.ajax({
            url: "<?= Router::getSourcePath() ?>"+"index.php?controller=Member&action=regis"  ,
            method : "POST",
            data:{username : username.value ,
                password:password.value,
                firstname:firstname.value,
                lastname:lastname.value,
                email:email.value,
                confirmpassword : confirmpassword.value,
                permission : permission.value
            },
            success:function (data) {

                if (data == "donntuseemail") {
                    $("#email").val("");
                    email.focus();
                    Swal.fire({
                        type: 'warning',
                        title: 'E-MAIL ซ้ำ',
                        confirmButtonText: 'ตกลง'
                    });


                }
                else if (data == "checkpassword") {
                    $("#password").val("");
                    $("#confirmpassword").val("");
                    password.focus();
                    Swal.fire({
                        type: 'warning',
                        title: 'ตรวจสอบรหัสผ่านให้ถูกต้อง',
                        confirmButtonText: 'ตกลง'
                    });


                }
                else if (data == "dontuseusername") {

                    $("#username").val("");
                    username.focus();
                    Swal.fire({
                        type: 'warning',
                        title: 'ชื่อผู้ใช้ซ้ำ',
                        confirmButtonText: 'ตกลง'
                    });
                }
                else {
                    Swal.fire({
                        type: 'success',
                        title: 'เพิ่มผู้ใช้สำเร็จ',
                        showConfirmButton: false


                    });
                    $('#regis').hide();

                    setTimeout(function () {
                        location.reload();
                    }, 1500);
                }
            }
        });


    });

    $('.delete1').click(function (){
        var id = $(this).attr('data-id');
        var get = $(this).attr('data-name2')+" "+$(this).attr('data-surname2');
        $("#memID").val(id);
        document.getElementById("edit-content").innerHTML = get ;
        // $("#exampleModal3").modal('show');

    });

    $('#exampleModal3').on('submit',function (e){
        e.preventDefault();
        var memID=document.getElementById("memID");

        $.ajax({
            url: "<?= Router::getSourcePath() ?>"+"index.php?controller=Member&action=delete"  ,
            method : "POST",
            data:{memID : memID.value

            },
            success:function (data) {

                if (data == "0") {
                    $('#exampleModal3').hide();
                    Swal.fire({
                        type: 'warning',
                        title: 'ลบไม่ได้',
                        text: 'เนื่องจากมีการเชื่อมโยงกับข้อมูลอื่น!',
                        showConfirmButton: false


                    });


                    setTimeout(function () {
                        location.reload();
                    }, 2500);

                }
                else { $('#exampleModal3').hide();
                    Swal.fire({
                        type: 'success',
                        title: 'ลบผู้ใช้สำเร็จ',
                        showConfirmButton: false


                    });


                    setTimeout(function () {
                        location.reload();
                    }, 1500);
                }
            }
        });
    });

    $('.edit_spec2').click(function (){
        // var update = $(this);
        // user = e.relatedTarget.;
        // update.find('#userName2').val(user);

        // ดึงค่า
        var userName = $(this).attr('data-userName');
        var name = $(this).attr('data-name');
        var surname = $(this).attr('data-surname');
        var email = $(this).attr('data-email');
        var permission = $(this).attr('data-per');
        var updateID = $(this).attr('data-userID');
        var pass = $(this).attr('data-pass');
        // เซทค่า
        //document.getElementById("").innerHTML = ;
        $("#username2").val(userName);
        $("#name2").val(name);
        $("#surname2").val(surname);
        $("#email2").val(email);
        $("#updateID").val(updateID);
        $("#pass2").val(pass);
        $("#check").val(email);
        if(permission=="user")
            radiobtn = document.getElementById("permission1");
        else radiobtn = document.getElementById("permission2");
        radiobtn.checked = true;

        // $("#exampleModal2").modal('show');
    });



    $('#exampleModal2').on('submit',function (e){
        e.preventDefault();
        var updateID=document.getElementById("updateID");
        var name2=document.getElementById("name2");
        var surname2=document.getElementById("surname2");
        var email2=document.getElementById("email2");
        var username2=document.getElementById("username2");
        var pass2=document.getElementById("pass2");
        var check=document.getElementById("check");


        $.ajax({
            url: "<?= Router::getSourcePath() ?>"+"index.php?controller=Member&action=update"  ,
            method : "POST",
            data:{updateID : updateID.value,
                name2 : name2.value,
                surname2 : surname2.value,
                email2 : email2.value,
                username2 : username2.value,
                permission : $('input[name="permission"]:checked','#exampleModal2').val(),
                pass2 : pass2.value,
                check : check.value

            },
            success:function (data) {
                if (data == "donntuseemail") {

                    email2.focus();
                    Swal.fire({
                        type: 'warning',
                        title: 'E-MAIL ซ้ำ',
                        confirmButtonText: 'ตกลง'
                    });


                }

                else {
                    $('#exampleModal2').hide();
                    Swal.fire({
                        type: 'success',
                        title: 'อัพเดทผู้ใช้สำเร็จ',
                        showConfirmButton: false


                    });


                    setTimeout(function () {
                        location.reload();
                    }, 1500);
                }

            }
        });

    });

    $('#profile').on('submit',function (e){
        e.preventDefault();
        var updateprofileID=document.getElementById("updateprofileID");
        var name3=document.getElementById("name3");
        var surname3=document.getElementById("surname3");
        var email3=document.getElementById("email3");
        var user3=document.getElementById("user3");
        var password3=document.getElementById("password3");
        var permission3 = document.getElementById("permission3");
        var check3=document.getElementById("check3");

        $.ajax({
            url: "<?= Router::getSourcePath() ?>"+"index.php?controller=Member&action=updateprofile"  ,
            method : "POST",
            data:{updateprofileID : updateprofileID.value,
                name3 : name3.value,
                surname3 : surname3.value,
                email3 : email3.value,
                user3 : user3.value,
                permission3 : permission3.value,
                password3 : password3.value,
                check3:check3.value

            },
            success:function (data) {


                if (data == "donntuseemail") {
                    
                    email3.focus();
                    Swal.fire({
                        type: 'warning',
                        title: 'E-MAIL ซ้ำ',
                        confirmButtonText: 'ตกลง'
                    });


                }

                else {
                    $('#myProfile').hide();
                    Swal.fire({
                        type: 'success',
                        title: 'อัพเดทผู้ใช้สำเร็จ',
                        showConfirmButton: false


                    });


                    setTimeout(function () {
                        location.reload();
                    }, 1500);
                }
            }


        });

    });


    $('#memberTable').DataTable({
        "order": [],
        "columnDefs": [{
            "targets": 'no-sort',
            "orderable": false
        }],
        "oLanguage": {
            "sEmptyTable": "ไม่มีข้อมูลในตาราง",
            "sInfo": "แสดง _START_ ถึง _END_ จาก _TOTAL_ แถว",
            "sInfoEmpty": "แสดง 0 ถึง 0 จาก 0 แถว",
            "sInfoFiltered": "(กรองข้อมูล _MAX_ ทุกแถว)",
            "sInfoPostFix": "",
            "sInfoThousands": ",",
            "sLengthMenu": "แสดง _MENU_ แถว",
            "sLoadingRecords": "กำลังโหลดข้อมูล...",
            "sProcessing": "กำลังดำเนินการ...",
            "sSearch": "ค้นหา: ",
            "sZeroRecords": "ไม่พบข้อมูล",
            "oPaginate": {
                "sFirst": "หน้าแรก",
                "sPrevious": "ก่อนหน้า",
                "sNext": "ถัดไป",
                "sLast": "หน้าสุดท้าย"
            },
            "oAria": {
                "sSortAscending": ": เปิดใช้งานการเรียงข้อมูลจากน้อยไปมาก",
                "sSortDescending": ": เปิดใช้งานการเรียงข้อมูลจากมากไปน้อย"
            }
        }
    });

</script>
</body>
</html>
