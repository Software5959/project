<?php
$s = $_GET['s'];
$uid = $_GET['uid'];
if($s==1){
    $status = 1;
    $isAdmin = 0;
}elseif($s==2){
    $status = 2;
    $isAdmin = 1;
}else{
    $status = 3;
    $isAdmin = 0;
}
require('connect.php');
$con->query("UPDATE `user` SET `status` = '$status', `isAdmin` = '$isAdmin' WHERE `user`.`uid` = '$uid'");
$con->query("UPDATE `user` SET `status` = '$status' WHERE `user`.`uid` = '$uid'");
header("Location: login.php?error=ต้องเข้าระบบใหม่?");


?>