<!-- Topbar Navbar -->
<!DOCTYPE html>
<?php
?>
<ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">KU
            <span href="#" class="badge badge-primary ml-1">COMPUTER ENGINEER</span>


        </a>
    </li>

</ul>
<ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">

</ul>
<ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul>
<ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">

        </a>
    </li>
</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul>
</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
    <li class="nav-item">
        <a href="#" class="nav-link">


        </a>
    </li>

</ul>
<ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">

</ul><ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">


</ul>
<ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">

</ul>
<ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">

</ul>

<ul class="navbar-nav ml-auto">
    <!-- Nav Item - User Information -->

    <li class="nav-item">
        <font size="3">
           <?php
           if (($_SESSION["ldap_idcode"] =='U1234'))
           {echo $_SESSION["ldap_idcode"];
               echo "<li class=class=\"navbar-nav ml-auto\" ></li>";
               echo "<ul class=class=\"navbar-nav ml-auto\" > </ul>";
               

           }
           else { echo $_SESSION["ldap_idcode"];}


           ?><br>
        </font>
    </li>
        <img class="img-xs rounded-circle" src="images/faces/face1.jpg" alt="Profile image">
    <li class="nav-item">
    </li>
    <a style="background-color: #9e9e9e" class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
      LOGOUT
    </a>

</ul>
</nav>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">หากต้องการออกจากระบบกรุณายืนยัน</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">ยกเลิก</button>
                <a class="btn btn-primary" href="<?= Router::getSourcePath() . "index.php?controller=Index&action=index" ?>" >ยืนยัน</a>
            </div>
        </div>
    </div>
</div>
