<div style="background: black; width:100%; color: #ff6471; text-align:center; font-size: small;padding:3px;">
    <div>&copy;2018 My Cashier 02204445 - N.S.</div>
    <div>ภาควิชาวิศวกรรมคอมพิวเตอร์ คณะวิศวกรรมศาสตร์ กำแพงแสน มหาวิทยาลัยเกษตรศาสตร์</div>
    <div>1 ถ.มาลัยแมน ต.กำแพงแสน อ.กำแพงแสน จ.นครปฐม 73140</div>
</div>
<?php
/*echo "<hr/>";
echo "<pre><code>";
show_source(__FILE__);
echo "</code></pre>";*/