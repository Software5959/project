<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <span class="navbar-brand mb-0 h1"><img src="./img/logo.png" alt="" width="150" height="60"></span>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="nav nav-pills mr-auto">
            <li class="nav-item">
                <a class="nav-link text-white" id="pillsWorker"  href=<?=Router::getSourcePath()."index.php?controller=Team&action=showTeamWorker"?> role="tab" aria-controls="pills-home" aria-selected="true"><i class="fas fa-sitemap"></i> ทีมรับงาน <i id="NotifyWorkerPoint1" hidden class="fas fa-circle fa-xs" style="color: #ff6b6b;"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" id="pillsManager"   href=<?=Router::getSourcePath()."index.php?controller=Team&action=showTeamManager"?> role="tab" aria-controls="pills-profile" aria-selected="false"><i class="fas fa-user-tie"></i> ทีมสั่งงาน</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-white" id="pillsMyWork"   href=<?=Router::getSourcePath()."index.php?controller=Work&action=showMyWork"?> role="tab" aria-controls="pills-profile" aria-selected="false"><i class="far fa-envelope"></i> จัดการงานที่ได้รับ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" id="pills-contact-tab"  href=<?=Router::getSourcePath()."index.php?controller=Team&action=showCreateTeam"?> role="tab" aria-controls="pills-contact" aria-selected="false"><i class="fas fa-users"></i> สร้างทีม</a>
            </li>
            <script>
                    var GET = "<?= $_GET['action'] ?>";
                    if(GET=="login") {
                        $("#pillsWorker").attr("aria-selected", "true");
                        $("#pillsWorker").attr("class", "nav-link active text-white");
                    }else if(GET=="showTeamWorker"){
                        $("#pillsWorker").attr("aria-selected","true");
                        $("#pillsWorker").attr("class","nav-link active text-white");
                    }else if(GET=="showTeamManager") {
                        $("#pillsManager").attr("aria-selected", "true");
                        $("#pillsManager").attr("class", "nav-link active text-white");
                    }else if(GET=="showMyWork") {
                        $("#pillsMyWork").attr("aria-selected","true");
                        $("#pillsMyWork").attr("class","nav-link active text-white");
                    }else if(GET=="showCreateTeam") {
                        $("#pills-contact-tab").attr("aria-selected","true");
                        $("#pills-contact-tab").attr("class","nav-link active text-white");
                    }
                    </script>
        </ul>

        <form class="form-inline">
            <?php
            $statusHistoryList = $statusHistoryList??null;
            $teamOfStatusHistoryList = $teamOfStatusHistoryList??null;
            $memberOfStatusHistoryList = $memberOfStatusHistoryList??null;
            ?>
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link  text-white" href="#" id="navbarDropdownStatusHistory" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="far fa-bell fa-lg"></i><span id="numNotifyStatusHistory" class="badge badge-pill badge-danger "></span></a>
                    <div id="setupStatusHistory">
                        
                    </div>
                </li>
            </ul>
            <input id="numNotifyStatus" hidden value="">
            <div class="input-group mb-0 ">
                <div class="input-group-prepend ">
                    <a class = "nav-link text-white" href="#myProfile" data-toggle="modal"><i class="far fa-user fa-lg mr-2" style="color:#ffffff;"></i>
                        <?php
                        $mem = $_SESSION['member'];
                        echo"<h8>".$mem->getName()." ".$mem->getSurname()."</h8>";
                        ?>
                    </a>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mb-0"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</button>
        </form>
    </div>
</nav>
<script>
    $.ajax({
        url:"<?= Router::getSourcePath()?>" + "index.php?controller=Team&action=getNotifyWorker",
        success:function (data) {
            if(data!=0){
                $('#NotifyWorkerPoint').attr('hidden',null);
            }
        }
    });
    $.ajax({
        url:"<?= Router::getSourcePath()?>" + "index.php?controller=Team&action=getStatusHistory",
        success:function (data) {
            $('#setupStatusHistory').html(data);
        }
    });
    $.ajax({
        url:"<?= Router::getSourcePath()?>" + "index.php?controller=Team&action=getNumStatusHistory",
        success:function (data) {
            if(data!=0){
                $('#numNotifyStatusHistory').html(data);
            }
        }
    });
    var checkClick = false;
    var toggle = false;
    $('#navbarDropdownStatusHistory').click(function () {
        if(checkClick===false){
            $.ajax({
                url:"<?= Router::getSourcePath()?>" + "index.php?controller=Team&action=offNotifyStatusHistory",
                success:function (data) {
                    if(data==1){
                        $('#numNotifyStatusHistory').remove();
                    }
                }
            });
            checkClick= true;
        }
        if(toggle){
           $('.dropdown-menu').hide();
            toggle = !toggle;
        }else{
            $('.dropdown-menu').show();
            toggle = !toggle;
        }
    })
</script>


