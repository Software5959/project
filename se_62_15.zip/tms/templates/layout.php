<!DOCTYPE html>
<html lang="th">
<head>

    <meta charset="UTF-8">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <!--style-->
    <link rel="stylesheet" href="./css/dropdown.css">
    <link rel="stylesheet" href="./css/nontification.css">
    <link rel="stylesheet" href="./css/loading.css">

    <!--New DataTable-->
    <!--
    <link rel="stylesheet" type="text/css" href="./css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="./css/dataTables.bootstrap4.min.css">
    <script type="text/javascript" src="./js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript" language="JavaScript" src="./js/jquery-3.3.1.js"></script>
    <script type="text/javascript" language="JavaScript" scr="./js/jquery.dataTables.min.js"></script>-->

    <!-- DataTables-->
    <link rel="stylesheet" type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">

    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"
            async=""></script>
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" language="javascript"
            src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <style>
        body {
            background-image: url("img/background.jpg");
            background-size: 100%;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
    </style>

</head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<body>

<div id="container" >
    <div id="header">
        <?php include("header.inc.php");

        $mem=$_SESSION["member"];
        $id=$mem->getMemId();
        $user=$mem->getUsername();
        $pass = $mem->getPassword();
        $permis = $mem->getPermission();

        //หาไม่เจอ จะหาที่โฟลเดอร์เดียวกัน ?>
    </div>
    <div id="content" style="text-align: center">
        <?= $content ?>
    </div>

    <!-- ModalProfile -->
    <div class="modal fade" id="myProfile" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><i class="fas fa-user-circle fa-lg"></i> โปรไฟล์</h4>
                </div>
                <div class="modal-body">
                    <form id="profile" action=<?= Router::getSourcePath()."index.php?controller=Member&action=updateprofile"?> method="post">
                        <div class="form-group">
                            <label for="name">ชื่อ</label> <input class="form-control" id="name3" name="name3" type="text" value="<?=$mem->getName() ?>">
                        </div>
                        <div class="form-group">
                            <label for="name">นามสกุล</label> <input class="form-control" id="surname3" name="surname3" type="text" value="<?=$mem->getSurname() ?>">
                        </div>
                        <div class="form-group">
                            <label for="name">email</label> <input class="form-control" id="email3" name="email3" type="text" value="<?=$mem->getEmail() ?>">
                        </div>
                        <div class="modal-footer">

                            <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
                            <button type="submit"  class="btn btn-primary" >แก้ไข</button>
                            <input hidden type="text" name="updateprofileID" id="updateprofileID" value="<?=$id?>" >
                            <input hidden type="text" name="user3" id="user3" value="<?=$user?>" >
                            <input hidden type="text" name="password3" id="password3" value="<?=$pass?>" >
                            <input hidden  type="text" name="permission3" id="permission3" value="<?=$permis ?>" >
                            <input class="form-control" type="hidden" name="check3" id="check3" value="<?=$mem->getEmail() ?>">

                        </div>
                    </form>
                </div>

            </div>

        </div>
    </div>
    
</div>
<script>

    $('#profile').on('submit',function (e){
        e.preventDefault();
        var updateprofileID=document.getElementById("updateprofileID");
        var name3=document.getElementById("name3");
        var surname3=document.getElementById("surname3");
        var email3=document.getElementById("email3");
        var user3=document.getElementById("user3");
        var password3=document.getElementById("password3");
        var permission3 = document.getElementById("permission3");
        var check3=document.getElementById("check3");

        $.ajax({
            url: "<?= Router::getSourcePath() ?>"+"index.php?controller=Member&action=updateprofile"  ,
            method : "POST",
            data:{updateprofileID : updateprofileID.value,
                name3 : name3.value,
                surname3 : surname3.value,
                email3 : email3.value,
                user3 : user3.value,
                permission3 : permission3.value,
                password3 : password3.value,
                check3:check3.value

            },
            success:function (data) {


                if (data == "donntuseemail") {

                    email3.focus();
                    Swal.fire({
                        type: 'warning',
                        title: 'E-MAIL ซ้ำ',
                        confirmButtonText: 'ตกลง'
                    });


                }

                else {
                    $('#myProfile').hide();
                    Swal.fire({
                        type: 'success',
                        title: 'อัพเดทผู้ใช้สำเร็จ',
                        showConfirmButton: false


                    });


                    setTimeout(function () {
                        location.reload();
                    }, 1500);
                }
            }


        });

    });
</script>
</body>
</html>
