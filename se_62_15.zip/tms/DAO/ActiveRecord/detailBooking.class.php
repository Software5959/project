<?php
class detailBooking
{
    private $detailBookingId;
    private $bookingID;
    private $deviceId;
    private $amount;
    private $receptionDate;
    private $revertingDate;


    private const TABLE = "detailBooking";
    public function __construct(){}

    public static function  getDetailBookingByBooking(int $mem_id):?array
    {
        $con = Db::getInstance();
        $query = "SELECT " . self::TABLE . ".* FROM " . self::TABLE . " INNER JOIN booking ON " . self::TABLE . ".bookingID = booking.bookingId WHERE booking.bookingId = '$mem_id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "detailBooking");
        $stmt->execute();
        $workList = array();
        while ($work = $stmt->fetch())
        {
            $workList[$work->getDetailBookingId()] = $work;
        }
        return $workList;
    }
    public  static function findAll():array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE;
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "detailBooking");
        $stmt->execute();
        $teamList = array();
        while ($team = $stmt->fetch())
        {
            $teamList[$team->getDetailBookingId()] = $team;
        }
        return $teamList;
    }
    public static  function findById(int $id): ?detailBooking
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE detailBookingId ='$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "detailBooking");
        $stmt->execute();
        if ($team = $stmt->fetch())
        {
            return $team;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $team => $val) {
            if($val==null)
            {
                $values .= "NULL,";
            }else {
                $values .= "'$val',";
            }
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        $res = $con->exec($query);
        echo $query;
        $this->bookingId = $con->lastInsertId();
        return $res;
    }
    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $team => $val) {
            $query .= " $team='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE team_id = " . $this->getDetailBookingId();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE detailBookingId ='{$this->getDetailBookingId()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    /**
     * @return mixed
     */
    public function getDetailBookingId()
    {
        return $this->detailBookingId;
    }

    /**
     * @param mixed $detailBookingId
     */
    public function setDetailBookingId($detailBookingId): void
    {
        $this->detailBookingId = $detailBookingId;
    }

    /**
     * @return mixed
     */
    public function getBookingID()
    {
        return $this->bookingID;
    }

    /**
     * @param mixed $bookingID
     */
    public function setBookingID($bookingID): void
    {
        $this->bookingID = $bookingID;
    }

    /**
     * @return mixed
     */
    public function getDeviceId()
    {
        return $this->deviceId;
    }

    /**
     * @param mixed $deviceId
     */
    public function setDeviceId($deviceId): void
    {
        $this->deviceId = $deviceId;
    }


    /**
     * @return mixed
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * @param mixed $amount
     */
    public function setAmount($amount): void
    {
        $this->amount = $amount;
    }

    /**
     * @return mixed
     */
    public function getReceptionDate()
    {
        return $this->receptionDate;
    }

    /**
     * @param mixed $receptionDate
     */
    public function setReceptionDate($receptionDate): void
    {
        $this->receptionDate = $receptionDate;
    }

    /**
     * @return mixed
     */
    public function getRevertingDate()
    {
        return $this->revertingDate;
    }

    /**
     * @param mixed $revertingDate
     */
    public function setRevertingDate($revertingDate): void
    {
        $this->revertingDate = $revertingDate;
    }

}
