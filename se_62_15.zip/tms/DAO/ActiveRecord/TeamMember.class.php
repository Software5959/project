<?php
class TeamMember
{
    private $teamwork_id;
    private $team_id;
    private $mem_id;
    private $status;
    private $statusDisplay;
    private $statusTeamWork;

    private const TABLE = "team_member";
    public function __construct(){}
    public static function getTeamMemberByMember(int $mem_id,string $statusTeamMember='OPEN'):array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." INNER JOIN member ON member.mem_id=".self::TABLE.".mem_id WHERE member.mem_id='$mem_id' AND team_member.statusTeamWork='$statusTeamMember'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "TeamMember");
        $stmt->execute();
        $teamList = array();
        while ($team = $stmt->fetch())
        {
            $teamList[$team->getTeamworkId()] = $team;
        }
        return $teamList;
    }
    public static function getTeamMemberByTeam(int $team_id,string $statusTeamMember='OPEN',string $statusTeam='OPEN'):array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." INNER JOIN team ON ".self::TABLE.".team_id = team.team_id WHERE team.team_id = '$team_id' AND ".self::TABLE.".statusTeamWork='$statusTeamMember' AND team.statusTeam='$statusTeam'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "TeamMember");
        $stmt->execute();
        $teamList = array();
        while ($team = $stmt->fetch())
        {
            $teamList[$team->getTeamworkId()] = $team;
        }
        return $teamList;
    }
    public static function findAll(string $statusTeamMember='OPEN'):array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE ".self::TABLE.".statusTeamWork='$statusTeamMember' ORDER BY statusDisplay";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "TeamMember");
        $stmt->execute();
        $teamList = array();
        while ($team = $stmt->fetch())
        {
            $teamList[$team->getTeamworkId()] = $team;
        }
        return $teamList;
    }
    public static  function findById(int $id,string $statusTeamMember='OPEN'): ?TeamMember
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE teamwork_id ='$id' AND ".self::TABLE.".statusTeamWork='$statusTeamMember'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "TeamMember");
        $stmt->execute();
        if ($team = $stmt->fetch())
        {
            return $team;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $team => $val) {
            if($val==null)
            {
                $values .= "NULL,";
            }else {
                $values .= "'$val',";
            }
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        $res = $con->exec($query);
        $this->teamwork_id = $con->lastInsertId();
        return $res;
    }

    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $team => $val) {
            $query .= " $team='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE teamwork_id = " . $this->getTeamworkId();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE teamwork_id ='{$this->getTeamworkId()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    /**
     * @return mixed
     */
    public function getTeamworkId()
    {
        return $this->teamwork_id;
    }

    /**
     * @param mixed $teamwork_id
     */
    public function setTeamworkId($teamwork_id): void
    {
        $this->teamwork_id = $teamwork_id;
    }

    /**
     * @return mixed
     */
    public function getTeamId()
    {
        return $this->team_id;
    }

    /**
     * @param mixed $team_id
     */
    public function setTeamId($team_id): void
    {
        $this->team_id = $team_id;
    }

    /**
     * @return mixed
     */
    public function getMemId()
    {
        return $this->mem_id;
    }

    /**
     * @param mixed $mem_id
     */
    public function setMemId($mem_id): void
    {
        $this->mem_id = $mem_id;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status): void
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getStatusDisplay()
    {
        return $this->statusDisplay;
    }

    /**
     * @param mixed $statusDisplay
     */
    public function setStatusDisplay($statusDisplay): void
    {
        $this->statusDisplay = $statusDisplay;
    }

    /**
     * @return mixed
     */
    public function getStatusTeamWork()
    {
        return $this->statusTeamWork;
    }

    /**
     * @param mixed $statusTeamWork
     */
    public function setStatusTeamWork($statusTeamWork): void
    {
        $this->statusTeamWork = $statusTeamWork;
    }


}
