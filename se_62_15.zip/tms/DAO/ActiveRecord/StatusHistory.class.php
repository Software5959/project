<?php
class StatusHistory
{
    private $status_history_id;
    private $begin_date;
    private $begin_time;
    private $teamwork_id;
    private $status_id;
    private $team_id;
    private $mem_id;
    private $notify;

    private const TABLE = "status_history";
    public function __construct(){}
    public static function getStatusHistoryByTeamMember(int $teamMember_id,string $statusTeamWork='OPEN'){
        $con = Db::getInstance();
        $query = "SELECT ".self::TABLE.".* FROM ".self::TABLE." INNER JOIN team_member ON ".self::TABLE.".teamwork_id = team_member.teamwork_id WHERE team_member.teamwork_id='$teamMember_id' AND team_member.statusTeamWork='$statusTeamWork' ORDER BY ".self::TABLE.".begin_date DESC,".self::TABLE.".begin_time DESC";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "StatusHistory");
        $stmt->execute();
        $historyList = array();
        while ($his = $stmt->fetch())
        {
            $historyList[$his->getStatusHistoryId()] = $his;
        }
        return $historyList;
    }
    public static function getStatusHistoryByMember(int $mem_id,string $statusTeamMember='OPEN'):array
    {
        $con = Db::getInstance();
        $query = "SELECT ".self::TABLE.".* FROM ".self::TABLE." INNER JOIN team_member ON ".self::TABLE.".teamwork_id=team_member.teamwork_id INNER JOIN status ON ".self::TABLE.".status_id=status.status_id WHERE team_member.mem_id = '$mem_id' AND team_member.statusTeamWork='$statusTeamMember' ORDER BY status_history.begin_date DESC,status_history.begin_time DESC";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "StatusHistory");
        $stmt->execute();
        $historyList = array();
        while ($his = $stmt->fetch())
        {
            $historyList[$his->getStatusHistoryId()] = $his;
        }
        return $historyList;
    }
    public  static function findAll():array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." ORDER BY begin_date DESC,begin_time DESC";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "StatusHistory");
        $stmt->execute();
        $historyList = array();
        while ($his = $stmt->fetch())
        {
            $historyList[$his->getStatusHistoryId()] = $his;
        }
        return $historyList;
    }
    public static  function findById(int $id): ?StatusHistory
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE status_history_id ='$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "StatusHistory");
        $stmt->execute();
        if ($his = $stmt->fetch())
        {
            return $his;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $his => $val) {
            if($val==null){
                $values .= "NULL,";
            }else {
                $values .= "'$val',";
            }
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        $res = $con->exec($query);
        $this->status_history_id = $con->lastInsertId();
        return $res;
    }
    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $his => $val) {
            $query .= " $his='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE status_history_id = " . $this->getStatusHistoryId();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE status_history_id ='{$this->getStatusHistoryId()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    /**
     * @return mixed
     */
    public function getStatusHistoryId()
    {
        return $this->status_history_id;
    }

    /**
     * @param mixed $status_history_id
     */
    public function setStatusHistoryId($status_history_id): void
    {
        $this->status_history_id = $status_history_id;
    }

    /**
     * @return mixed
     */
    public function getBeginDate()
    {
        return $this->begin_date;
    }

    /**
     * @param mixed $begin_date
     */
    public function setBeginDate($begin_date): void
    {
        $this->begin_date = $begin_date;
    }

    /**
     * @return mixed
     */
    public function getBeginTime()
    {
        return $this->begin_time;
    }

    /**
     * @param mixed $begin_time
     */
    public function setBeginTime($begin_time): void
    {
        $this->begin_time = $begin_time;
    }

    /**
     * @return mixed
     */
    public function getTeamworkId()
    {
        return $this->teamwork_id;
    }

    /**
     * @param mixed $teamwork_id
     */
    public function setTeamworkId($teamwork_id): void
    {
        $this->teamwork_id = $teamwork_id;
    }

    /**
     * @return mixed
     */
    public function getStatusId()
    {
        return $this->status_id;
    }

    /**
     * @param mixed $status_id
     */
    public function setStatusId($status_id): void
    {
        $this->status_id = $status_id;
    }

    /**
     * @return mixed
     */
    public function getTeamId()
    {
        return $this->team_id;
    }

    /**
     * @param mixed $team_id
     */
    public function setTeamId($team_id): void
    {
        $this->team_id = $team_id;
    }

    /**
     * @return mixed
     */
    public function getMemId()
    {
        return $this->mem_id;
    }

    /**
     * @param mixed $mem_id
     */
    public function setMemId($mem_id): void
    {
        $this->mem_id = $mem_id;
    }

    /**
     * @return mixed
     */
    public function getNotify()
    {
        return $this->notify;
    }

    /**
     * @param mixed $notify
     */
    public function setNotify($notify): void
    {
        $this->notify = $notify;
    }
    
}
