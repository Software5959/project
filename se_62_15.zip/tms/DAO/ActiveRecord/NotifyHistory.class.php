<?php
class NotifyHistory
{
    private $notify_history_id;
    private $team_id;
    private $work_id;
    private $teamwork_id;
    private $notify_date;
    private $notify_time;
    private $notify;

    private const TABLE = "notify_history";
    public function __construct(){}
    public static function getNotifyHistoryByTeamOrWork(int $team_id=NULL,int $work_id=NULL){
        $con = Db::getInstance();
        if(isset($team_id) && isset($work_id)) {
            $query = "SELECT * FROM ".self::TABLE." WHERE notify_history.team_id='$team_id' AND notify_history.work_id='$work_id'";
        }else if(isset($team_id))
        {
            $query = "SELECT * FROM ".self::TABLE." WHERE notify_history.team_id='$team_id'";
        }else return NULL;
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "NotifyHistory");
        $stmt->execute();
        $historyList = array();
        while ($his = $stmt->fetch())
        {
            $historyList[$his->getNotifyHistoryId()] = $his;
        }
        return $historyList;
    }
    public static function getNotifyHistoryByMemberOrTeam(int $mem_id=NULL,int $team_id=NULL,string $statusTeamMember='OPEN'):?array
    {
        $con = Db::getInstance();
        if(isset($team_id) && isset($mem_id)) {
            $query = "SELECT *  FROM ".self::TABLE." JOIN team_member ON ".self::TABLE.".teamwork_id =  team_member.teamwork_id  WHERE team_member.mem_id = '$mem_id' AND ".self::TABLE.".team_id = '$team_id' AND ".self::TABLE.".notify = 'FALSE' AND team_member.statusTeamWork='$statusTeamMember' ORDER BY ".self::TABLE.".notify_date DESC,".self::TABLE.".notify_time DESC";
        }else if(isset($team_id))
        {
            $query = "SELECT *  FROM ".self::TABLE." JOIN team_member ON ".self::TABLE.".teamwork_id =  team_member.teamwork_id  WHERE ".self::TABLE.".team_id = '$team_id' AND ".self::TABLE.".notify = 'FALSE' AND team_member.statusTeamWork='$statusTeamMember' ORDER BY ".self::TABLE.".notify_date DESC,".self::TABLE.".notify_time DESC";
        }else if(isset($mem_id)){
            $query = "SELECT *  FROM ".self::TABLE." JOIN team_member ON ".self::TABLE.".teamwork_id =  team_member.teamwork_id  WHERE team_member.mem_id = '$mem_id' AND ".self::TABLE.".notify = 'FALSE' AND team_member.statusTeamWork='$statusTeamMember' ORDER BY ".self::TABLE.".notify_date DESC,".self::TABLE.".notify_time DESC";
        }else return NULL;
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "NotifyHistory");
        $stmt->execute();
        $historyList = array();
        while ($his = $stmt->fetch())
        {
            $historyList[$his->getNotifyHistoryId()] = $his;
        }
        return $historyList;
    }
    public static function getNotifyNumberByMember(int $mem_id,string $statusTeamMember='OPEN'):array
    {
        $con = Db::getInstance();
        $query = "SELECT ".self::TABLE.".team_id,COUNT(*) as number  FROM ".self::TABLE." JOIN team_member ON ".self::TABLE.".teamwork_id = team_member.teamwork_id WHERE team_member.mem_id = '$mem_id' AND ".self::TABLE.".notify = 0 AND team_member.statusTeamWork='$statusTeamMember' GROUP BY ".self::TABLE.".team_id";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $notifyNumberList = array();
        while ($notify = $stmt->fetch(PDO::FETCH_ASSOC))
        {
            $notifyNumberList[$notify['team_id']] = $notify['number'];
        }
        return $notifyNumberList;
    }
    public static function findAll():array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." ORDER BY notify_date DESC,notify_time DESC";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "NotifyHistory");
        $stmt->execute();
        $historyList = array();
        while ($his = $stmt->fetch())
        {
            $historyList[$his->getHistoryId()] = $his;
        }
        return $historyList;
    }
    public static  function findById(int $id): ?NotifyHistory
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE notify_history_id ='$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "NotifyHistory");
        $stmt->execute();
        if ($his = $stmt->fetch())
        {
            return $his;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $his => $val) {
            if($val==null){
                $values .= "NULL,";
            }else{
                $values .= "'$val',";
            }

        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        $res = $con->exec($query);
        $this->notify_history_id = $con->lastInsertId();
        return $res;
    }
    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $his => $val) {
            $query .= " $his='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE notify_history_id = " . $this->getNotifyHistoryId();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE notify_history_id ='{$this->getNotifyHistoryId()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    /**
     * @return mixed
     */
    public function getNotifyHistoryId()
    {
        return $this->notify_history_id;
    }

    /**
     * @param mixed $notify_history_id
     */
    public function setNotifyHistoryId($notify_history_id): void
    {
        $this->notify_history_id = $notify_history_id;
    }


    /**
     * @return mixed
     */
    public function getTeamId()
    {
        return $this->team_id;
    }

    /**
     * @param mixed $team_id
     */
    public function setTeamId($team_id): void
    {
        $this->team_id = $team_id;
    }

    /**
     * @return mixed
     */
    public function getWorkId()
    {
        return $this->work_id;
    }

    /**
     * @param mixed $work_id
     */
    public function setWorkId($work_id): void
    {
        $this->work_id = $work_id;
    }

    /**
     * @return mixed
     */
    public function getTeamworkId()
    {
        return $this->teamwork_id;
    }

    /**
     * @param mixed $teamwork_id
     */
    public function setTeamworkId($teamwork_id): void
    {
        $this->teamwork_id = $teamwork_id;
    }

    /**
     * @return mixed
     */
    public function getNotifyDate()
    {
        return $this->notify_date;
    }

    /**
     * @param mixed $notify_date
     */
    public function setNotifyDate($notify_date): void
    {
        $this->notify_date = $notify_date;
    }

    /**
     * @return mixed
     */
    public function getNotify()
    {
        return $this->notify;
    }

    /**
     * @param mixed $notify
     */
    public function setNotify($notify): void
    {
        $this->notify = $notify;
    }

    /**
     * @return mixed
     */
    public function getNotifyTime()
    {
        return $this->notify_time;
    }

    /**
     * @param mixed $notify_time
     */
    public function setNotifyTime($notify_time): void
    {
        $this->notify_time = $notify_time;
    }


}
