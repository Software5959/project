<?php
class booking
{
    private $bookingId;
    private $borrowerId;
    private $lenderId;
    private $status;
    private $dateStart;
    private $dateEnd;
    private $disapprovalReason;

    private const TABLE = "booking";
    public function __construct(){}

    public static function  getBookingByMember(int $mem_id):?array
    {
        $con = Db::getInstance();
        $query = "SELECT " . self::TABLE . ".* FROM " . self::TABLE . " INNER JOIN user ON " . self::TABLE . ".borrowerId = user.uid WHERE user.uid = '$mem_id' ORDER BY " . self::TABLE . ".dateStart DESC";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "booking");
        $stmt->execute();
        $workList = array();
        while ($work = $stmt->fetch())
        {
            $workList[$work->getBookingId()] = $work;
        }
        return $workList;
    }

    public  static function findAll():array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE;
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "booking");
        $stmt->execute();
        $teamList = array();
        while ($team = $stmt->fetch())
        {
            $teamList[$team->getBookingId()] = $team;
        }
        return $teamList;
    }
    public static  function findById(int $id): ?booking
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE bookingId ='$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "booking");
        $stmt->execute();
        if ($team = $stmt->fetch())
        {
            return $team;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $team => $val) {
            if($val==null)
            {
                $values .= "NULL,";
            }else {
                $values .= "'$val',";
            }
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        $res = $con->exec($query);
        $this->bookingId = $con->lastInsertId();
        return $res;
    }
    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $team => $val) {
            $query .= " $team='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE team_id = " . $this->getBookingId();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE bookingId ='{$this->getBookingId()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    /**
     * @return mixed
     */
    public function getBookingId()
    {
        return $this->bookingId;
    }

    /**
     * @param mixed $team_id
     */
    public function setBookingId($bookingId): void
    {
        $this->bookingId = $bookingId;
    }

    /**
     * @return mixed
     */
    public function getBorrowerId()
    {
        return $this->borrowerId;
    }

    /**
     * @param mixed $name
     */
    public function setBorrowerId($borrowerId): void
    {
        $this->borrowerId = $borrowerId;
    }

    /**
     * @return mixed
     */
    public function getLenderId()
    {
        return $this->lenderId;
    }

    /**
     * @param mixed $create_date
     */
    public function setLenderId($lenderId): void
    {
        $this->lenderId = $lenderId;
    }

    /**
     * @return mixed
     */
    public function getDateStart()
    {
        return $this->dateStart;
    }

    /**
     * @param mixed $head
     */
    public function setDateStart($dateStart): void
    {
        $this->dateStart = $dateStart;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $create_time
     */
    public function setStatus($status): void
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getDateEnd()
    {
        return $this->dateEnd;
    }

    /**
     * @param mixed $statusTeam
     */
    public function setDateEnd($dateEnd): void
    {
        $this->dateEnd = $dateEnd;
    }

    /**
     * @return mixed
     */
    public function getDisapprovalReason()
    {
        return $this->disapprovalReason;
    }

    /**
     * @param mixed $disapprovalReason
     */
    public function setDisapprovalReason($disapprovalReason): void
    {
        $this->disapprovalReason = $disapprovalReason;
    }


}
