<?php
class Member
{
    private $uid;
    private $username;
    private $name;
    private $surname;
    private $type;
    private $numberStudent;
    private $numberMajor;
    private $email;
    private $telnumber;
    private $address;
    private $pass;


    private const TABLE = "user";
    public function __construct(){}
    public static function getMemberByTeamMember(int $team_member,string $status=null,string $statusTeamMember='OPEN'):?Member
    {
        $con = Db::getInstance();
        if(isset($team_member)&&isset($status))
        {
            $query = "SELECT * FROM " . self::TABLE . " INNER JOIN team_member ON " . self::TABLE . ".mem_id = team_member.mem_id WHERE team_member.teamwork_id = '$team_member' AND team_member.status='$status' AND team_member.statusTeamWork='$statusTeamMember'";
        }else if(isset($team_member)) {
            $query = "SELECT * FROM " . self::TABLE . " INNER JOIN team_member ON " . self::TABLE . ".mem_id = team_member.mem_id WHERE team_member.teamwork_id = '$team_member' AND team_member.statusTeamWork='$statusTeamMember'";
        }else return NULL;
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }
    public static  function  getMemberByWork(int $work_id,string $status=null,string $statusTeamMember='OPEN'):?Member
    {
        $con = Db::getInstance();
        if($status == "manager"){
            $query = "SELECT " . self::TABLE . ".* FROM ((" . self::TABLE . " JOIN team_member ON " . self::TABLE . ".mem_id = team_member.mem_id) JOIN work ON work.manager_id = team_member.teamwork_id) WHERE work.manager_id = '$work_id' AND team_member.statusTeamWork='$statusTeamMember'";
        }else if($status == "worker"){
            $query = "SELECT " . self::TABLE . ".* FROM ((" . self::TABLE . " JOIN team_member ON " . self::TABLE . ".mem_id = team_member.mem_id) JOIN work ON work.worker_id = team_member.teamwork_id) WHERE work.manager_id = '$work_id' AND team_member.statusTeamWork='$statusTeamMember'";
        }else{
            return null;
        }
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }
    public static function  getMemberByTeam(int $team_id,string $status=null,string $statusTeamMember='OPEN',string $statusTeam='OPEN'):array
    {
        $con = Db::getInstance();
        if(!isset($status)){
            $query = "SELECT " . self::TABLE . ".* FROM ((" . self::TABLE . " JOIN team_member ON " . self::TABLE . ".mem_id = team_member.mem_id) JOIN team ON team.team_id = team_member.team_id) WHERE team.team_id = '$team_id' AND team_member.statusTeamWork='$statusTeamMember' AND team.statusTeam='$statusTeam'";
        }else
        {
            $query = "SELECT " . self::TABLE . ".* FROM ((" . self::TABLE . " JOIN team_member ON " . self::TABLE . ".mem_id = team_member.mem_id) JOIN team ON team.team_id = team_member.team_id) WHERE team.team_id = '$team_id' AND team_member.status = '$status' AND team_member.statusTeamWork='$statusTeamMember' AND team.statusTeam='$statusTeam'";
        }
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        $memList = array();
        while ($mem = $stmt->fetch())
        {
            $memList[$mem->getMemId()] = $mem;
        }
        return $memList;
    }
    public function findByUsername(string $username) : ?Member
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE username = '$username'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }
    public function findByEmail(string $email) : ?Member
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE email = '$email'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }
    public static function findByAccount(string $username,string $password) : ?Member
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE numberStudent = '$username' and pass = '$password'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }
    public  static function findAll():array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE;
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        $memberList = array();
        while ($mem = $stmt->fetch())
        {
            $memberList[$mem->getUid()] = $mem;
        }
        return $memberList;
    }
    public static  function findById(int $id): ?Member
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE uid ='$id' ";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        $stmt->execute();
        if ($mem = $stmt->fetch())
        {
            return $mem;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "NULL,";
        $i=1;
        foreach ($this as $mem => $val) {
            if($i==0)
                $values .= "'$val',";
            $i = 0;
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        echo $query;
        $res = $con->exec($query);
        $this->uid = $con->lastInsertId();
        return $res;
    }
    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $mem => $val) {
            $query .= " $mem='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE mem_id = " . $this->getUid();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE uid ='{$this->getUid()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    /**
     * @return mixed
     */
    public function getUid()
    {
        return $this->uid;
    }

    /**
     * @param mixed $uid
     */
    public function setUid($uid): void
    {
        $this->uid = $uid;
    }

    /**
     * @return mixed
     */
    public function getNumberStudent()
    {
        return $this->numberStudent;
    }

    /**
     * @param mixed $numberStudent
     */
    public function setNumberStudent($numberStudent): void
    {
        $this->numberStudent = $numberStudent;
    }

    /**
     * @return mixed
     */
    public function getPass()
    {
        return $this->pass;
    }

    /**
     * @param mixed $pass
     */
    public function setPass($pass): void
    {
        $this->pass = $pass;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name): void
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param mixed $type
     */
    public function setType($type): void
    {
        $this->type = $type;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email): void
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getPermission()
    {
        return $this->permission;
    }

    /**
     * @param mixed $permission
     */
    public function setPermission($permission): void
    {
        $this->permission = $permission;
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param mixed $username
     */
    public function setUsername($username): void
    {
        $this->username = $username;
    }

    /**
     * @return mixed
     */
    public function getSurname()
    {
        return $this->surname;
    }

    /**
     * @param mixed $surname
     */
    public function setSurname($surname): void
    {
        $this->surname = $surname;
    }

    /**
     * @return mixed
     */
    public function getNumberMajor()
    {
        return $this->numberMajor;
    }

    /**
     * @param mixed $numberMajor
     */
    public function setNumberMajor($numberMajor): void
    {
        $this->numberMajor = $numberMajor;
    }

    /**
     * @return mixed
     */
    public function getTelnumber()
    {
        return $this->telnumber;
    }

    /**
     * @param mixed $telnumber
     */
    public function setTelnumber($telnumber): void
    {
        $this->telnumber = $telnumber;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param mixed $address
     */
    public function setAddress($address): void
    {
        $this->address = $address;
    }

}
