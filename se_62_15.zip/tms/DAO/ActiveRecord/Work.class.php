<?php
class Work
{
    private $work_id;
    private $topic;
    private $detail;
    private $start_date;
    private $start_time;
    private $end_date;
    private $end_time;
    private $status_public;
    private $status_work;
    private $file;
    private $send_date;
    private $send_time;
    private $complete_date;
    private $complete_time;
    private $manager_id;
    private $worker_id;
    private $team_id;
    private $notifyWork;

    private const TABLE = "work";
    public function __construct(){}
    public static function  getWorkByTeam(int $team_id,string  $status_work=NULL,string $status_public=NULL,string $statusTeam='OPEN'):array
    {
        $con = Db::getInstance();
        if(isset($status_work) && isset($status_public))
        {
            $query = "SELECT " . self::TABLE . ".* FROM team JOIN " . self::TABLE . " ON team.team_id = " . self::TABLE . ".team_id WHERE team.team_id = '$team_id' AND " . self::TABLE . ".status_work = '$status_work' AND " . self::TABLE . ".status_public = '$status_public' AND team.statusTeam='$statusTeam' ORDER BY " . self::TABLE . ".start_date DESC," . self::TABLE . ".start_time DESC ";
        }else if(isset($status_work)) {
            $query = "SELECT " . self::TABLE . ".* FROM team JOIN " . self::TABLE . " ON team.team_id = " . self::TABLE . ".team_id WHERE team.team_id = '$team_id' AND " . self::TABLE . ".status_work = '$status_work' AND team.statusTeam='$statusTeam' ORDER BY " . self::TABLE . ".start_date DESC," . self::TABLE . ".start_time DESC ";
        }else if(isset($status_public)) {
            $query = "SELECT " . self::TABLE . ".* FROM team JOIN " . self::TABLE . " ON team.team_id = " . self::TABLE . ".team_id WHERE team.team_id = '$team_id'  AND " . self::TABLE . ".status_public = '$status_public' AND team.statusTeam='$statusTeam' ORDER BY " . self::TABLE . ".start_date DESC," . self::TABLE . ".start_time DESC ";
        }else {
            $query = "SELECT " . self::TABLE . ".* FROM team JOIN " . self::TABLE . " ON team.team_id = " . self::TABLE . ".team_id WHERE team.team_id = '$team_id' AND team.statusTeam='$statusTeam' ORDER BY " . self::TABLE . ".start_date DESC," . self::TABLE . ".start_time DESC ";
        }
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Work");
        $stmt->execute();
        $workList = array();
        while ($work = $stmt->fetch())
        {
            $workList[$work->getWorkId()] = $work;
        }
        return $workList;
    }
    public static function  getWorkByMember(int $mem_id,string $status=null,string  $status_work=null,string $status_public=null,string $statusTeamMember='OPEN',string $statusTeam='OPEN'):?array
    {
        $con = Db::getInstance();
        if(isset($mem_id)&&isset($status)&&isset($status_work)&&isset($status_public)){
            $query = "SELECT " . self::TABLE . ".* FROM " . self::TABLE . " INNER JOIN team ON " . self::TABLE . ".team_id = team.team_id INNER JOIN team_member ON team_member.team_id = team.team_id INNER JOIN member ON team_member.mem_id = member.mem_id WHERE member.mem_id = '$mem_id' AND team_member.status = '$status' AND work.status_work = '$status_work' AND work.status_public = '$status_public' AND team_member.statusTeamWork='$statusTeamMember' AND team.statusTeam='$statusTeam' ORDER BY " . self::TABLE . ".start_date DESC," . self::TABLE . ".start_time DESC";
        }else if(isset($mem_id)&&isset($status)&&isset($status_work)) {
            $query = "SELECT " . self::TABLE . ".* FROM " . self::TABLE . " INNER JOIN team ON " . self::TABLE . ".team_id = team.team_id INNER JOIN team_member ON team_member.team_id = team.team_id INNER JOIN member ON team_member.mem_id = member.mem_id WHERE member.mem_id = '$mem_id' AND team_member.status = '$status' AND work.status_work = '$status_work'  AND team_member.statusTeamWork='$statusTeamMember' AND team.statusTeam='$statusTeam' ORDER BY " . self::TABLE . ".start_date DESC," . self::TABLE . ".start_time DESC";
        }else if(isset($mem_id)&&isset($status)&&isset($status_work)){
            $query = "SELECT " . self::TABLE . ".* FROM " . self::TABLE . " INNER JOIN team ON " . self::TABLE . ".team_id = team.team_id INNER JOIN team_member ON team_member.team_id = team.team_id INNER JOIN member ON team_member.mem_id = member.mem_id WHERE member.mem_id = '$mem_id' AND team_member.status = '$status' AND work.status_public = '$status_public' AND team_member.statusTeamWork='$statusTeamMember' AND team.statusTeam='$statusTeam' ORDER BY " . self::TABLE . ".start_date DESC," . self::TABLE . ".start_time DESC";
        }else if(isset($mem_id)&&isset($status)) {
            $query = "SELECT " . self::TABLE . ".* FROM " . self::TABLE . " INNER JOIN team ON " . self::TABLE . ".team_id = team.team_id INNER JOIN team_member ON team_member.team_id = team.team_id INNER JOIN member ON team_member.mem_id = member.mem_id WHERE member.mem_id = '$mem_id' AND team_member.status = '$status' AND team_member.statusTeamWork='$statusTeamMember' AND team.statusTeam='$statusTeam' ORDER BY " . self::TABLE . ".start_date DESC," . self::TABLE . ".start_time DESC";
        }else {
            return null;
        }
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Work");
        $stmt->execute();
        $workList = array();
        while ($work = $stmt->fetch())
        {
            $workList[$work->getWorkId()] = $work;
        }
        return $workList;
    }
    public  static function findAll():array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." ORDER BY start_date,start_time DESC";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Work");
        $stmt->execute();
        $workList = array();
        while ($work = $stmt->fetch())
        {
            $workList[$work->getWorkId()] = $work;
        }
        return $workList;
    }

    public static  function findById(int $id): ?Work
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE work_id ='$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Work");
        $stmt->execute();
        if ($work = $stmt->fetch())
        {
            return $work;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $work => $val) {
            if($val==null)
            {
                $values .= "NULL,";
            }else {
                $values .= "'$val',";
            }

        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        $res = $con->exec($query);
        $this->work_id = $con->lastInsertId();
        return $res;
    }
    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $work => $val) {
            if ($val == null) {
                $query .= " $work=NULL,";
            } else {
                $query .= " $work='$val',";
            }
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE work_id = " . $this->getWorkId();
        echo $query;
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE work_id ='{$this->getWorkId()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public static function countAll($teamID,$managerID)
    {
        $con = Db::getInstance();
        $query = "SELECT COUNT(work_id) FROM ". self::TABLE." WHERE team_id=".$teamID." AND manager_id = ".$managerID."";
        //echo $query;
        $stmt = $con->prepare($query);
        $stmt->execute();
        $count = $stmt->fetch();

        return $count;
    }
    public  static function countByDate($dateStart,$dateEnd,$teamID,$managerID)
    {
        $con = Db::getInstance();
        $query = "SELECT COUNT(work_id) FROM " .self::TABLE. " WHERE start_date BETWEEN '$dateStart' AND '$dateEnd'AND team_id='$teamID' AND manager_id='$managerID'";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $count = $stmt->fetch();

        return $count;
    }
    public static function statistic($teamID,$managerID)
    {
        $con = Db::getInstance();
        $query = "SELECT name,COUNT(worker_id) FROM (work INNER JOIN team_member ON work.worker_id=team_member.teamwork_id)INNER JOIN member ON team_member.mem_id=member.mem_id
                  WHERE  work.team_id='$teamID'  AND worker_id IS NOT NULL AND manager_id='$managerID' GROUP BY name ";
        //echo $query;
        $stmt = $con->prepare($query);
        $stmt->execute();
        $statis = $stmt->fetchAll();

        return $statis;
    }
    public static function statisticByDate($dateStart,$dateEnd,$teamID,$managerID)
    {
        $con = Db::getInstance();
        $query = "SELECT name,COUNT(worker_id) 
                  FROM (work INNER JOIN team_member ON work.worker_id=team_member.teamwork_id)INNER JOIN member ON team_member.mem_id=member.mem_id
                  WHERE  work.team_id='$teamID'  AND worker_id IS NOT NULL AND start_date BETWEEN '$dateStart' AND '$dateEnd' AND manager_id='$managerID'
                  GROUP BY name ";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $statis = $stmt->fetchAll();

        return $statis;
    }
    public static function statisticTable($teamID,$managerID)
    {
        $con = Db::getInstance();
        $query = "SELECT  work.start_date,work.topic,work.status_work,IF(work.worker_id IS NULL ,\"ไม่มี\",member.name) as worker FROM (work LEFT JOIN team_member ON work.worker_id=team_member.teamwork_id)LEFT JOIN member ON team_member.mem_id=member.mem_id WHERE  work.team_id='$teamID'  AND manager_id='$managerID'";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $statis = $stmt->fetchAll();

        return $statis;
    }
    public static function statisticTableByDate($dateStart,$dateEnd,$teamID,$managerID)
    {
        $con = Db::getInstance();
        $query = "SELECT  work.start_date,work.topic,work.status_work,IF(work.worker_id IS NULL ,\"ไม่มี\",member.name) as worker FROM (work LEFT JOIN team_member ON work.worker_id=team_member.teamwork_id)LEFT JOIN member ON team_member.mem_id=member.mem_id WHERE  work.team_id='$teamID'  AND manager_id='$managerID' AND start_date BETWEEN '$dateStart' AND '$dateEnd'";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $statis = $stmt->fetchAll();

        return $statis;
    }

    /**
     * @return mixed
     */
    public function getWorkId()
    {
        return $this->work_id;
    }

    /**
     * @param mixed $work_id
     */
    public function setWorkId($work_id): void
    {
        $this->work_id = $work_id;
    }

    /**
     * @return mixed
     */
    public function getTopic()
    {
        return $this->topic;
    }

    /**
     * @param mixed $topic
     */
    public function setTopic($topic): void
    {
        $this->topic = $topic;
    }

    /**
     * @return mixed
     */
    public function getDetail()
    {
        return $this->detail;
    }

    /**
     * @param mixed $detail
     */
    public function setDetail($detail): void
    {
        $this->detail = $detail;
    }

    /**
     * @return mixed
     */
    public function getStartDate()
    {
        return $this->start_date;
    }

    /**
     * @param mixed $start_date
     */
    public function setStartDate($start_date): void
    {
        $this->start_date = $start_date;
    }

    /**
     * @return mixed
     */
    public function getStartTime()
    {
        return $this->start_time;
    }

    /**
     * @param mixed $start_time
     */
    public function setStartTime($start_time): void
    {
        $this->start_time = $start_time;
    }

    /**
     * @return mixed
     */
    public function getEndDate()
    {
        return $this->end_date;
    }

    /**
     * @param mixed $end_date
     */
    public function setEndDate($end_date): void
    {
        $this->end_date = $end_date;
    }

    /**
     * @return mixed
     */
    public function getEndTime()
    {
        return $this->end_time;
    }

    /**
     * @param mixed $end_time
     */
    public function setEndTime($end_time): void
    {
        $this->end_time = $end_time;
    }

    /**
     * @return mixed
     */
    public function getStatusPublic()
    {
        return $this->status_public;
    }

    /**
     * @param mixed $status_public
     */
    public function setStatusPublic($status_public): void
    {
        $this->status_public = $status_public;
    }

    /**
     * @return mixed
     */
    public function getStatusWork()
    {
        return $this->status_work;
    }

    /**
     * @param mixed $status_work
     */
    public function setStatusWork($status_work): void
    {
        $this->status_work = $status_work;
    }

    /**
     * @return mixed
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @param mixed $file
     */
    public function setFile($file): void
    {
        $this->file = $file;
    }

    /**
     * @return mixed
     */
    public function getSendDate()
    {
        return $this->send_date;
    }

    /**
     * @param mixed $send_date
     */
    public function setSendDate($send_date): void
    {
        $this->send_date = $send_date;
    }

    /**
     * @return mixed
     */
    public function getSendTime()
    {
        return $this->send_time;
    }

    /**
     * @param mixed $send_time
     */
    public function setSendTime($send_time): void
    {
        $this->send_time = $send_time;
    }

    /**
     * @return mixed
     */
    public function getCompleteDate()
    {
        return $this->complete_date;
    }

    /**
     * @param mixed $complete_date
     */
    public function setCompleteDate($complete_date): void
    {
        $this->complete_date = $complete_date;
    }

    /**
     * @return mixed
     */
    public function getCompleteTime()
    {
        return $this->complete_time;
    }

    /**
     * @param mixed $complete_time
     */
    public function setCompleteTime($complete_time): void
    {
        $this->complete_time = $complete_time;
    }

    /**
     * @return mixed
     */
    public function getManagerId()
    {
        return $this->manager_id;
    }

    /**
     * @param mixed $manager_id
     */
    public function setManagerId($manager_id): void
    {
        $this->manager_id = $manager_id;
    }

    /**
     * @return mixed
     */
    public function getWorkerId()
    {
        return $this->worker_id;
    }

    /**
     * @param mixed $worker_id
     */
    public function setWorkerId($worker_id): void
    {
        $this->worker_id = $worker_id;
    }

    /**
     * @return mixed
     */
    public function getTeamId()
    {
        return $this->team_id;
    }

    /**
     * @param mixed $team_id
     */
    public function setTeamId($team_id): void
    {
        $this->team_id = $team_id;
    }

    /**
     * @return mixed
     */
    public function getNotifyWork()
    {
        return $this->notifyWork;
    }

    /**
     * @param mixed $notifyWork
     */
    public function setNotifyWork($notifyWork): void
    {
        $this->notifyWork = $notifyWork;
    }
    
}
