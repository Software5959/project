<?php
class Status
{
    private $status_id;
    private $statusType;

    private const TABLE = "status";
    public function __construct(){}
    public  static function findAll():array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE;
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Status");
        $stmt->execute();
        $statusList = array();
        while ($status = $stmt->fetch())
        {
            $statusList[$status->getStatusId()] = $status;
        }
        return $statusList;
    }
    public static  function findById(int $id): ?Status
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE status_id ='$id'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Status");
        $stmt->execute();
        if ($his = $stmt->fetch())
        {
            return $his;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $his => $val) {
            $values .= "'$val',";
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        $res = $con->exec($query);
        $this->status_id = $con->lastInsertId();
        return $res;
    }
    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $his => $val) {
            $query .= " $his='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE status_id = " . $this->getStatusId();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE status_id ='{$this->getStatusId()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    /**
     * @return mixed
     */
    public function getStatusId()
    {
        return $this->status_id;
    }

    /**
     * @param mixed $status_id
     */
    public function setStatusId($status_id): void
    {
        $this->status_id = $status_id;
    }

    /**
     * @return mixed
     */
    public function getStatusType()
    {
        return $this->statusType;
    }

    /**
     * @param mixed $statusType
     */
    public function setStatusType($statusType): void
    {
        $this->statusType = $statusType;
    }

}
