<?php
class Team
{
    private $team_id;
    private $name;
    private $create_date;
    private $create_time;
    private $head;
    private $statusTeam;

    private const TABLE = "team";
    public function __construct(){}
    public static function getTeamByWork(int $work_id,string $statusTeam='OPEN'):?Team
    {
        $con = Db::getInstance();
        $query = "SELECT ".self::TABLE.".* FROM ".self::TABLE." JOIN work ON ".self::TABLE.".team_id = work.team_id WHERE work.work_id ='$work_id' AND ".self::TABLE.".statusTeam='$statusTeam'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Team");
        $stmt->execute();
        if ($team = $stmt->fetch())
        {
            return $team;
        }
        return null;
    }
    public static function  getTeamByMember(int $mem_id,string $status=null,string $statusTeamMember='OPEN',string $statusTeam='OPEN'):array
    {
        $con = Db::getInstance();
        if(!isset($status)){
            $query = "SELECT ".self::TABLE.".* FROM ((member JOIN team_member ON member.mem_id = team_member.mem_id) JOIN ".self::TABLE." ON ".self::TABLE.".team_id = team_member.team_id) WHERE member.mem_id = '$mem_id' AND team_member.statusDisplay != 'HIDE' AND team_member.statusTeamWork='$statusTeamMember' AND ".self::TABLE.".statusTeam='$statusTeam' ORDER BY  team_member.statusDisplay ,create_date,create_time";
        }else {
            $query = "SELECT ".self::TABLE.".* FROM ((member JOIN team_member ON member.mem_id = team_member.mem_id) JOIN ".self::TABLE." ON ".self::TABLE.".team_id = team_member.team_id) WHERE member.mem_id = '$mem_id' AND team_member.status='$status' AND team_member.statusDisplay != 'HIDE' AND team_member.statusTeamWork='$statusTeamMember' AND ".self::TABLE.".statusTeam='$statusTeam' ORDER BY  team_member.statusDisplay ,create_date ,create_time ";
        }
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Team");
        $stmt->execute();
        $teamList = array();
        while ($team = $stmt->fetch())
        {
            $teamList[$team->getTeamId()] = $team;
        }
        return $teamList;
    }
    public  static function findAll(string $statusTeam='OPEN'):array
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." AND ".self::TABLE.".statusTeam='$statusTeam' ORDER BY create_date DESC,create_time DESC";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Team");
        $stmt->execute();
        $teamList = array();
        while ($team = $stmt->fetch())
        {
            $teamList[$team->getTeamId()] = $team;
        }
        return $teamList;
    }
    public static  function findById(int $id,string $statusTeam='OPEN'): ?Team
    {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." WHERE team_id ='$id' AND ".self::TABLE.".statusTeam='$statusTeam'";
        $stmt = $con->prepare($query);
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Team");
        $stmt->execute();
        if ($team = $stmt->fetch())
        {
            return $team;
        }
        return null;
    }
    public function insert():bool {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $team => $val) {
            if($val==null)
            {
                $values .= "NULL,";
            }else {
                $values .= "'$val',";
            }
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        $res = $con->exec($query);
        $this->team_id = $con->lastInsertId();
        return $res;
    }
    public function update():bool
    {
        $query = "UPDATE " . self::TABLE . " SET ";
        foreach ($this as $team => $val) {
            $query .= " $team='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE team_id = " . $this->getTeamId();
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
    public function  delete():bool
    {
        $query = "DELETE FROM ".self::TABLE." WHERE team_id ='{$this->getTeamId()}'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }

    /**
     * @return mixed
     */
    public function getTeamId()
    {
        return $this->team_id;
    }

    /**
     * @param mixed $team_id
     */
    public function setTeamId($team_id): void
    {
        $this->team_id = $team_id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name): void
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getCreateDate()
    {
        return $this->create_date;
    }

    /**
     * @param mixed $create_date
     */
    public function setCreateDate($create_date): void
    {
        $this->create_date = $create_date;
    }

    /**
     * @return mixed
     */
    public function getHead()
    {
        return $this->head;
    }

    /**
     * @param mixed $head
     */
    public function setHead($head): void
    {
        $this->head = $head;
    }

    /**
     * @return mixed
     */
    public function getCreateTime()
    {
        return $this->create_time;
    }

    /**
     * @param mixed $create_time
     */
    public function setCreateTime($create_time): void
    {
        $this->create_time = $create_time;
    }

    /**
     * @return mixed
     */
    public function getStatusTeam()
    {
        return $this->statusTeam;
    }

    /**
     * @param mixed $statusTeam
     */
    public function setStatusTeam($statusTeam): void
    {
        $this->statusTeam = $statusTeam;
    }


}
