<?php
function showTable(array $header, array $data){
    echo "<table class = \"table table-bordered\">";
    echo "<tr class =\"table-active\">";
    foreach ($header as $h){
        echo "<th>$h</th>";
    }
    echo "</tr>";
    foreach ($data as $row) {
        echo "<tr>";
        foreach ($row as $col){
            echo "<td>$col</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
}

function showTable2(array $header, array $data){
    echo "<table id=\"memberTable\" class=\"table table-striped table-bordered dataTable\" style=\"width: 100%;\" role=\"grid\"
          aria-describedby=\"example_info\">";
    echo "<thead><tr class=\"table-active\">";
    foreach ($header as $h){
        echo"<th scope=\"col\">$h</th>";
    }
    echo "</tr><thead>";
    foreach ($data as $row) {
        echo "<tr>";
        foreach ($row as $col){
            echo "<td>$col</td>";
        }
        echo "</tr>";
    }
    echo "</table>";

}
function formatDate(string $date){
    $date = new DateTime($date);
    return $date->format("d/m/Y");
}
function calculatePeriodOfTime(DateTime $dateTime):?string
{
    if(date("A")=="PM"){
        $date = (date("h")+12).date(":i:s");
        if(date("h")==12){
            $date = (date("h")-12).date(":i:s");
        }
    }else {
        $date = date("h:i:s");
        if(date("h")==12){
            $date = (date("h")-12).date(":i:s");
        }
    }
    $today = new DateTime(date("Y-m-d") . " " . $date);
    if($today>=$dateTime) {

        $interval = $today->diff($dateTime);
        if($interval->y==0){
            if($interval->m==0){
                if($interval->d==0){
                    if($interval->h==0){
                        if($interval->i==0){
                            return $interval->s.' วินาที';
                        }else return $interval->i.' นาที';
                    }else return $interval->h.' ชั่วโมง';
                }else if($interval->d>=7){
                    return (int)($interval->d/7).' สัปดาห์';
                }else return $interval->d.' วัน';
            } return $interval->m.' เดือน';
        }else return $interval->y.' ปี';
    }else return NULL;
}
function calculateBetweenPeriodOfTime(DateTime $endDateTime):string
{
    if(date("A")=="PM"){
        $date = (date("h")+12).date(":i:s");
        if(date("h")==12){
            $date = (date("h")-12).date(":i:s");
        }
    }else {
        $date = date("h:i:s");
        if(date("h")==12){
            $date = (date("h")-12).date(":i:s");
        }
    }
    $currentDate = new DateTime(date("Y-m-d") . " " . $date);
    $interval = $currentDate->diff($endDateTime);
    if($interval->format('%R')=='-') return "หมดเวลา";
    $days = (int)$interval->format('%a');
    $hours = (int)$interval->format('%H');
    $minutes = (int)$interval->format('%I');
    if($days==0)
    {
        if($minutes==0)
        {
            return $hours." ชั่วโมง";
        }
        return $hours." ชั่วโมง ".$minutes." นาที";
    }
    if($hours==0)
    {
        return $days." วัน";
    }
    return $days." วัน ".$hours." ชั่วโมง";
}
function EmailChangeStatus(string $email,string $team,string $target,string $head,string $topic,string $detail,string $status)
{
    require_once("phpmailer/PHPMailerAutoload.php");
    header('Content-Type: text/html; charset=utf-8');

    $mail = new PHPMailer;
    $mail->CharSet = "utf-8";
    $mail->isSMTP();

    //Enable SMTP debugging
    // 0 = off (for production use)
    // 1 = client messages
    // 2 = client and server messages
    $mail->SMTPDebug = 0;

    //Ask for HTML-friendly debug output
    $mail->Debugoutput = 'html';

    $mail->Host = 'smtp.gmail.com';
    //$mail->Host = 'smtp.mandrillapp.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $gmail_username = "TMSCPE10@gmail.com"; // gmail ที่ใช้ส่ง
    $gmail_password = "tmscpe10"; // รหัสผ่าน gmail
    // ตั้งค่าอนุญาตการใช้งานได้ที่นี่ https://myaccount.google.com/lesssecureapps?pli=1

    $sender = "TMS"; // ชื่อผู้ส่ง
    $email_sender = "TMSCPE10@gmail.com"; // เมล์ผู้ส่ง
    $email_receiver = $email; // เมล์ผู้รับ ***

    $subject = "Change Status"; // หัวข้อเมล์

    $mail->Username = $gmail_username;
    $mail->Password = $gmail_password;
    $mail->setFrom($email_sender, $sender);
    $mail->addAddress($email_receiver);
    $mail->Subject = $subject;

    if($status=='worker'){
        $status = "ถูกเปลี่ยนสถานะจากผู้สั่งงานเป็นผู้รับงาน";
    }else{
        $status = "ถูกเปลี่ยนสถานะจากผู้รับงานเป็นผู้สั่งงาน";
    }
    $email_content = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset=utf-8'/>
                <title>Email</title>
            </head>
            <body>
            <div style='padding:20px;'>
                <div>
                <h2>เรียน สมาชิกทีม $team</h2>
                    <h2>สมาชิก $target $status โดย $head</h2>
                    <h2>งาน</h2>
                    <h2>หัวข้อ : $topic</h2>
                    <h2>รายละเอียด : $detail</h2>
                    <h2>ถูกยกเลิก</h2>
                    <a href='http://158.108.207.4/WAD18_09/tms/' >
                        <h1><strong style='color:#3c83f9;'> >> คลิ๊กที่นี่ เพื่อไปหน้าเว็บหลัก<< </strong> </h1>
                    </a>
                    <h5 style='color:red;'>*อีเมลฉบับนี้เป็นการแจ้งข้อมูลจากระบบอัตโนมัติ กรุณาอย่าตอบกลับ</h5>
                </div>
                <div style='margin-top:30px;'>
                    <hr>
                    <address>
                        <h4>ติดต่อสอบถาม</h4>
                        <p>TMS</p>
                        <p>TMSCPE10@gmail.com</p>
                    </address>
                </div>
            </div>
            <div style='background: #3b434c;color: #a2abb7;padding:30px;'>
                <div style='text-align:center'>
                    TMS
                </div>
            </div>
            </body>
            </html>";

    //  ถ้ามี email ผู้รับ
    if ($email_receiver) {
        $mail->msgHTML($email_content);
        if (!$mail->send()) {  // สั่งให้ส่ง email
            // กรณีส่ง email ไม่สำเร็จ
            return $result = 0;
        } else {
            // กรณีส่ง email สำเร็จ
            return $result = 1;
        }
    } else //ถ้าไม่มีผู้รับ
        return $result = 2;

}
function EmailToWorker($email,$team,$manager,$topic,$detail)
{
    require_once("phpmailer/PHPMailerAutoload.php");
    header('Content-Type: text/html; charset=utf-8');

    $mail = new PHPMailer;
    $mail->CharSet = "utf-8";
    $mail->isSMTP();

    //Enable SMTP debugging
    // 0 = off (for production use)
    // 1 = client messages
    // 2 = client and server messages
    $mail->SMTPDebug = 0;

    //Ask for HTML-friendly debug output
    $mail->Debugoutput = 'html';

    $mail->Host = 'smtp.gmail.com';
    //$mail->Host = 'smtp.mandrillapp.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $gmail_username = "TMSCPE10@gmail.com"; // gmail ที่ใช้ส่ง
    $gmail_password = "tmscpe10"; // รหัสผ่าน gmail
    // ตั้งค่าอนุญาตการใช้งานได้ที่นี่ https://myaccount.google.com/lesssecureapps?pli=1

    $sender = "TMS"; // ชื่อผู้ส่ง
    $email_sender = "TMSCPE10@gmail.com"; // เมล์ผู้ส่ง
    $email_receiver = $email; // เมล์ผู้รับ ***

    $subject = "New work"; // หัวข้อเมล์

    $mail->Username = $gmail_username;
    $mail->Password = $gmail_password;
    $mail->setFrom($email_sender, $sender);
    $mail->addAddress($email_receiver);
    $mail->Subject = $subject;

    $email_content = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset=utf-8'/>
                <title>Email</title>
            </head>
            <body>
            <div style='padding:20px;'>
                <div>
                <h2>เรียน สมาชิกทีม $team</h2>
                    <h2>สมาชิก $manager ได้สั่งงาน</h2>
                    <h2>หัว : $topic</h2>
                    <h2>รายละเอียด : $detail</h2>
                    <a href='http://158.108.207.4/WAD18_09/tms/' >
                        <h1><strong style='color:#3c83f9;'> >> คลิ๊กที่นี่ เพื่อไปหน้าเว็บหลัก<< </strong> </h1>
                    </a>
                    <h5 style='color:red;'>*อีเมลฉบับนี้เป็นการแจ้งข้อมูลจากระบบอัตโนมัติ กรุณาอย่าตอบกลับ</h5>
                </div>
                <div style='margin-top:30px;'>
                    <hr>
                    <address>
                        <h4>ติดต่อสอบถาม</h4>
                        <p>TMS</p>
                        <p>TMSCPE10@gmail.com</p>
                    </address>
                </div>
            </div>
            <div style='background: #3b434c;color: #a2abb7;padding:30px;'>
                <div style='text-align:center'>
                    TMS
                </div>
            </div>
            </body>
            </html>";

    //  ถ้ามี email ผู้รับ
    if ($email_receiver) {
        $mail->msgHTML($email_content);
        if (!$mail->send()) {  // สั่งให้ส่ง email
            // กรณีส่ง email ไม่สำเร็จ
            return $result = 0;
        } else {
            // กรณีส่ง email สำเร็จ
            return $result = 1;
        }
    } else //ถ้าไม่มีผู้รับ
        return $result = 2;

}
function EmailToManager($email,$team,$worker,$topic,$detail)
{
    require_once("phpmailer/PHPMailerAutoload.php");
    header('Content-Type: text/html; charset=utf-8');

    $mail = new PHPMailer;
    $mail->CharSet = "utf-8";
    $mail->isSMTP();

    //Enable SMTP debugging
    // 0 = off (for production use)
    // 1 = client messages
    // 2 = client and server messages
    $mail->SMTPDebug = 0;

    //Ask for HTML-friendly debug output
    $mail->Debugoutput = 'html';

    $mail->Host = 'smtp.gmail.com';
    //$mail->Host = 'smtp.mandrillapp.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $gmail_username = "TMSCPE10@gmail.com"; // gmail ที่ใช้ส่ง
    $gmail_password = "tmscpe10"; // รหัสผ่าน gmail
    // ตั้งค่าอนุญาตการใช้งานได้ที่นี่ https://myaccount.google.com/lesssecureapps?pli=1

    $sender = "TMS"; // ชื่อผู้ส่ง
    $email_sender = "TMSCPE10@gmail.com"; // เมล์ผู้ส่ง
    $email_receiver = $email; // เมล์ผู้รับ ***

    $subject = "Send work"; // หัวข้อเมล์

    $mail->Username = $gmail_username;
    $mail->Password = $gmail_password;
    $mail->setFrom($email_sender, $sender);
    $mail->addAddress($email_receiver);
    $mail->Subject = $subject;

    $email_content = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset=utf-8'/>
                <title>Email</title>
            </head>
            <body>
            <div style='padding:20px;'>
                <div>
                <h2>เรียน สมาชิกทีม $team</h2>
                    <h2>สมาชิก $worker ได้ส่งงาน</h2>
                    <h2>หัว : $topic</h2>
                    <h2>รายละเอียด : $detail</h2>
                    <a href='http://158.108.207.4/WAD18_09/tms/' >
                        <h1><strong style='color:#3c83f9;'> >> คลิ๊กที่นี่ เพื่อไปหน้าเว็บหลัก<< </strong> </h1>
                    </a>
                    <h5 style='color:red;'>*อีเมลฉบับนี้เป็นการแจ้งข้อมูลจากระบบอัตโนมัติ กรุณาอย่าตอบกลับ</h5>
                </div>
                <div style='margin-top:30px;'>
                    <hr>
                    <address>
                        <h4>ติดต่อสอบถาม</h4>
                        <p>TMS</p>
                        <p>TMSCPE10@gmail.com</p>
                    </address>
                </div>
            </div>
            <div style='background: #3b434c;color: #a2abb7;padding:30px;'>
                <div style='text-align:center'>
                    TMS
                </div>
            </div>
            </body>
            </html>";

    //  ถ้ามี email ผู้รับ
    if ($email_receiver) {
        $mail->msgHTML($email_content);
        if (!$mail->send()) {  // สั่งให้ส่ง email
            // กรณีส่ง email ไม่สำเร็จ
            return $result = 0;
        } else {
            // กรณีส่ง email สำเร็จ
            return $result = 1;
        }
    } else //ถ้าไม่มีผู้รับ
        return $result = 2;

}
function EmailDeleteTeam($email,$team,$head)
{
    require_once("phpmailer/PHPMailerAutoload.php");
    header('Content-Type: text/html; charset=utf-8');

    $mail = new PHPMailer;
    $mail->CharSet = "utf-8";
    $mail->isSMTP();

    //Enable SMTP debugging
    // 0 = off (for production use)
    // 1 = client messages
    // 2 = client and server messages
    $mail->SMTPDebug = 0;

    //Ask for HTML-friendly debug output
    $mail->Debugoutput = 'html';

    $mail->Host = 'smtp.gmail.com';
    //$mail->Host = 'smtp.mandrillapp.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $gmail_username = "TMSCPE10@gmail.com"; // gmail ที่ใช้ส่ง
    $gmail_password = "tmscpe10"; // รหัสผ่าน gmail
    // ตั้งค่าอนุญาตการใช้งานได้ที่นี่ https://myaccount.google.com/lesssecureapps?pli=1

    $sender = "TMS"; // ชื่อผู้ส่ง
    $email_sender = "TMSCPE10@gmail.com"; // เมล์ผู้ส่ง
    $email_receiver = $email; // เมล์ผู้รับ ***

    $subject = "Send work"; // หัวข้อเมล์

    $mail->Username = $gmail_username;
    $mail->Password = $gmail_password;
    $mail->setFrom($email_sender, $sender);
    $mail->addAddress($email_receiver);
    $mail->Subject = $subject;

    $email_content = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset=utf-8'/>
                <title>Email</title>
            </head>
            <body>
            <div style='padding:20px;'>
                <div>
                <h2>เรียน สมาชิกทีม $team</h2>
                    <h2>หัวหน้าทีม $head ได้ลบทีม $team</h2>
                    <a href='http://158.108.207.4/WAD18_09/tms/' >
                        <h1><strong style='color:#3c83f9;'> >> คลิ๊กที่นี่ เพื่อไปหน้าเว็บหลัก<< </strong> </h1>
                    </a>
                    <h5 style='color:red;'>*อีเมลฉบับนี้เป็นการแจ้งข้อมูลจากระบบอัตโนมัติ กรุณาอย่าตอบกลับ</h5>
                </div>
                <div style='margin-top:30px;'>
                    <hr>
                    <address>
                        <h4>ติดต่อสอบถาม</h4>
                        <p>TMS</p>
                        <p>TMSCPE10@gmail.com</p>
                    </address>
                </div>
            </div>
            <div style='background: #3b434c;color: #a2abb7;padding:30px;'>
                <div style='text-align:center'>
                    TMS
                </div>
            </div>
            </body>
            </html>";

    //  ถ้ามี email ผู้รับ
    if ($email_receiver) {
        $mail->msgHTML($email_content);
        if (!$mail->send()) {  // สั่งให้ส่ง email
            // กรณีส่ง email ไม่สำเร็จ
            return $result = 0;
        } else {
            // กรณีส่ง email สำเร็จ
            return $result = 1;
        }
    } else //ถ้าไม่มีผู้รับ
        return $result = 2;

}
function EmailOutTeam($email,$team,$target,$topic,$detail,$head=null)
{
    require_once("phpmailer/PHPMailerAutoload.php");
    header('Content-Type: text/html; charset=utf-8');

    $mail = new PHPMailer;
    $mail->CharSet = "utf-8";
    $mail->isSMTP();

    //Enable SMTP debugging
    // 0 = off (for production use)
    // 1 = client messages
    // 2 = client and server messages
    $mail->SMTPDebug = 0;

    //Ask for HTML-friendly debug output
    $mail->Debugoutput = 'html';

    $mail->Host = 'smtp.gmail.com';
    //$mail->Host = 'smtp.mandrillapp.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $gmail_username = "TMSCPE10@gmail.com"; // gmail ที่ใช้ส่ง
    $gmail_password = "tmscpe10"; // รหัสผ่าน gmail
    // ตั้งค่าอนุญาตการใช้งานได้ที่นี่ https://myaccount.google.com/lesssecureapps?pli=1

    $sender = "TMS"; // ชื่อผู้ส่ง
    $email_sender = "TMSCPE10@gmail.com"; // เมล์ผู้ส่ง
    $email_receiver = $email; // เมล์ผู้รับ ***

    $subject = "New work"; // หัวข้อเมล์

    $mail->Username = $gmail_username;
    $mail->Password = $gmail_password;
    $mail->setFrom($email_sender, $sender);
    $mail->addAddress($email_receiver);
    $mail->Subject = $subject;

    if($head!=NULL) {
        $email_content = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset=utf-8'/>
                <title>Email</title>
            </head>
            <body>
            <div style='padding:20px;'>
                <div>
                <h2>เรียน สมาชิกทีม $team</h2>
                    <h2>งานหัวข้อ: $topic</h2>
                    <h2>รายละเอียด : $detail</h2>
                    <h2>เนื่องจากสมาชิก $target ได้ไล่ออกจากทีมโดยหัวหน้าทีม $head</h2>
                    <h2 >จึงทำให้งานที่สั่งหรือได้รับมานั้น<span style='color:red;'>ถูกยกเลิก</span></h2>
                    <a href='http://158.108.207.4/WAD18_09/tms/' >
                        <h1><strong style='color:#3c83f9;'> >> คลิ๊กที่นี่ เพื่อไปหน้าเว็บหลัก<< </strong> </h1>
                    </a>
                    <h5 style='color:red;'>*อีเมลฉบับนี้เป็นการแจ้งข้อมูลจากระบบอัตโนมัติ กรุณาอย่าตอบกลับ</h5>
                </div>
                <div style='margin-top:30px;'>
                    <hr>
                    <address>
                        <h4>ติดต่อสอบถาม</h4>
                        <p>TMS</p>
                        <p>TMSCPE10@gmail.com</p>
                    </address>
                </div>
            </div>
            <div style='background: #3b434c;color: #a2abb7;padding:30px;'>
                <div style='text-align:center'>
                    TMS
                </div>
            </div>
            </body>
            </html>";
    }else {
        $email_content = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset=utf-8'/>
                <title>Email</title>
            </head>
            <body>
            <div style='padding:20px;'>
                <div>
                <h2>เรียน สมาชิกทีม $team</h2>
                    <h2>งานหัวข้อ: $topic</h2>
                    <h2>รายละเอียด : $detail</h2>
                    <h2>เนื่องจากสมาชิก $target ได้ออกจากทีม</h2>
                    <h2>จึงทำให้งานที่สั่งหรือได้รับมานั้น<span style='color:red;'>ถูกยกเลิก</span></h2>
                    <a href='http://158.108.207.4/WAD18_09/tms/' >
                        <h1><strong style='color:#3c83f9;'> >> คลิ๊กที่นี่ เพื่อไปหน้าเว็บหลัก<< </strong> </h1>
                    </a>
                    <h5 style='color:red;'>*อีเมลฉบับนี้เป็นการแจ้งข้อมูลจากระบบอัตโนมัติ กรุณาอย่าตอบกลับ</h5>
                </div>
                <div style='margin-top:30px;'>
                    <hr>
                    <address>
                        <h4>ติดต่อสอบถาม</h4>
                        <p>TMS</p>
                        <p>TMSCPE10@gmail.com</p>
                    </address>
                </div>
            </div>
            <div style='background: #3b434c;color: #a2abb7;padding:30px;'>
                <div style='text-align:center'>
                    TMS
                </div>
            </div>
            </body>
            </html>";
    }

    //  ถ้ามี email ผู้รับ
    if ($email_receiver) {
        $mail->msgHTML($email_content);
        if (!$mail->send()) {  // สั่งให้ส่ง email
            // กรณีส่ง email ไม่สำเร็จ
            return $result = 0;
        } else {
            // กรณีส่ง email สำเร็จ
            return $result = 1;
        }
    } else //ถ้าไม่มีผู้รับ
        return $result = 2;

}
function EmailForget($email,$username,$password,$name,$surname)
{
    require_once("phpmailer/PHPMailerAutoload.php");
    header('Content-Type: text/html; charset=utf-8');

    $mail = new PHPMailer;
    $mail->CharSet = "utf-8";
    $mail->isSMTP();

    //Enable SMTP debugging
    // 0 = off (for production use)
    // 1 = client messages
    // 2 = client and server messages
    $mail->SMTPDebug = 0;

    //Ask for HTML-friendly debug output
    $mail->Debugoutput = 'html';

    $mail->Host = 'smtp.gmail.com';
    //$mail->Host = 'smtp.mandrillapp.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $gmail_username = "TMSCPE10@gmail.com"; // gmail ที่ใช้ส่ง
    $gmail_password = "tmscpe10"; // รหัสผ่าน gmail
    // ตั้งค่าอนุญาตการใช้งานได้ที่นี่ https://myaccount.google.com/lesssecureapps?pli=1

    $sender = "TMS"; // ชื่อผู้ส่ง
    $email_sender = "TMSCPE10@gmail.com"; // เมล์ผู้ส่ง
    $email_receiver = $email; // เมล์ผู้รับ ***

    $subject = "Send work"; // หัวข้อเมล์

    $mail->Username = $gmail_username;
    $mail->Password = $gmail_password;
    $mail->setFrom($email_sender, $sender);
    $mail->addAddress($email_receiver);
    $mail->Subject = $subject;

    $email_content = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset=utf-8'/>
                <title>Email</title>
            </head>
            <body>
            <div style='padding:20px;'>
                <div>
                <h2>เรียน คุณ $name $surname</h2>
                    <h2> ชื่อผู้ใช้ของคุณ คือ $username</h2>
                    <h2> รหัสผ่านของคุณ คือ $password </h2>
                    <a href='http://158.108.207.4/WAD18_09/tms/' >
                        <h1><strong style='color:#3c83f9;'> >> คลิ๊กที่นี่ เพื่อไปหน้าเว็บหลัก<< </strong> </h1>
                    </a>
                    <h5 style='color:red;'>*อีเมลฉบับนี้เป็นการแจ้งข้อมูลจากระบบอัตโนมัติ กรุณาอย่าตอบกลับ</h5>
                </div>
                <div style='margin-top:30px;'>
                    <hr>
                    <address>
                        <h4>ติดต่อสอบถาม</h4>
                        <p>TMS</p>
                        <p>TMSCPE10@gmail.com</p>
                    </address>
                </div>
            </div>
            <div style='background: #3b434c;color: #a2abb7;padding:30px;'>
                <div style='text-align:center'>
                    TMS
                </div>
            </div>
            </body>
            </html>";

    //  ถ้ามี email ผู้รับ
    if ($email_receiver) {
        $mail->msgHTML($email_content);
        if (!$mail->send()) {  // สั่งให้ส่ง email
            // กรณีส่ง email ไม่สำเร็จ
            return $result = 0;
        } else {
            // กรณีส่ง email สำเร็จ
            return $result = 1;
        }
    } else //ถ้าไม่มีผู้รับ
        return $result = 2;

}
