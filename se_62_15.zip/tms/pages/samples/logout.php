<?php

session_start();
unset($_SESSION["Logon"]);
session_destroy();

header('Location:login.php');
?>
