<?php
$controllers = array('pages'=>['form_login','error','home'],
    'students'=>['borrow'],'admin'=>['addEquipment','addEquip']);

function call($controller,$action){
    require_once ("Controllers/".$controller."_controller.php");
    switch ($controller){
        case "pages" :      require_once ('Models/equipmentModel.php');
                            require_once ('Models/typeModel.php');
                            $controller = new PagesController();
            break;
        case "students" :   require_once ('Models/typeModel.php');
                            require_once ('Models/equipmentModel.php');
                            $controller = new StudentsController();
            break;
        case "admin" :      require_once ('Models/typeModel.php');
                            require_once ('Models/equipmentModel.php');
                            $controller = new AdminController();
            break;
    }
    $controller->{$action}();
}
if (array_key_exists($controller,$controllers)){
    if (in_array($action,$controllers[$controller])){
        call($controller,$action);
    }
    else{
        call('pages','error');
    }
}
else{
    call('pages','error');
}
?>
