<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ระบบยืม-คืนอุปกรณ์ มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../vendors/iconfonts/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="../../css/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="../../images/favicon.png" />
</head>
<div class="container-scroller"><center><font size="5" color="black"> <a>ระบบยืม-คืนอุปกรณ์ ภาควิชาวิศวกรรมคอมพิวเตอร์เเะอิเล็กทรอนิกส์ มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน</a></font></center>
    <div class="container-fluid page-body-wrapper full-page-wrapper auth-page">

        <div class="content-wrapper d-flex align-items-center auth auth-bg-1 theme-one">
            <div class="row w-100">
                <div class="col-lg-4 mx-auto">
                    <div class="auto-form-wrapper">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">เข้าสู่ระบบ</h1>
                            </div>
                        <form class="user" name="userenter" onSubmit="return ChkValid()" method="post"  action="http://158.108.207.4/se62_15/StarAdmin/login1.php">
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" name="form_account"  placeholder="Username...">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control form-control-user" name="form_password" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <button ali class="btn btn-primary submit-btn btn-block" type="submit">Login</button><button ali class="btn btn-primary submit-btn btn-block" type="reset">Reset</button>
                                </td>

                            </div>
                        </form>
                            <div class="form-group d-flex justify-content-between">
                                <div class="form-check form-check-flat mt-0">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input" checked> Keep me signed in
                                    </label>
                                </div>
                            </div>
                        </form>
                    </ul>
                </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<!-- plugins:js -->
<script src="../../vendors/js/vendor.bundle.base.js"></script>
<script src="../../vendors/js/vendor.bundle.addons.js"></script>
<!-- endinject -->
<!-- inject:js -->
<script src="../../js/off-canvas.js"></script>
<script src="../../js/misc.js"></script>
<!-- endinject -->
<body >


</body>